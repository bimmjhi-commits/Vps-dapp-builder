export interface DeviceMarketEntry {
  brand: string;
  market: string;
}

export const DEVICE_MARKET_MAP: Record<string, DeviceMarketEntry> = {
  // OPPO
  CPH82901: { brand: 'OPPO', market: 'OPPO A7' },
  CPH1901: { brand: 'OPPO', market: 'OPPO A7' },
  CPH1903: { brand: 'OPPO', market: 'OPPO A7' },
  CPH1905: { brand: 'OPPO', market: 'OPPO A7' },
  CPH1919: { brand: 'OPPO', market: 'OPPO A5 2020' },
  CPH1931: { brand: 'OPPO', market: 'OPPO A5 2020' },
  CPH1803: { brand: 'OPPO', market: 'OPPO A3S' },
  CPH1853: { brand: 'OPPO', market: 'OPPO A3S' },
  CPH1909: { brand: 'OPPO', market: 'OPPO A5S' },
  CPH1937: { brand: 'OPPO', market: 'OPPO A9 2020' },
  CPH2015: { brand: 'OPPO', market: 'OPPO A31' },
  CPH2083: { brand: 'OPPO', market: 'OPPO A12' },
  CPH2127: { brand: 'OPPO', market: 'OPPO A53' },
  CPH2185: { brand: 'OPPO', market: 'OPPO A15' },
  CPH2239: { brand: 'OPPO', market: 'OPPO A54' },
  CPH2269: { brand: 'OPPO', market: 'OPPO A16' },
  CPH2385: { brand: 'OPPO', market: 'OPPO A57' },
  CPH2477: { brand: 'OPPO', market: 'OPPO A78' },
  CPH2557: { brand: 'OPPO', market: 'OPPO A58' },
  CPH2591: { brand: 'OPPO', market: 'OPPO A38' },
  CPH2603: { brand: 'OPPO', market: 'OPPO A60' },
  CPH2639: { brand: 'OPPO', market: 'OPPO A3X' },
  CPH2665: { brand: 'OPPO', market: 'OPPO A3' },

  // XIAOMI / REDMI / POCO
  '23129RAA4G': { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 13' },
  '23124RA7EO': { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 13' },
  '2312DRA50G': { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 13 PRO' },
  '23021RAA2Y': { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 12' },
  '23021RAAEG': { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 12' },
  '22101316G': { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 12 PRO' },
  '2201117TG': { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 11' },
  M2101K7AG: { brand: 'XIAOMI', market: 'XIAOMI REDMI NOTE 10' },
  M2006C3MG: { brand: 'XIAOMI', market: 'XIAOMI REDMI 9A' },
  '220333QAG': { brand: 'XIAOMI', market: 'XIAOMI REDMI 10C' },
  '23053RN02A': { brand: 'XIAOMI', market: 'XIAOMI REDMI 12' },
  '23106RN0DA': { brand: 'XIAOMI', market: 'XIAOMI REDMI 13C' },
  '2311DRK48G': { brand: 'XIAOMI', market: 'POCO X6 PRO' },
  '23122PCD1G': { brand: 'XIAOMI', market: 'POCO M6 PRO' },
  '23049PCD8G': { brand: 'XIAOMI', market: 'POCO F5' },
  '22041219PG': { brand: 'XIAOMI', market: 'POCO M4 5G' },

  // REALME
  RMX2020: { brand: 'REALME', market: 'REALME C3' },
  RMX2185: { brand: 'REALME', market: 'REALME C11' },
  RMX2189: { brand: 'REALME', market: 'REALME C15' },
  RMX3201: { brand: 'REALME', market: 'REALME C21' },
  RMX3261: { brand: 'REALME', market: 'REALME C21Y' },
  RMX3581: { brand: 'REALME', market: 'REALME C30' },
  RMX3624: { brand: 'REALME', market: 'REALME C33' },
  RMX3710: { brand: 'REALME', market: 'REALME C55' },
  RMX3760: { brand: 'REALME', market: 'REALME C53' },
  RMX3830: { brand: 'REALME', market: 'REALME C51' },
  RMX3930: { brand: 'REALME', market: 'REALME C67' },
  RMX3393: { brand: 'REALME', market: 'REALME 9 PRO+' },
  RMX3630: { brand: 'REALME', market: 'REALME 10' },
  RMX3780: { brand: 'REALME', market: 'REALME 11 5G' },

  // SAMSUNG
  'SM-A035F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A03' },
  'SM-A045F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A04' },
  'SM-A055F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A05' },
  'SM-A125F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A12' },
  'SM-A135F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A13' },
  'SM-A145F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A14' },
  'SM-A155F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A15' },
  'SM-A235F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A23' },
  'SM-A245F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A24' },
  'SM-A256E': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A25 5G' },
  'SM-A336E': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A33 5G' },
  'SM-A346E': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A34 5G' },
  'SM-A356E': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A35 5G' },
  'SM-A525F': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A52' },
  'SM-A536E': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A53 5G' },
  'SM-A546E': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A54 5G' },
  'SM-A556E': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY A55 5G' },
  'SM-S918B': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY S23 ULTRA' },
  'SM-S928B': { brand: 'SAMSUNG', market: 'SAMSUNG GALAXY S24 ULTRA' },

  // VIVO
  V2026: { brand: 'VIVO', market: 'VIVO Y20' },
  V2043: { brand: 'VIVO', market: 'VIVO Y12S' },
  V2111: { brand: 'VIVO', market: 'VIVO Y15S' },
  V2120: { brand: 'VIVO', market: 'VIVO Y21' },
  V2204: { brand: 'VIVO', market: 'VIVO Y22' },
  V2206: { brand: 'VIVO', market: 'VIVO Y16' },
  V2237: { brand: 'VIVO', market: 'VIVO Y27' },
  V2250: { brand: 'VIVO', market: 'VIVO V27' },
  V2309: { brand: 'VIVO', market: 'VIVO V29' },
  V2322: { brand: 'VIVO', market: 'VIVO Y17S' },
  V2339: { brand: 'VIVO', market: 'VIVO Y28' },

  // APPLE
  IPHONE: { brand: 'APPLE', market: 'APPLE IPHONE' },
  IPAD: { brand: 'APPLE', market: 'APPLE IPAD' }
};

function inferBrand(modelCode: string, ua: string): string {
  const upper = modelCode.toUpperCase();
  if (/^(CPH|P[A-Z]{2,3}\d)/.test(upper) || /\bOPPO\b/i.test(ua)) return 'OPPO';
  if (/^RMX\d/.test(upper) || /\bREALME\b/i.test(ua)) return 'REALME';
  if (/^(SM-|GT-)/.test(upper) || /\bSAMSUNG\b/i.test(ua)) return 'SAMSUNG';
  if (/^V\d{4}/.test(upper) || /\bVIVO\b/i.test(ua)) return 'VIVO';
  if (/^(22|23|24|25)\d{5,}/.test(upper) || /^M\d{4}/.test(upper) || /\b(XIAOMI|REDMI|POCO)\b/i.test(ua)) return 'XIAOMI';
  if (/^(IPHONE|IPAD|MAC)/.test(upper) || /\b(IPHONE|IPAD|MACINTOSH)\b/i.test(ua)) return 'APPLE';
  if (/PIXEL/i.test(upper)) return 'GOOGLE';
  if (/INFINIX/i.test(ua) || /^X6\d{3}/.test(upper)) return 'INFINIX';
  if (/TECNO/i.test(ua)) return 'TECNO';
  return 'DEVICE';
}

function extractModelFromUserAgent(ua: string): string {
  // Android UA pattern: "; Android 14; CPH82901 Build/..." or "; Android 10; K)"
  const androidMatch = ua.match(/Android\s+[^;)]+;\s*([^;)]+?)(?:\s+Build\/|\))/i);
  if (androidMatch && androidMatch[1]) {
    const candidate = androidMatch[1].trim();
    if (candidate && candidate.toUpperCase() !== 'WV') {
      return candidate;
    }
  }
  if (/iPhone/i.test(ua)) return 'IPHONE';
  if (/iPad/i.test(ua)) return 'IPAD';
  if (/Windows NT/i.test(ua)) return 'WINDOWS PC';
  if (/Macintosh/i.test(ua)) return 'MACINTOSH';
  if (/Linux/i.test(ua)) return 'LINUX PC';
  return 'UNKNOWN';
}

function detectOsAndBrowser(ua: string, platform?: string, platformVersion?: string): string {
  const isMobile = /Mobile|Android|iPhone|iPad/i.test(ua);
  let osLabel = 'UNKNOWN OS';

  if (platform && /android/i.test(platform)) {
    const major = platformVersion ? platformVersion.split('.')[0] : '';
    osLabel = major && Number(major) > 0 ? `ANDROID ${major}` : 'ANDROID';
  } else if (/Android\s+([\d.]+)/i.test(ua)) {
    const m = ua.match(/Android\s+([\d.]+)/i);
    osLabel = m ? `ANDROID ${m[1].split('.')[0]}` : 'ANDROID';
  } else if (/iPhone OS\s+([\d_]+)|CPU OS\s+([\d_]+)/i.test(ua)) {
    const m = ua.match(/(?:iPhone OS|CPU OS)\s+([\d_]+)/i);
    const ver = m ? m[1].replace(/_/g, '.').split('.')[0] : '';
    osLabel = ver ? `IOS ${ver}` : 'IOS';
  } else if (/Windows NT 10\.0/i.test(ua) || (platform && /windows/i.test(platform))) {
    const major = platformVersion ? Number(platformVersion.split('.')[0]) : 0;
    osLabel = major >= 13 ? 'WINDOWS 11' : 'WINDOWS 10';
  } else if (/Macintosh|Mac OS X/i.test(ua)) {
    osLabel = 'MACOS';
  } else if (/Linux/i.test(ua)) {
    osLabel = 'LINUX';
  }

  let browserLabel = 'BROWSER';
  if (/SamsungBrowser/i.test(ua)) {
    browserLabel = 'SAMSUNG INTERNET';
  } else if (/EdgA|EdgiOS|Edg\//i.test(ua)) {
    browserLabel = isMobile ? 'EDGE MOBILE' : 'EDGE DESKTOP';
  } else if (/OPR|Opera/i.test(ua)) {
    browserLabel = isMobile ? 'OPERA MOBILE' : 'OPERA';
  } else if (/FxiOS|Firefox/i.test(ua)) {
    browserLabel = isMobile ? 'FIREFOX MOBILE' : 'FIREFOX DESKTOP';
  } else if (/CriOS|Chrome/i.test(ua)) {
    browserLabel = isMobile ? 'CHROME MOBILE' : 'CHROME DESKTOP';
  } else if (/Safari/i.test(ua) && !/Chrome|Chromium/i.test(ua)) {
    browserLabel = isMobile ? 'SAFARI MOBILE' : 'SAFARI DESKTOP';
  }

  return `${osLabel} - ${browserLabel}`;
}

export interface DetectedDeviceInfo {
  headline: string;
  detectedText: string;
}

export async function getDetectedDeviceInfo(): Promise<DetectedDeviceInfo> {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : '';
  let rawModel = '';
  let uaPlatform = '';
  let uaPlatformVersion = '';

  try {
    const uaData = (navigator as any).userAgentData;
    if (uaData && typeof uaData.getHighEntropyValues === 'function') {
      const hints = await uaData.getHighEntropyValues(['model', 'platform', 'platformVersion']);
      if (hints?.model && typeof hints.model === 'string') {
        rawModel = hints.model.trim();
      }
      if (hints?.platform && typeof hints.platform === 'string') {
        uaPlatform = hints.platform.trim();
      }
      if (hints?.platformVersion && typeof hints.platformVersion === 'string') {
        uaPlatformVersion = hints.platformVersion.trim();
      }
    }
  } catch {
    // Fallback cleanly to navigator.userAgent
  }

  if (!rawModel) {
    rawModel = extractModelFromUserAgent(ua);
  }

  const upperModel = rawModel.toUpperCase();
  const mapped = DEVICE_MARKET_MAP[upperModel];
  const detectedText = detectOsAndBrowser(ua, uaPlatform, uaPlatformVersion);

  let headline = '';
  if (mapped) {
    headline = `${mapped.market} (${mapped.brand} ${upperModel})`;
  } else {
    const brand = inferBrand(upperModel, ua);
    if (upperModel === 'WINDOWS PC' || upperModel === 'MACINTOSH' || upperModel === 'LINUX PC' || upperModel === 'UNKNOWN') {
      headline = `${upperModel} (${brand} ${upperModel})`;
    } else {
      headline = `${upperModel} (${brand} ${upperModel})`;
    }
  }

  return {
    headline,
    detectedText
  };
}
