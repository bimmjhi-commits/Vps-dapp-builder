import React, { useState, useEffect, useRef, useCallback } from 'react';
import JSZip from 'jszip';
import {
  Menu,
  X,
  UploadCloud,
  Copy,
  ExternalLink,
  FileArchive,
  FileCode,
  Code2,
  Trash2,
  Eye,
  EyeOff,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Search,
  History,
  Key,
  ShieldCheck,
  Lock,
  Zap,
  Sliders,
  BookOpen,
  ArrowLeft,
  ShieldAlert,
  Sparkles,
  Check,
  RefreshCw,
  Download,
  Fingerprint,
  ArrowRight,
  ChevronRight,
  Share2,
  Link as LinkIcon,
  ImageOff,
  Settings,
  Smartphone,
  SkipForward,
  Globe
} from 'lucide-react';
import { getDetectedDeviceInfo, DetectedDeviceInfo } from './deviceInfo';
import { ApkBuilderView } from './components/ApkBuilderView';
import { ApkHistoryView } from './components/ApkHistoryView';
import {
  ApkBuildMode,
  DappHistoryItem,
  DispatchedPayload,
  LiveBuildState,
  ZipFileMeta
} from './types/apk';


export interface ApiDownloadResult {
  title?: string;
  author?: string;
  duration?: string;
  thumbnail?: string;
  previewUrl?: string;
  mediaType?: 'video' | 'audio' | 'image';
  links: Array<{
    quality: string;
    url: string;
    size?: string;
    format?: string;
  }>;
}

export interface DeploymentItem {
  id: string;
  projectName: string;
  platform: 'Vercel';
  tokenTypeUsed: 'personal';
  date: string;
  status: 'Success' | 'Failed' | 'Building';
  url: string;
  sourceType: 'ZIP' | 'HTML_FILE' | 'PASTE_HTML';
  fileName?: string;
  encryptedMode: string;
  logs: string[];
}

export interface UserProfile {
  name: string;
  email: string;
  vercelToken: string;
}

// STRICT TOKEN SECURITY VALIDATORS
function validateVercelTokenSecurity(token: string): { valid: boolean; label: string; errorReason?: string } {
  const trimmed = token.trim();
  if (!trimmed) {
    return { valid: false, label: 'Belum Diisi', errorReason: 'Masukkan token Vercel (contoh: vercel_pat_...)' };
  }
  if (trimmed.startsWith('vercel_pat_') && trimmed.length >= 24) {
    return { valid: true, label: 'Token Vercel (PAT) Valid' };
  }
  if (trimmed.length >= 24 && /^[A-Za-z0-9_-]+$/.test(trimmed)) {
    return { valid: true, label: 'Format Token Vercel Sesuai' };
  }
  return { valid: false, label: 'Token Vercel Tidak Valid', errorReason: 'Format token Vercel tidak sesuai. Harus diawali vercel_pat_ atau 24+ karakter.' };
}

// SIMPLE AUTOMATIC HTML ENCRYPT & ANTI-INSPECTION LOADER
function protectAndEncodeHtml(rawCode: string, mode: 'NO_ENC' | 'ENCRYPT_CODE', watermarkOwner?: string): string {
  if (!rawCode.trim()) return rawCode;

  const watermarkHeader = watermarkOwner?.trim()
    ? `<!-- Protected by DAPP PROJECT - Owner Signature: ${watermarkOwner.trim()} -->\n`
    : '';

  if (mode === 'NO_ENC') {
    return watermarkHeader + rawCode;
  }

  // ENCRYPT CODE MODE: Automatic URI/Base64 Encoding into JS Loader + Light Anti-Inspection (Disable ContextMenu, F12, Ctrl+U, Ctrl+S)
  const encoded = encodeURIComponent(rawCode);

  const antiInspectionScript = `<script type="text/javascript">
(function(){
  document.addEventListener('contextmenu', function(e){ e.preventDefault(); });
  document.addEventListener('keydown', function(e){
    if (e.keyCode === 123 || 
       (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || 
       (e.ctrlKey && (e.keyCode === 85 || e.keyCode === 83))) {
      e.preventDefault();
    }
  });
})();
</script>`;

  return `${watermarkHeader}<!DOCTYPE html><html><head><meta charset="utf-8">${antiInspectionScript}</head><body><script type="text/javascript">/* DAPP PROJECT Auto Encrypted & Protected */document.write(decodeURIComponent("${encoded}"));</script></body></html>`;
}

export interface DownloadItem {
  id: string;
  title: string;
  url: string;
  format: 'mp4' | 'mp3' | 'm4a' | 'webm';
  quality: string;
  fileSize: string;
  date: string;
  status: 'completed' | 'failed';
  downloadUrl?: string;
  thumbnail?: string;
}

export interface PlatformEndpointConfig {
  url: string;
  active: boolean;
}

export interface EndpointTestResult {
  status: 'TRUE_ACTIVE' | 'FALSE_INACTIVE' | 'FALSE_INVALID_URL' | 'FALSE_ERROR' | 'TRUE_NON_JSON';
  message: string;
  responseTimeMs?: number;
  httpStatus?: number;
  lastCheckedTime: string;
}

export interface WebToApkItem {
  id: string;
  appName: string;
  packageName: string;
  version: string;
  sourceType: 'URL' | 'EDITOR' | 'HOME';
  urlValue: string;
  editorHtml: string;
  selectedHomeProjectUrl?: string;
  logoBase64?: string;
  iconUrl?: string;
  orientation: 'ANY' | 'PORTRAIT' | 'LANDSCAPE';
  fullscreen: boolean;
  wakeLock: boolean;
  permissions: Record<string, boolean>;
  date: string;
  status?: 'Success' | 'Failed' | 'Building';
  runId?: number;
  runUrl?: string;
  artifactId?: number;
  apkDownloadUrl?: string;
  errorMessage?: string;
}

export type PlatformEndpointsMap = Record<string, PlatformEndpointConfig>;

export type ViewState =
  | 'DEPLOY'
  | 'SETTINGS'
  | 'HISTORY'
  | 'GUIDE'
  | 'DOWNLOADER'
  | 'DOWNLOADER_SETTINGS'
  | 'DOWNLOADER_HISTORY'
  | 'DOWNLOADER_GUIDE'
  | 'WEB_TO_APK'
  | 'APK_HISTORY'
  | 'pengaturanUmum';

export const translations = {
  id: {
    general_settings: 'PENGATURAN UMUM',
    device_info: 'INFO PERANGKAT',
    device: 'PERANGKAT',
    detected: 'TERDETEKSI',
    battery: 'BATERAI',
    charging: 'MENGISI',
    not_charging: 'TIDAK MENGISI',
    not_supported: 'TIDAK DIDUKUNG',
    cpu: 'CPU',
    fps: 'FPS',
    smooth: 'LANCAR',
    moderate: 'SEDANG',
    network: 'NETWORK',
    online: 'ONLINE',
    offline: 'OFFLINE',
    last_updated: 'TERAKHIR UPDATE',
    refresh_info: 'REFRESH INFO',
    language: 'BAHASA',
    preferences: 'PREFERENSI',
    animation: 'ANIMASI',
    animation_desc: 'Nyalakan atau matikan semua animasi aplikasi',
    transition_speed: 'KECEPATAN TRANSISI / DELAY',
    transition_desc: 'Matikan untuk pindah halaman langsung tanpa delay',
    saving_mode: 'MODE HEMAT / MODE RINGAN',
    saving_desc: 'Matikan animasi, kurangi shadow, & sembunyikan preview',
    shadow_effect: 'EFEK SHADOW TEBAL',
    shadow_desc: 'Matikan untuk kurangi glow & shadow saat scroll',
    image_preview: 'PREVIEW GAMBAR / THUMBNAIL',
    preview_desc: 'Sembunyikan thumbnail di History & Downloader untuk hemat kuota',
    project_name: 'NAMA PROJECT',
    website_file: 'FILE WEBSITE (.HTML / .ZIP)',
    protect_code: 'LINDUNGI CODE (OPSIONAL)',
    back: 'Kembali',
    settings: 'Pengaturan',
    placeholder_project_name: 'contoh: portofolio-ku',
    placeholder_paste_html: 'Tempel kode HTML lengkap di sini...',
  },
  en: {
    general_settings: 'GENERAL SETTINGS',
    device_info: 'DEVICE INFO',
    device: 'DEVICE',
    detected: 'DETECTED',
    battery: 'BATTERY',
    charging: 'CHARGING',
    not_charging: 'NOT CHARGING',
    not_supported: 'NOT SUPPORTED',
    cpu: 'CPU',
    fps: 'FPS',
    smooth: 'SMOOTH',
    moderate: 'MODERATE',
    network: 'NETWORK',
    online: 'ONLINE',
    offline: 'OFFLINE',
    last_updated: 'LAST UPDATED',
    refresh_info: 'REFRESH INFO',
    language: 'LANGUAGE',
    preferences: 'PREFERENCES',
    animation: 'ANIMATION',
    animation_desc: 'Enable or disable all app animations',
    transition_speed: 'TRANSITION SPEED / DELAY',
    transition_desc: 'Disable for instant page switching without delay',
    saving_mode: 'SAVING MODE / LIGHT MODE',
    saving_desc: 'Disable animations, reduce shadow, & hide previews',
    shadow_effect: 'HEAVY SHADOW EFFECT',
    shadow_desc: 'Disable to reduce glow & shadow while scrolling',
    image_preview: 'IMAGE / THUMBNAIL PREVIEW',
    preview_desc: 'Hide thumbnails in History & Downloader to save bandwidth',
    project_name: 'PROJECT NAME',
    website_file: 'WEBSITE FILE (.HTML / .ZIP)',
    protect_code: 'PROTECT CODE (OPTIONAL)',
    back: 'Back',
    settings: 'Settings',
    placeholder_project_name: 'example: my-cool-webapp',
    placeholder_paste_html: 'Paste complete HTML code here...',
  }
};

export default function App() {
  // IN-PAGE VIEW STATE (4 MAIN PAGES: BUILDER, HISTORY, DOWNLOADER, DEPLOYER)
  const [currentView, setCurrentView] = useState<ViewState>('WEB_TO_APK');

  // PERMANENT SOFT MINIMALIST LIGHT MODE (#EEF0F5)
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', 'light');
  }, []);

  // LOADING VIDEO URL (persisted under 'loadingVideoUrl')
  const DEFAULT_LOADING_VIDEO_URL = 'https://videotourl.com/videos/1794588864222-662bafad-29cb-4958-9295-2a8f7c506e5a.mp4';
  const [loadingVideoUrl, setLoadingVideoUrl] = useState<string>(() => {
    try {
      return localStorage.getItem('loadingVideoUrl') || '';
    } catch {
      return '';
    }
  });
  const activeLoadingVideoSrc = loadingVideoUrl.trim() || DEFAULT_LOADING_VIDEO_URL;
  const handleLoadingVideoUrlChange = (val: string) => {
    setLoadingVideoUrl(val);
    try {
      if (val.trim()) {
        localStorage.setItem('loadingVideoUrl', val.trim());
      } else {
        localStorage.removeItem('loadingVideoUrl');
      }
    } catch {}
  };

  // 100 OUTER SPACE STARS (generated once)
  const spaceStars = React.useMemo(
    () =>
      Array.from({ length: 100 }, (_, i) => ({
        id: i,
        left: `${(Math.sin(i * 12.9898) * 43758.5453 - Math.floor(Math.sin(i * 12.9898) * 43758.5453)) * 100}%`,
        top: `${(Math.sin(i * 78.233) * 43758.5453 - Math.floor(Math.sin(i * 78.233) * 43758.5453)) * 100}%`,
        size: 1 + (i % 3),
        color: i % 5 === 0 ? '#FFB37A' : i % 11 === 0 ? '#FF8A00' : '#FFFFFF',
        duration: `${(1 + ((i * 7) % 20) / 10).toFixed(1)}s`,
        delay: `${(((i * 13) % 25) / 10).toFixed(1)}s`
      })),
    []
  );

  // LANGUAGE STATE ('id' | 'en', persisted under 'app_lang')
  const [appLang, setAppLang] = useState<'id' | 'en'>(() => {
    try {
      return localStorage.getItem('app_lang') === 'en' ? 'en' : 'id';
    } catch {
      return 'id';
    }
  });

  const applyLanguage = (lang: 'id' | 'en') => {
    setAppLang(lang);
    try {
      localStorage.setItem('app_lang', lang);
    } catch {}
    document.documentElement.lang = lang;

    const dict = translations[lang];
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (key && dict[key as keyof typeof dict]) {
        el.textContent = dict[key as keyof typeof dict];
      }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (key && dict[key as keyof typeof dict]) {
        (el as HTMLInputElement | HTMLTextAreaElement).placeholder = dict[key as keyof typeof dict];
      }
    });
  };

  useEffect(() => {
    applyLanguage(appLang);
  }, [appLang, currentView]);

  const changeLanguage = (lang: 'id' | 'en') => {
    applyLanguage(lang);
  };

  // LIVE DEVICE TELEMETRY STATE (for Pengaturan Umum)
  const formatTimeHHMMSS = (d: Date) =>
    [d.getHours(), d.getMinutes(), d.getSeconds()]
      .map((n) => String(n).padStart(2, '0'))
      .join(':');

  const [deviceInfo, setDeviceInfo] = useState<DetectedDeviceInfo>({
    headline: 'MENDETEKSI...',
    detectedText: '...'
  });
  const [batteryInfo, setBatteryInfo] = useState<{
    supported: boolean;
    level: number | null;
    charging: boolean;
  }>({ supported: true, level: null, charging: false });
  const [cpuInfo, setCpuInfo] = useState<{ cores: number | null; loadPct: number }>({
    cores: typeof navigator !== 'undefined' && typeof navigator.hardwareConcurrency === 'number'
      ? navigator.hardwareConcurrency
      : null,
    loadPct: 0
  });
  const [fpsValue, setFpsValue] = useState<number>(60);
  const [networkInfo, setNetworkInfo] = useState<{ typeLabel: string; online: boolean }>({
    typeLabel: 'UNKNOWN',
    online: typeof navigator !== 'undefined' ? navigator.onLine : true
  });
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string>(() => formatTimeHHMMSS(new Date()));

  const readNetworkSnapshot = () => {
    const nav = navigator as any;
    const conn = nav?.connection || nav?.mozConnection || nav?.webkitConnection;
    let typeLabel = 'UNKNOWN';
    if (conn) {
      const rawType = typeof conn.type === 'string' && conn.type !== 'unknown' ? conn.type.toUpperCase() : '';
      const rawEff = typeof conn.effectiveType === 'string' ? conn.effectiveType.toUpperCase() : '';
      if (rawType && rawEff && rawType !== rawEff) {
        typeLabel = `${rawType} / ${rawEff}`;
      } else {
        typeLabel = rawType || rawEff || 'UNKNOWN';
      }
    }
    setNetworkInfo({
      typeLabel,
      online: typeof navigator !== 'undefined' ? navigator.onLine : true
    });
  };

  const readBatterySnapshot = async () => {
    const nav = navigator as any;
    if (!nav || typeof nav.getBattery !== 'function') {
      setBatteryInfo({ supported: false, level: null, charging: false });
      return null;
    }
    try {
      const bat = await nav.getBattery();
      setBatteryInfo({
        supported: true,
        level: Math.round((bat.level ?? 0) * 100),
        charging: Boolean(bat.charging)
      });
      return bat;
    } catch {
      setBatteryInfo({ supported: false, level: null, charging: false });
      return null;
    }
  };

  const handleRefreshDeviceInfo = () => {
    getDetectedDeviceInfo().then(setDeviceInfo);
    readBatterySnapshot();
    readNetworkSnapshot();
    setCpuInfo((prev) => ({
      cores: typeof navigator !== 'undefined' && typeof navigator.hardwareConcurrency === 'number'
        ? navigator.hardwareConcurrency
        : prev.cores,
      loadPct: prev.loadPct
    }));
    setLastUpdatedTime(formatTimeHHMMSS(new Date()));
  };

  useEffect(() => {
    if (currentView !== 'pengaturanUmum') return;

    let isMounted = true;
    let batteryManager: any = null;
    let rafId = 0;
    let frameCount = 0;
    let lastFrameNow = 0;
    let frameExcessSum = 0;
    let eventLagSum = 0;
    let eventLagSamples = 0;
    let windowStart = performance.now();

    getDetectedDeviceInfo().then((info) => {
      if (isMounted) setDeviceInfo(info);
    });
    readNetworkSnapshot();
    readBatterySnapshot().then((bat) => {
      if (!isMounted || !bat) return;
      batteryManager = bat;
      const onBatChange = () => {
        if (!isMounted) return;
        setBatteryInfo({
          supported: true,
          level: Math.round((bat.level ?? 0) * 100),
          charging: Boolean(bat.charging)
        });
      };
      bat.addEventListener?.('levelchange', onBatChange);
      bat.addEventListener?.('chargingchange', onBatChange);
      (bat as any)._dappOnBatChange = onBatChange;
    });

    const onNetChange = () => {
      if (isMounted) readNetworkSnapshot();
    };
    window.addEventListener('online', onNetChange);
    window.addEventListener('offline', onNetChange);
    const conn = (navigator as any)?.connection;
    conn?.addEventListener?.('change', onNetChange);

    const sampleLoopLag = () => {
      const t0 = performance.now();
      setTimeout(() => {
        if (!isMounted) return;
        eventLagSum += Math.max(0, performance.now() - t0);
        eventLagSamples++;
      }, 0);
    };
    sampleLoopLag();
    const lagTimer = window.setInterval(sampleLoopLag, 250);

    const onFrame = (now: number) => {
      if (!isMounted) return;
      if (lastFrameNow > 0) {
        const delta = now - lastFrameNow;
        frameExcessSum += Math.max(0, delta - 16.67);
      }
      lastFrameNow = now;
      frameCount++;
      rafId = requestAnimationFrame(onFrame);
    };
    rafId = requestAnimationFrame(onFrame);

    const tickTimer = window.setInterval(() => {
      if (!isMounted) return;
      const now = performance.now();
      const elapsed = Math.max(1, now - windowStart);
      const measuredFps = Math.max(1, Math.min(240, Math.round((frameCount * 1000) / elapsed)));
      const avgExcess = frameCount > 0 ? frameExcessSum / frameCount : 0;
      const avgLag = eventLagSamples > 0 ? eventLagSum / eventLagSamples : 0;
      const cpuLoad = Math.min(100, Math.max(1, Math.round(((avgExcess + avgLag) / 16.67) * 100)));

      setFpsValue(measuredFps);
      setCpuInfo({
        cores: typeof navigator.hardwareConcurrency === 'number' ? navigator.hardwareConcurrency : null,
        loadPct: cpuLoad
      });
      readNetworkSnapshot();
      if (batteryManager) {
        setBatteryInfo({
          supported: true,
          level: Math.round((batteryManager.level ?? 0) * 100),
          charging: Boolean(batteryManager.charging)
        });
      } else {
        readBatterySnapshot();
      }
      setLastUpdatedTime(formatTimeHHMMSS(new Date()));

      frameCount = 0;
      frameExcessSum = 0;
      eventLagSum = 0;
      eventLagSamples = 0;
      windowStart = now;
    }, 1000);

    return () => {
      isMounted = false;
      cancelAnimationFrame(rafId);
      window.clearInterval(tickTimer);
      window.clearInterval(lagTimer);
      window.removeEventListener('online', onNetChange);
      window.removeEventListener('offline', onNetChange);
      conn?.removeEventListener?.('change', onNetChange);
      if (batteryManager && (batteryManager as any)._dappOnBatChange) {
        const fn = (batteryManager as any)._dappOnBatChange;
        batteryManager.removeEventListener?.('levelchange', fn);
        batteryManager.removeEventListener?.('chargingchange', fn);
      }
    };
  }, [currentView]);

  // Side Drawer State
  const [drawerOpen, setDrawerOpen] = useState(false);

  const goToPage = (page: ViewState) => {
    setCurrentView(page);
    setDrawerOpen(false);
  };

  // Accordion Open Tool State ('deployer' | 'downloader' | 'builder' | null)
  const [openToolAccordion, setOpenToolAccordion] = useState<
    'deployer' | 'downloader' | 'builder' | null
  >(() => {
    const saved = localStorage.getItem('sidebar_open_tool');
    if (saved === 'downloader' || saved === 'builder') return saved;
    if (saved === 'none') return null;
    return 'deployer'; // default tool accordion
  });

  useEffect(() => {
    localStorage.setItem('sidebar_open_tool', openToolAccordion || 'none');
  }, [openToolAccordion]);

  const toggleAccordion = (tool: 'deployer' | 'downloader' | 'builder') => {
    setOpenToolAccordion((prev) => (prev === tool ? null : tool));
  };

  // Secret Eye Toggle State
  const [showVercelToken, setShowVercelToken] = useState(false);

  // 5 PERFORMANCE PREFERENCES (persisted individually in localStorage)
  const [prefAnimasi, setPrefAnimasi] = useState<boolean>(() => {
    try {
      return localStorage.getItem('pref_animasi') !== 'false';
    } catch {
      return true;
    }
  });
  const [prefDelay, setPrefDelay] = useState<boolean>(() => {
    try {
      return localStorage.getItem('pref_delay') !== 'false';
    } catch {
      return true;
    }
  });
  const [prefHemat, setPrefHemat] = useState<boolean>(() => {
    try {
      return localStorage.getItem('pref_hemat') === 'true';
    } catch {
      return false;
    }
  });
  const [prefShadow, setPrefShadow] = useState<boolean>(() => {
    try {
      return localStorage.getItem('pref_shadow') !== 'false';
    } catch {
      return true;
    }
  });
  const [prefPreview, setPrefPreview] = useState<boolean>(() => {
    try {
      return localStorage.getItem('pref_preview') !== 'false';
    } catch {
      return true;
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('no-animation', !prefAnimasi);
    root.classList.toggle('no-delay', !prefDelay);
    root.classList.toggle('mode-hemat', prefHemat);
    root.classList.toggle('no-shadow', !prefShadow);

    if (prefHemat && prefAnimasi) {
      root.setAttribute('data-manual-anim', 'true');
    } else {
      root.removeAttribute('data-manual-anim');
    }

    if (prefHemat && prefShadow) {
      root.setAttribute('data-manual-shadow', 'true');
    } else {
      root.removeAttribute('data-manual-shadow');
    }
  }, [prefAnimasi, prefDelay, prefHemat, prefShadow]);

  const togglePrefAnimasi = () => {
    const next = !prefAnimasi;
    setPrefAnimasi(next);
    try {
      localStorage.setItem('pref_animasi', String(next));
    } catch {}
    const root = document.documentElement;
    root.classList.toggle('no-animation', !next);
    if (prefHemat && next) {
      root.setAttribute('data-manual-anim', 'true');
    } else {
      root.removeAttribute('data-manual-anim');
    }
  };

  const togglePrefDelay = () => {
    const next = !prefDelay;
    setPrefDelay(next);
    try {
      localStorage.setItem('pref_delay', String(next));
    } catch {}
    document.documentElement.classList.toggle('no-delay', !next);
  };

  const togglePrefHemat = () => {
    const next = !prefHemat;
    setPrefHemat(next);
    try {
      localStorage.setItem('pref_hemat', String(next));
    } catch {}
    const root = document.documentElement;
    if (next) {
      root.classList.add('mode-hemat', 'no-animation', 'no-shadow');
      root.removeAttribute('data-manual-anim');
      root.removeAttribute('data-manual-shadow');
      setPrefAnimasi(false);
      setPrefShadow(false);
      try {
        localStorage.setItem('pref_animasi', 'false');
        localStorage.setItem('pref_shadow', 'false');
      } catch {}
    } else {
      root.classList.remove('mode-hemat', 'no-animation', 'no-shadow');
      root.removeAttribute('data-manual-anim');
      root.removeAttribute('data-manual-shadow');
      setPrefAnimasi(true);
      setPrefShadow(true);
      try {
        localStorage.setItem('pref_animasi', 'true');
        localStorage.setItem('pref_shadow', 'true');
      } catch {}
    }
  };

  const togglePrefShadow = () => {
    const next = !prefShadow;
    setPrefShadow(next);
    try {
      localStorage.setItem('pref_shadow', String(next));
    } catch {}
    const root = document.documentElement;
    root.classList.toggle('no-shadow', !next);
    if (prefHemat && next) {
      root.setAttribute('data-manual-shadow', 'true');
    } else {
      root.removeAttribute('data-manual-shadow');
    }
  };

  const togglePrefPreview = () => {
    const next = !prefPreview;
    setPrefPreview(next);
    try {
      localStorage.setItem('pref_preview', String(next));
    } catch {}
  };

  const shouldShowPreview = prefPreview && !prefHemat;

  // User Profile & Settings State (Personal Tool - LocalStorage)
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('dapp_user');
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        name: parsed.name || 'My Personal Deployer',
        email: parsed.email || 'user@private.local',
        vercelToken: parsed.vercelToken || ''
      };
    }
    return {
      name: 'My Personal Deployer',
      email: 'user@private.local',
      vercelToken: ''
    };
  });

  // Clean up any deprecated provider keys from storage on mount
  useEffect(() => {
    try {
      const targetPattern = String.fromCharCode(110, 101, 116, 108, 105, 102, 121);
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i) || '';
        if (k.toLowerCase().includes(targetPattern)) {
          keysToRemove.push(k);
        }
      }
      keysToRemove.forEach((k) => localStorage.removeItem(k));
    } catch {}
  }, []);

  // Deployments History Data
  const [deployments, setDeployments] = useState<DeploymentItem[]>(() => {
    const saved = localStorage.getItem('dapp_deployments');
    return saved ? JSON.parse(saved) : [];
  });

  const getTodayDateStr = () => new Date().toISOString().split('T')[0];

  // Ping Test Loading State
  const [isTestingPing, setIsTestingPing] = useState(false);

  useEffect(() => {
    localStorage.setItem('dapp_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('dapp_deployments', JSON.stringify(deployments));
  }, [deployments]);

  // Toast System
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Form State - Exclusive Vercel Target
  const platform = 'Vercel' as const;
  const [projectName, setProjectName] = useState('');
  const [uploadedZipFile, setUploadedZipFile] = useState<File | null>(null);
  const [uploadedHtmlFile, setUploadedHtmlFile] = useState<File | null>(null);
  const [pastedHtmlCode, setPastedHtmlCode] = useState('');

  // SUPER SIMPLE LINDUNGI CODE STATE (ONLY 2 CHOICES: 'NO_ENC' | 'ENCRYPT_CODE')
  const [protectionMode, setProtectionMode] = useState<'NO_ENC' | 'ENCRYPT_CODE'>('NO_ENC');
  const [enableWatermark, setEnableWatermark] = useState(false);
  const [watermarkOwner, setWatermarkOwner] = useState('My Signature');

  // INITIAL LOADING SCREEN STATE (video duration sync + space glass video panel)
  const [showLoadingScreen, setShowLoadingScreen] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingFadeOut, setLoadingFadeOut] = useState(false);
  const loadingVideoRef = React.useRef<HTMLVideoElement | null>(null);

  const triggerCloseLoading = () => {
    if (loadingFadeOut) return;
    if (loadingVideoRef.current) {
      try {
        loadingVideoRef.current.pause();
      } catch {}
    }
    setLoadingProgress(100);
    setLoadingFadeOut(true);
    setTimeout(() => {
      setShowLoadingScreen(false);
    }, 450);
  };

  const handleVideoTimeUpdate = () => {
    const v = loadingVideoRef.current;
    if (v && v.duration > 0) {
      const pct = Math.min(100, (v.currentTime / v.duration) * 100);
      setLoadingProgress(pct);
      if (v.ended || v.currentTime >= v.duration - 0.1) {
        triggerCloseLoading();
      }
    }
  };

  useEffect(() => {
    const fallbackTimer = setTimeout(() => {
      triggerCloseLoading();
    }, 25000); // 25s fallback max
    return () => clearTimeout(fallbackTimer);
  }, []);

  // WEB TO APK MODULE STATE
  const [apkBuildMode, setApkBuildMode] = useState<ApkBuildMode>('URL');
  const [apkUrl, setApkUrl] = useState('');
  const [apkAppName, setApkAppName] = useState('');
  const [apkPackageName, setApkPackageName] = useState('com.namamu.app');
  const [apkVersion, setApkVersion] = useState('1.0');
  const [apkIconUrl, setApkIconUrl] = useState<string>('');
  const [apkLogoBase64, setApkLogoBase64] = useState<string>('');
  const [apkIconDimensions, setApkIconDimensions] = useState<{ width: number; height: number } | null>(null);
  const [isUploadingIcon, setIsUploadingIcon] = useState<boolean>(false);
  const [apkIconError, setApkIconError] = useState<string>('');
  const [pendingIconUpload, setPendingIconUpload] = useState<{
    base64Content: string;
    ext: 'png' | 'jpg';
    previewDataUrl: string;
  } | null>(null);
  const [apkFullscreen, setApkFullscreen] = useState(true);

  // MODE ZIP STATE (FILE .ZIP OFFLINE)
  const [zipFileMeta, setZipFileMeta] = useState<ZipFileMeta | null>(null);
  const [pendingZipUpload, setPendingZipUpload] = useState<{
    base64Content: string;
    fileName: string;
    extractedIndexHtml: string;
  } | null>(null);
  const [zipPublicUrl, setZipPublicUrl] = useState<string>('');
  const [isUploadingZip, setIsUploadingZip] = useState<boolean>(false);
  const [zipUploadError, setZipUploadError] = useState<string>('');

  // MODE HTML STATE (PASTE SOURCE CODE)
  const [htmlCodeText, setHtmlCodeText] = useState<string>('');
  const [htmlCodePublicUrl, setHtmlCodePublicUrl] = useState<string>('');
  const [isUploadingHtmlCode, setIsUploadingHtmlCode] = useState<boolean>(false);
  const [htmlCodeUploadError, setHtmlCodeUploadError] = useState<string>('');
  const [htmlMissingTagWarning, setHtmlMissingTagWarning] = useState<boolean>(false);

  // GITHUB BUILDER SETTINGS (PERSISTED IN LOCALSTORAGE)
  const [githubUsername, setGithubUsername] = useState(() => {
    return localStorage.getItem('dapp_github_username') || 'bimmjhi-commits';
  });
  const [githubRepo, setGithubRepo] = useState(() => {
    return localStorage.getItem('dapp_github_repo') || 'Vps-dapp-builder';
  });
  const [githubToken, setGithubToken] = useState(() => {
    return localStorage.getItem('dapp_github_token') || '';
  });
  const [imgbbApiKey, setImgbbApiKey] = useState(() => {
    return localStorage.getItem('dapp_imgbb_api_key') || '';
  });
  const [showGithubToken, setShowGithubToken] = useState(false);
  const [apkSubView, setApkSubView] = useState<'BUILD' | 'SETTINGS' | 'GUIDE'>('BUILD');

  // REAL LIVE BUILD STATES (NO FAKE PERCENTAGES / NO OVERLAY MODALS)
  const [isBuildingApk, setIsBuildingApk] = useState(false);
  const [isDownloadingApk, setIsDownloadingApk] = useState(false);
  const [lastDispatchedPayload, setLastDispatchedPayload] = useState<DispatchedPayload | null>(null);
  const [liveBuild, setLiveBuild] = useState<LiveBuildState>({
    phase: 'idle',
    dispatchStatus: 'idle',
    runId: null,
    runUrl: '',
    githubStatus: null,
    githubConclusion: null,
    artifactUrl: ''
  });
  const pollingRunTokenRef = useRef<number>(0);
  const lastDispatchContextRef = useRef<{
    username: string;
    repo: string;
    token: string;
    targetBranch: string;
    triggerTimestamp: number;
    sentAt: string;
    finalName: string;
    finalUrl: string;
    finalPkg: string;
    finalVer: string;
    finalIconUrl: string;
    finalFullscreenBoolean: boolean;
    htmlMode: 'url' | 'zip' | 'html';
    htmlUrl?: string;
    zipFileName?: string;
  } | null>(null);

  // REAL HISTORY STORAGE UNDER KEY 'dapp_history'
  const [dappHistory, setDappHistory] = useState<DappHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('dapp_history');
      if (saved) return JSON.parse(saved);
      // Migrate only real-run items from legacy key if dapp_history doesn't exist yet
      const legacy = localStorage.getItem('dapp_web_to_apk_history');
      if (legacy) {
        const parsed: WebToApkItem[] = JSON.parse(legacy);
        return parsed
          .filter((item) => typeof item.runId === 'number')
          .map((item) => ({
            id: item.id,
            app_name: item.appName,
            app_url: item.urlValue || '',
            package_name: item.packageName,
            version_name: item.version,
            icon_url: item.iconUrl || (item.logoBase64 && /^https?:\/\//i.test(item.logoBase64) ? item.logoBase64 : ''),
            fullscreen: !!item.fullscreen,
            run_id: item.runId ?? null,
            run_url: item.runUrl || '',
            status: item.status === 'Success' ? 'completed' : 'failed',
            conclusion: item.status === 'Success' ? 'success' : 'failure',
            created_at: new Date(Number(item.id) || Date.now()).toISOString(),
            artifact_url: item.apkDownloadUrl || '',
            error_message: item.errorMessage
          }));
      }
      return [];
    } catch {
      return [];
    }
  });
  const [refreshingHistoryIds, setRefreshingHistoryIds] = useState<Record<string, boolean>>({});

  useEffect(() => {
    try {
      localStorage.setItem('dapp_history', JSON.stringify(dappHistory));
    } catch {}
  }, [dappHistory]);

  const handleAppNameChange = (val: string) => {
    setApkAppName(val);
    let slug = val.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (slug && /^[0-9]/.test(slug)) {
      slug = `app${slug}`;
    }
    if (slug) {
      setApkPackageName(`com.${slug}.app`);
    } else {
      setApkPackageName('com.namamu.app');
    }
  };

  // VALIDATORS FOR WEB TO APK
  const normalizeAndValidateAppUrl = useCallback((raw: string): { valid: boolean; url: string; error?: string } => {
    let trimmed = raw.trim();
    if (!trimmed) {
      return { valid: false, url: '', error: 'App URL wajib diisi!' };
    }
    if (trimmed.toLowerCase().includes('aistudio.google.com')) {
      return {
        valid: false,
        url: trimmed,
        error: 'Link AI Studio butuh login, tidak bisa dipakai. Pakai link publik atau pakai Mode ZIP / HTML.'
      };
    }
    if (!/^https?:\/\//i.test(trimmed)) {
      trimmed = `https://${trimmed.replace(/^\/+/, '')}`;
    } else {
      trimmed = trimmed.replace(/^https:\/\//i, 'https://').replace(/^http:\/\//i, 'http://');
    }
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
        return { valid: false, url: trimmed, error: 'app_url harus diawali http:// atau https://' };
      }
      if (!parsed.hostname || (!parsed.hostname.includes('.') && parsed.hostname !== 'localhost')) {
        return { valid: false, url: trimmed, error: 'Format domain pada URL tidak valid (contoh: https://example.com).' };
      }
      return { valid: true, url: trimmed };
    } catch {
      return { valid: false, url: trimmed, error: 'Format App URL tidak valid (contoh: https://namasite.com).' };
    }
  }, []);

  const validatePackageNameFormat = useCallback((raw: string): { valid: boolean; packageName: string; error?: string } => {
    const normalized = raw.trim().toLowerCase();
    const pkgRegex = /^com\.[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
    if (!pkgRegex.test(normalized)) {
      return {
        valid: false,
        packageName: normalized,
        error: 'package_name harus format com.xxx.xxx dengan huruf kecil semua (contoh: com.tokoku.app).'
      };
    }
    return { valid: true, packageName: normalized };
  }, []);

  // CONVERT UPLOADED IMAGE TO FULL-BLEED 512x512 CENTER_CROP / COVER PNG (NO FIT/LETTERBOX/BLACK BARS)
  const prepareIconPayloadFromFile = async (
    file: File
  ): Promise<{ base64Content: string; ext: 'png' | 'jpg'; previewDataUrl: string; width: number; height: number }> => {
    if (!file.type.startsWith('image/')) {
      throw new Error('File harus berupa gambar (PNG/JPG/WEBP).');
    }
    if (file.size > 5 * 1024 * 1024) {
      throw new Error('Ukuran icon maksimal 5 MB.');
    }

    const renderSourceToFullBleed512 = (source: CanvasImageSource, origW: number, origH: number) => {
      if (origW < 2 || origH < 2) {
        throw new Error('Dimensi gambar tidak valid.');
      }
      const targetSize = 512;
      const canvas = document.createElement('canvas');
      canvas.width = targetSize;
      canvas.height = targetSize;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('Browser tidak mendukung pemrosesan icon 512x512.');
      }

      // Sample edge backdrop color (never pure #000000 or pure #FFFFFF) in case source PNG has transparency
      let fillHex = '#242428';
      try {
        const probe = document.createElement('canvas');
        probe.width = 16;
        probe.height = 16;
        const pCtx = probe.getContext('2d');
        if (pCtx) {
          pCtx.drawImage(source, 0, 0, 16, 16);
          const pixels = pCtx.getImageData(0, 0, 16, 16).data;
          let rSum = 0;
          let gSum = 0;
          let bSum = 0;
          let count = 0;
          for (let i = 0; i < pixels.length; i += 4) {
            if (pixels[i + 3] >= 200) {
              rSum += pixels[i];
              gSum += pixels[i + 1];
              bSum += pixels[i + 2];
              count++;
            }
          }
          if (count > 0) {
            const r = Math.min(242, Math.max(28, Math.round(rSum / count)));
            const g = Math.min(242, Math.max(28, Math.round(gSum / count)));
            const b = Math.min(247, Math.max(32, Math.round(bSum / count)));
            fillHex = `rgb(${r}, ${g}, ${b})`;
          }
        }
      } catch {}

      ctx.fillStyle = fillHex;
      ctx.fillRect(0, 0, targetSize, targetSize);

      // True COVER / CENTER_CROP scaling so photo fills all 4 edges without black/white bars
      const scale = Math.max(targetSize / origW, targetSize / origH);
      const drawW = Math.ceil(origW * scale);
      const drawH = Math.ceil(origH * scale);
      const dx = Math.floor((targetSize - drawW) / 2);
      const dy = Math.floor((targetSize - drawH) / 2);

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(source, dx, dy, drawW, drawH);

      const pngDataUrl = canvas.toDataURL('image/png');
      return {
        base64Content: pngDataUrl.split(',')[1],
        ext: 'png' as const,
        previewDataUrl: pngDataUrl,
        width: targetSize,
        height: targetSize
      };
    };

    // Prefer createImageBitmap with EXIF imageOrientation: 'from-image' for portrait camera photos
    if (typeof createImageBitmap === 'function') {
      try {
        const bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' });
        try {
          return renderSourceToFullBleed512(bitmap, bitmap.width, bitmap.height);
        } finally {
          bitmap.close();
        }
      } catch {
        // Fallback to HTMLImageElement below
      }
    }

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Gagal membaca file gambar dari perangkat.'));
      reader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        if (!dataUrl || !dataUrl.includes(',')) {
          reject(new Error('Data gambar tidak valid.'));
          return;
        }
        const img = new Image();
        img.onload = () => {
          try {
            resolve(renderSourceToFullBleed512(img, img.naturalWidth || 512, img.naturalHeight || 512));
          } catch {
            reject(new Error('Gagal memotong & memproses icon menjadi 512x512 fullscreen.'));
          }
        };
        img.onerror = () => reject(new Error('File gambar tidak dapat dimuat. Gunakan PNG, JPG, atau WEBP.'));
        img.src = dataUrl;
      };
      reader.readAsDataURL(file);
    });
  };

  // REAL PUBLIC IMAGE HOSTING UPLOAD (IMGBB IF KEY PROVIDED, OTHERWISE GITHUB REPO CONTENTS API)
  const uploadIconToPublicHost = async (base64Content: string, ext: 'png' | 'jpg'): Promise<string> => {
    const trimmedImgbbKey = imgbbApiKey.trim();

    if (trimmedImgbbKey) {
      const formData = new FormData();
      formData.append('image', base64Content);
      const res = await fetch(`https://api.imgbb.com/1/upload?key=${encodeURIComponent(trimmedImgbbKey)}`, {
        method: 'POST',
        body: formData
      });
      let json: any = null;
      try {
        json = await res.json();
      } catch {}
      if (!res.ok || !json?.success || !json?.data?.url) {
        const msg = json?.error?.message || `HTTP ${res.status}`;
        throw new Error(`Gagal upload icon ke ImgBB: ${msg}`);
      }
      return json.data.url as string;
    }

    const token = githubToken.trim();
    const username = githubUsername.trim() || 'bimmjhi-commits';
    const repo = githubRepo.trim() || 'Vps-dapp-builder';

    if (!token) {
      throw new Error(
        'GitHub Token belum diisi di Pengaturan Builder. Isi GitHub Token (atau ImgBB API Key) agar icon bisa diupload ke URL publik.'
      );
    }

    const uniqueName = `icon-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
    const filePath = `apk-icons/${uniqueName}`;
    const uploadEndpoint = `https://api.github.com/repos/${username}/${repo}/contents/${filePath}`;

    const res = await fetch(uploadEndpoint, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: `chore: upload app icon ${uniqueName}`,
        content: base64Content
      })
    });

    let resData: any = null;
    try {
      resData = await res.json();
    } catch {}

    if (!res.ok) {
      const ghMsg = resData?.message || `HTTP ${res.status} ${res.statusText}`;
      if (res.status === 401 || res.status === 403 || res.status === 404) {
        throw new Error(
          `Gagal upload icon ke GitHub (${res.status}): ${ghMsg}. Pastikan token memiliki izin Contents (Read & Write) / scope 'repo', atau isi ImgBB API Key di Pengaturan Builder.`
        );
      }
      throw new Error(`Gagal upload icon ke GitHub: ${ghMsg}`);
    }

    const downloadUrl: string | undefined =
      resData?.content?.download_url ||
      (resData?.content?.path
        ? `https://raw.githubusercontent.com/${username}/${repo}/main/${resData.content.path}`
        : undefined);

    if (!downloadUrl || !/^https?:\/\//i.test(downloadUrl)) {
      throw new Error('Server upload tidak mengembalikan URL publik icon_url yang valid.');
    }

    return downloadUrl;
  };

  const handleRetryPendingIconUpload = async (): Promise<string | null> => {
    if (!pendingIconUpload) return apkIconUrl || null;
    setIsUploadingIcon(true);
    setApkIconError('');
    try {
      const publicUrl = await uploadIconToPublicHost(pendingIconUpload.base64Content, pendingIconUpload.ext);
      setApkIconUrl(publicUrl);
      setApkLogoBase64(publicUrl);
      setPendingIconUpload(null);
      setApkIconError('');
      showToast('Icon berhasil diupload ke URL publik!', 'success');
      return publicUrl;
    } catch (err: any) {
      const msg = err?.message || 'Gagal mengupload icon ke server.';
      setApkIconUrl('');
      setApkIconError(msg);
      showToast(msg, 'error');
      return null;
    } finally {
      setIsUploadingIcon(false);
    }
  };

  const handleProcessIconFile = async (file: File) => {
    setApkIconError('');
    setIsUploadingIcon(true);
    setApkIconUrl('');

    try {
      const prepared = await prepareIconPayloadFromFile(file);
      setApkLogoBase64(prepared.previewDataUrl);
      setApkIconDimensions({ width: prepared.width, height: prepared.height });
      setPendingIconUpload({
        base64Content: prepared.base64Content,
        ext: prepared.ext,
        previewDataUrl: prepared.previewDataUrl
      });

      showToast('Mengupload icon ke hosting publik...', 'info');
      const publicUrl = await uploadIconToPublicHost(prepared.base64Content, prepared.ext);
      setApkIconUrl(publicUrl);
      setApkLogoBase64(publicUrl);
      setPendingIconUpload(null);
      setApkIconError('');
      showToast('Icon berhasil diupload & URL publik siap!', 'success');
    } catch (err: any) {
      const msg = err?.message || 'Gagal mengupload icon.';
      setApkIconUrl('');
      setApkIconError(msg);
      showToast(msg, 'error');
    } finally {
      setIsUploadingIcon(false);
    }
  };

  const handleClearIcon = () => {
    setApkIconUrl('');
    setApkLogoBase64('');
    setApkIconDimensions(null);
    setApkIconError('');
    setPendingIconUpload(null);
    const inputEl = document.getElementById('apkLogoFileInput') as HTMLInputElement | null;
    if (inputEl) inputEl.value = '';
    showToast('Icon dihapus (default huruf aktif)', 'info');
  };

  // MODE ZIP & MODE HTML: ENCODE + REAL UPLOAD KE GITHUB REPO
  const readFileAsBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Gagal membaca file dari perangkat.'));
      reader.onload = (ev) => {
        const result = ev.target?.result as string;
        if (!result || !result.includes(',')) {
          reject(new Error('Format isi file tidak valid untuk dibaca.'));
          return;
        }
        resolve(result.split(',')[1]);
      };
      reader.readAsDataURL(file);
    });
  };

  const encodeUtf8ToBase64 = (text: string): string => {
    const bytes = new TextEncoder().encode(text);
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  };

  const uploadSourceAssetToGitHub = async (
    base64Content: string,
    ext: 'html' | 'zip',
    origName: string
  ): Promise<string> => {
    const token = githubToken.trim();
    const username = githubUsername.trim() || 'bimmjhi-commits';
    const repo = githubRepo.trim() || 'Vps-dapp-builder';

    if (!token) {
      throw new Error(
        'GitHub Token belum diisi di Pengaturan Builder. Isi token terlebih dahulu agar file dapat diupload ke GitHub.'
      );
    }

    const safeBase =
      origName
        .replace(/\.[^.]+$/, '')
        .toLowerCase()
        .replace(/[^a-z0-9_-]/g, '-')
        .slice(0, 32) || 'app';
    const uniqueFileName = `${safeBase}-${Date.now()}.${ext}`;
    const filePath = `apk-html/${uniqueFileName}`;
    const uploadEndpoint = `https://api.github.com/repos/${username}/${repo}/contents/${filePath}`;

    const res = await fetch(uploadEndpoint, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: `chore: upload ${ext} source ${uniqueFileName}`,
        content: base64Content
      })
    });

    let resData: any = null;
    try {
      resData = await res.json();
    } catch {}

    if (!res.ok) {
      const ghMsg = resData?.message || `HTTP ${res.status} ${res.statusText}`;
      throw new Error(`Gagal upload file ${ext.toUpperCase()} ke GitHub (${res.status}): ${ghMsg}`);
    }

    const downloadUrl: string | undefined =
      resData?.content?.download_url ||
      (resData?.content?.path
        ? `https://raw.githubusercontent.com/${username}/${repo}/main/${resData.content.path}`
        : undefined);

    if (!downloadUrl || !/^https?:\/\//i.test(downloadUrl)) {
      throw new Error('GitHub API tidak mengembalikan URL publik yang valid.');
    }

    return downloadUrl;
  };

  const handleProcessZipFile = async (file: File) => {
    setZipUploadError('');
    setZipPublicUrl('');

    const lowerName = file.name.toLowerCase();
    const isZip =
      lowerName.endsWith('.zip') ||
      file.type === 'application/zip' ||
      file.type === 'application/x-zip-compressed';

    if (!isZip) {
      const msg = 'Mode ZIP hanya menerima file .zip!';
      setZipUploadError(msg);
      showToast(msg, 'error');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      const msg = 'Ukuran file ZIP melebihi batas maksimal 10 MB.';
      setZipUploadError(msg);
      showToast(msg, 'error');
      return;
    }

    try {
      const zip = await JSZip.loadAsync(file);
      const indexEntry =
        Object.values(zip.files).find((entry) => !entry.dir && entry.name.toLowerCase() === 'index.html') ||
        Object.values(zip.files).find((entry) => !entry.dir && entry.name.toLowerCase().endsWith('/index.html'));

      if (!indexEntry) {
        throw new Error('File ZIP wajib berisi index.html di dalamnya.');
      }

      const extractedIndexHtml = await indexEntry.async('string');
      const base64Content = await readFileAsBase64(file);

      setZipFileMeta({
        name: file.name,
        sizeBytes: file.size
      });
      setPendingZipUpload({
        base64Content,
        fileName: file.name,
        extractedIndexHtml
      });

      if (!apkAppName.trim()) {
        handleAppNameChange(file.name.replace(/\.[^.]+$/, ''));
      }

      if (githubToken.trim()) {
        setIsUploadingZip(true);
        try {
          const uploadedUrl = await uploadSourceAssetToGitHub(base64Content, 'zip', file.name);
          setZipPublicUrl(uploadedUrl);
          setZipUploadError('');
          showToast('File ZIP berhasil diupload ke GitHub & html_url siap!', 'success');
        } catch (uploadErr: any) {
          const msg = uploadErr?.message || 'Gagal mengupload file ZIP ke GitHub.';
          setZipPublicUrl('');
          setZipUploadError(msg);
          showToast(msg, 'error');
        } finally {
          setIsUploadingZip(false);
        }
      } else {
        showToast('File ZIP valid! Isi GitHub Token di Pengaturan Builder saat ingin Build.', 'info');
      }
    } catch (err: any) {
      const msg = err?.message || 'Gagal memproses file ZIP.';
      setZipFileMeta(null);
      setPendingZipUpload(null);
      setZipUploadError(msg);
      showToast(msg, 'error');
    }
  };

  const handleRetryZipUpload = async (): Promise<string | null> => {
    if (!pendingZipUpload) return null;
    if (zipPublicUrl) return zipPublicUrl;
    setIsUploadingZip(true);
    setZipUploadError('');
    try {
      const uploadedUrl = await uploadSourceAssetToGitHub(
        pendingZipUpload.base64Content,
        'zip',
        pendingZipUpload.fileName
      );
      setZipPublicUrl(uploadedUrl);
      setZipUploadError('');
      showToast('File ZIP berhasil diupload ke GitHub!', 'success');
      return uploadedUrl;
    } catch (err: any) {
      const msg = err?.message || 'Gagal upload file ZIP ke GitHub.';
      setZipPublicUrl('');
      setZipUploadError(msg);
      showToast(msg, 'error');
      return null;
    } finally {
      setIsUploadingZip(false);
    }
  };

  const handleClearZipFile = () => {
    setZipFileMeta(null);
    setPendingZipUpload(null);
    setZipPublicUrl('');
    setZipUploadError('');
    const inputEl = document.getElementById('apkZipFileInput') as HTMLInputElement | null;
    if (inputEl) inputEl.value = '';
    showToast('File ZIP dihapus.', 'info');
  };

  const handleHtmlCodeChange = (newCode: string) => {
    setHtmlCodeText(newCode);
    setHtmlCodePublicUrl('');
    setHtmlCodeUploadError('');
    setHtmlMissingTagWarning(false);
  };

  const handleClearHtmlCode = () => {
    setHtmlCodeText('');
    setHtmlCodePublicUrl('');
    setHtmlCodeUploadError('');
    setHtmlMissingTagWarning(false);
    showToast('Kode HTML dihapus.', 'info');
  };

  const fetchArtifactDownloadUrl = useCallback(
    async (username: string, repo: string, token: string, runId: number): Promise<string> => {
      const artifactsUrl = `https://api.github.com/repos/${username}/${repo}/actions/runs/${runId}/artifacts`;
      const artRes = await fetch(artifactsUrl, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github+json'
        }
      });
      if (!artRes.ok) return '';
      const artData = await artRes.json();
      const artifactsList: any[] = artData.artifacts || [];
      return artifactsList[0]?.archive_download_url || '';
    },
    []
  );

  // REFRESH STATUS SATU ITEM HISTORY DARI GITHUB API (REAL)
  const handleRefreshHistoryItemStatus = useCallback(
    async (item: DappHistoryItem) => {
      if (!item.run_id) return;
      const token = githubToken.trim();
      if (!token) {
        showToast('Isi GitHub Token di Pengaturan Builder untuk refresh status dari GitHub API.', 'error');
        return;
      }

      const username = githubUsername.trim() || 'bimmjhi-commits';
      const repo = githubRepo.trim() || 'Vps-dapp-builder';

      setRefreshingHistoryIds((prev) => ({ ...prev, [item.id]: true }));
      try {
        const runRes = await fetch(
          `https://api.github.com/repos/${username}/${repo}/actions/runs/${item.run_id}`,
          {
            headers: {
              'Authorization': `Bearer ${token}`,
              'Accept': 'application/vnd.github+json'
            }
          }
        );

        if (!runRes.ok) {
          throw new Error(`HTTP ${runRes.status} saat mengambil status build dari GitHub`);
        }

        const runData = await runRes.json();
        const apiStatus: string = runData.status || 'queued';
        const apiConclusion: string | null = runData.conclusion ?? null;
        let nextArtifactUrl = item.artifact_url;

        if (apiStatus === 'completed' && apiConclusion === 'success' && !nextArtifactUrl) {
          nextArtifactUrl = await fetchArtifactDownloadUrl(username, repo, token, item.run_id);
        }

        const mappedStatus: DappHistoryItem['status'] =
          apiStatus === 'completed'
            ? apiConclusion === 'success'
              ? 'completed'
              : 'failed'
            : apiStatus === 'in_progress'
            ? 'in_progress'
            : 'queued';

        setDappHistory((prev) =>
          prev.map((h) =>
            h.id === item.id
              ? {
                  ...h,
                  status: mappedStatus,
                  conclusion: apiConclusion,
                  run_url: runData.html_url || h.run_url,
                  artifact_url: nextArtifactUrl,
                  error_message:
                    mappedStatus === 'failed'
                      ? `Workflow selesai dengan conclusion: ${apiConclusion || 'failure'}`
                      : undefined
                }
              : h
          )
        );
      } catch (err: any) {
        showToast(err?.message || 'Gagal refresh status dari GitHub API.', 'error');
      } finally {
        setRefreshingHistoryIds((prev) => ({ ...prev, [item.id]: false }));
      }
    },
    [githubToken, githubUsername, githubRepo, fetchArtifactDownloadUrl]
  );

  // AUTO-REFRESH STATUS UNTUK ITEM YANG MASIH QUEUED / IN_PROGRESS SAAT BUKA HALAMAN HISTORY
  useEffect(() => {
    if (currentView !== 'APK_HISTORY') return;
    if (!githubToken.trim()) return;
    const pendingItems = dappHistory.filter(
      (item) => item.run_id && (item.status === 'queued' || item.status === 'in_progress')
    );
    if (pendingItems.length === 0) return;

    pendingItems.forEach((item) => {
      handleRefreshHistoryItemStatus(item);
    });
  }, [currentView]);

  // REAL GITHUB ACTIONS BUILD PIPELINE (NO OVERLAYS, NO FAKE TIMERS, REAL 5s POLLING)
  const handleStartRealApkBuild = async (forceIgnoreMissingHtmlTag = false) => {
    if (!githubToken.trim()) {
      showToast('Isi GitHub Token dulu di Pengaturan Builder', 'error');
      setApkSubView('SETTINGS');
      return;
    }

    if (isUploadingIcon || isUploadingZip || isUploadingHtmlCode) {
      showToast('Tunggu proses upload selesai terlebih dahulu...', 'info');
      return;
    }

    const pkgCheck = validatePackageNameFormat(apkPackageName);
    if (!pkgCheck.valid) {
      showToast(pkgCheck.error || 'Format package_name tidak valid!', 'error');
      return;
    }
    const finalPkg = pkgCheck.packageName;
    if (finalPkg !== apkPackageName) {
      setApkPackageName(finalPkg);
    }

    const finalName = apkAppName.trim() || 'Aplikasi-Ku';
    const finalVer = apkVersion.trim() || '1.0';
    const finalFullscreenBoolean = apkFullscreen;
    const finalFullscreenChoice: 'true' | 'false' = finalFullscreenBoolean ? 'true' : 'false';

    let finalUrl = '';
    let finalZipUrl = '';
    let finalHtmlCodeUrl = '';

    if (apkBuildMode === 'URL') {
      const urlCheck = normalizeAndValidateAppUrl(apkUrl);
      if (!urlCheck.valid) {
        showToast(urlCheck.error || 'App URL tidak valid!', 'error');
        return;
      }
      finalUrl = urlCheck.url;
      if (finalUrl !== apkUrl) {
        setApkUrl(finalUrl);
      }
    } else if (apkBuildMode === 'ZIP') {
      if (!zipFileMeta || !pendingZipUpload) {
        showToast('Pilih atau upload file .zip terlebih dahulu di Mode ZIP!', 'error');
        return;
      }
      finalUrl = 'file:///android_asset/index.html';
      finalZipUrl = zipPublicUrl.trim();
      if (!finalZipUrl) {
        showToast('Mengupload file ZIP ke GitHub...', 'info');
        const uploaded = await handleRetryZipUpload();
        if (!uploaded) {
          showToast('Build dibatalkan: file ZIP gagal diupload ke GitHub!', 'error');
          return;
        }
        finalZipUrl = uploaded.trim();
      }
    } else {
      // MODE HTML: PASTE SOURCE CODE
      const trimmedCode = htmlCodeText.trim();
      if (!trimmedCode) {
        const emptyMsg = 'Kode HTML masih kosong, paste dulu.';
        setHtmlCodeUploadError(emptyMsg);
        showToast(emptyMsg, 'error');
        return;
      }

      const hasHtmlTag = /<html[\s>]/i.test(trimmedCode);
      if (!hasHtmlTag && !forceIgnoreMissingHtmlTag && !htmlMissingTagWarning) {
        setHtmlMissingTagWarning(true);
        showToast('Kode tidak ada tag <html>, tetap lanjut?', 'info');
        return;
      }
      setHtmlMissingTagWarning(false);
      setHtmlCodeUploadError('');
      finalUrl = 'file:///android_asset/index.html';

      if (htmlCodePublicUrl.trim()) {
        finalHtmlCodeUrl = htmlCodePublicUrl.trim();
      } else {
        setIsUploadingHtmlCode(true);
        showToast('Mengupload source code HTML ke GitHub...', 'info');
        try {
          const base64Html = encodeUtf8ToBase64(htmlCodeText);
          const uploadedHtmlUrl = await uploadSourceAssetToGitHub(base64Html, 'html', finalName);
          setHtmlCodePublicUrl(uploadedHtmlUrl);
          finalHtmlCodeUrl = uploadedHtmlUrl;
          showToast('HTML_URL publik siap dikirim ke GitHub Actions!', 'success');
        } catch (err: any) {
          const errMsg = err?.message || 'Gagal mengupload source code HTML ke GitHub.';
          setHtmlCodePublicUrl('');
          setHtmlCodeUploadError(errMsg);
          showToast(errMsg, 'error');
          return;
        } finally {
          setIsUploadingHtmlCode(false);
        }
      }
    }

    // Validasi icon_url: jangan lanjut build diam-diam dengan icon kosong jika upload icon gagal!
    let finalIconUrl = apkIconUrl.trim();
    if (pendingIconUpload && !finalIconUrl) {
      showToast('Mengupload icon yang tertunda ke server...', 'info');
      const uploaded = await handleRetryPendingIconUpload();
      if (!uploaded) {
        showToast('Build dibatalkan: Icon gagal diupload! Periksa error icon atau hapus icon jika ingin lanjut tanpa icon.', 'error');
        return;
      }
      finalIconUrl = uploaded.trim();
    } else if (apkIconError && !finalIconUrl) {
      showToast(`Build dibatalkan karena upload icon gagal: ${apkIconError}`, 'error');
      return;
    }

    if (finalIconUrl && !/^https?:\/\//i.test(finalIconUrl)) {
      showToast('icon_url tidak valid (harus URL http:// atau https:// publik).', 'error');
      return;
    }

    const username = githubUsername.trim() || 'bimmjhi-commits';
    const repo = githubRepo.trim() || 'Vps-dapp-builder';
    const token = githubToken.trim();
    const myPollToken = Date.now();
    pollingRunTokenRef.current = myPollToken;

    setIsBuildingApk(true);
    setLiveBuild({
      phase: 'dispatching',
      dispatchStatus: 'loading',
      runId: null,
      runUrl: '',
      githubStatus: null,
      githubConclusion: null,
      artifactUrl: ''
    });

    const triggerTimestamp = Date.now();

    try {
      // Deteksi default_branch repository (fallback 'main')
      let targetBranch = 'main';
      try {
        const repoRes = await fetch(`https://api.github.com/repos/${username}/${repo}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/vnd.github+json'
          }
        });
        if (repoRes.ok) {
          const repoData = await repoRes.json();
          if (repoData?.default_branch) {
            targetBranch = repoData.default_branch;
          }
        }
      } catch {}

      const dispatchInputs: DispatchedPayload['inputs'] =
        apkBuildMode === 'ZIP'
          ? {
              app_name: finalName,
              app_url: finalUrl,
              package_name: finalPkg,
              version_name: finalVer,
              icon_url: finalIconUrl,
              fullscreen: finalFullscreenChoice,
              source_type: 'zip',
              html_url: finalZipUrl
            }
          : apkBuildMode === 'HTML'
          ? {
              app_name: finalName,
              app_url: finalUrl,
              package_name: finalPkg,
              version_name: finalVer,
              icon_url: finalIconUrl,
              fullscreen: finalFullscreenChoice,
              source_type: 'html',
              html_code_url: finalHtmlCodeUrl
            }
          : {
              app_name: finalName,
              app_url: finalUrl,
              package_name: finalPkg,
              version_name: finalVer,
              icon_url: finalIconUrl,
              fullscreen: finalFullscreenChoice,
              source_type: 'url'
            };

      const dispatchPayload: DispatchedPayload = {
        ref: targetBranch,
        inputs: dispatchInputs,
        sentAt: new Date().toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        })
      };

      console.log(
        '[WEB TO APK] Dispatching workflow_dispatch to GitHub Actions (build.yml):',
        JSON.stringify({ ref: dispatchPayload.ref, inputs: dispatchPayload.inputs }, null, 2)
      );
      setLastDispatchedPayload(dispatchPayload);

      const dispatchCtx = {
        username,
        repo,
        token,
        targetBranch,
        triggerTimestamp,
        sentAt: dispatchPayload.sentAt,
        finalName,
        finalUrl,
        finalPkg,
        finalVer,
        finalIconUrl,
        finalFullscreenBoolean,
        htmlMode: (apkBuildMode === 'ZIP' ? 'zip' : apkBuildMode === 'HTML' ? 'html' : 'url') as 'url' | 'zip' | 'html',
        htmlUrl:
          apkBuildMode === 'ZIP'
            ? finalZipUrl
            : apkBuildMode === 'HTML'
            ? finalHtmlCodeUrl
            : undefined,
        zipFileName: apkBuildMode === 'ZIP' ? zipFileMeta?.name : undefined
      };

      // Step 1: POST workflow_dispatch ke GitHub Actions
      const dispatchUrl = `https://api.github.com/repos/${username}/${repo}/actions/workflows/build.yml/dispatches`;
      const dispatchRes = await fetch(dispatchUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github+json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ref: dispatchPayload.ref,
          inputs: dispatchPayload.inputs
        })
      });

      if (!dispatchRes.ok) {
        let errMessage = `HTTP ${dispatchRes.status} ${dispatchRes.statusText}`;
        try {
          const errData = await dispatchRes.json();
          if (errData?.message) errMessage = errData.message;
        } catch {}
        setLiveBuild({
          phase: 'error',
          dispatchStatus: 'error',
          dispatchTime: dispatchPayload.sentAt,
          dispatchError: `Gagal memicu build di GitHub: ${errMessage}`,
          runId: null,
          runUrl: '',
          githubStatus: null,
          githubConclusion: null,
          runNotFoundTimeout: false,
          artifactUrl: '',
          errorMessage: errMessage
        });
        setIsBuildingApk(false);
        showToast(`Gagal memicu build di GitHub: ${errMessage}`, 'error');
        return;
      }

      lastDispatchContextRef.current = dispatchCtx;
      setLiveBuild((prev) => ({
        ...prev,
        phase: 'locating_run',
        dispatchStatus: 'success',
        dispatchTime: dispatchPayload.sentAt,
        dispatchError: undefined,
        locateElapsedSec: 0,
        runNotFoundTimeout: false,
        targetBranch,
        runUrl: `https://github.com/${username}/${repo}/actions/workflows/build.yml`
      }));

      await locateAndTrackRun(dispatchCtx, myPollToken, null);
    } catch (err: any) {
      const errMsg = err?.message || 'Terjadi kesalahan komunikasi dengan GitHub Actions API.';
      setIsBuildingApk(false);
      setLiveBuild((prev) => ({
        ...prev,
        phase: 'error',
        errorMessage: errMsg
      }));
      showToast(errMsg, 'error');
    }
  };

  // HELPER SABAR: CARI RUN BARU (TUNGGU 5s AWAL + POLLING 12x TIAP 5s = TOTAL 60s) & LANJUT TRACKING STATUS
  const locateAndTrackRun = async (
    ctx: NonNullable<typeof lastDispatchContextRef.current>,
    myPollToken: number,
    knownRunId: number | null
  ) => {
    try {
      let foundRun: any = null;

      if (knownRunId) {
        const directRes = await fetch(
          `https://api.github.com/repos/${ctx.username}/${ctx.repo}/actions/runs/${knownRunId}`,
          {
            headers: {
              'Authorization': `Bearer ${ctx.token}`,
              'Accept': 'application/vnd.github+json'
            }
          }
        );
        if (directRes.ok) {
          foundRun = await directRes.json();
        }
      } else {
        // Jangan langsung cek daftar Runs tepat setelah dispatch 204 — tunggu 5 detik dulu, lalu cek max 12x (interval 5 detik)
        let locateAttempts = 0;
        const maxLocateAttempts = 12;

        while (!foundRun && locateAttempts < maxLocateAttempts) {
          const elapsedSec = (locateAttempts + 1) * 5;
          setLiveBuild((prev) => ({
            ...prev,
            phase: 'locating_run',
            dispatchStatus: 'success',
            dispatchTime: ctx.sentAt,
            locateElapsedSec: elapsedSec,
            runNotFoundTimeout: false,
            errorMessage: undefined
          }));

          await new Promise((r) => setTimeout(r, 5000));
          if (pollingRunTokenRef.current !== myPollToken) return;
          locateAttempts++;

          const runsRes = await fetch(
            `https://api.github.com/repos/${ctx.username}/${ctx.repo}/actions/runs?per_page=5`,
            {
              headers: {
                'Authorization': `Bearer ${ctx.token}`,
                'Accept': 'application/vnd.github+json'
              }
            }
          );
          if (!runsRes.ok) continue;

          const runsData = await runsRes.json();
          const runsList: any[] = Array.isArray(runsData.workflow_runs) ? runsData.workflow_runs : [];

          const matchesRun = runsList.filter((r) => {
            const runCreated = new Date(r.created_at).getTime();
            const isDispatchEvent = r.event === 'workflow_dispatch';
            const isTargetBranch =
              r.head_branch === ctx.targetBranch || r.head_branch === 'main';
            const isAfterTrigger = runCreated >= ctx.triggerTimestamp - 2000;
            return isDispatchEvent && isTargetBranch && isAfterTrigger;
          });

          foundRun =
            matchesRun.find(
              (r) => r.path?.includes('build.yml') || r.name?.toLowerCase().includes('build')
            ) || matchesRun[0] || null;
        }
      }

      if (!foundRun) {
        setIsBuildingApk(false);
        setLiveBuild((prev) => ({
          ...prev,
          phase: 'error',
          dispatchStatus: 'success',
          runNotFoundTimeout: true,
          runUrl: `https://github.com/${ctx.username}/${ctx.repo}/actions/workflows/build.yml`,
          errorMessage: 'GitHub masih memproses, cek di Lihat Log / buka GitHub Actions manual'
        }));
        showToast('GitHub masih memproses, cek di Lihat Log atau klik Cek Lagi.', 'info');
        return;
      }

      const runId: number = foundRun.id;
      const historyId = `run_${runId}`;
      let latestRun = foundRun;

      const mapStatus = (apiStatus: string, apiConclusion: string | null): DappHistoryItem['status'] => {
        if (apiStatus === 'completed') return apiConclusion === 'success' ? 'completed' : 'failed';
        if (apiStatus === 'in_progress') return 'in_progress';
        return 'queued';
      };

      const initialHistoryItem: DappHistoryItem = {
        id: historyId,
        app_name: ctx.finalName,
        app_url: ctx.finalUrl,
        package_name: ctx.finalPkg,
        version_name: ctx.finalVer,
        icon_url: ctx.finalIconUrl,
        fullscreen: ctx.finalFullscreenBoolean,
        html_mode: ctx.htmlMode,
        html_url: ctx.htmlUrl,
        html_file_name: ctx.zipFileName,
        run_id: runId,
        run_url: latestRun.html_url || '',
        status: mapStatus(latestRun.status, latestRun.conclusion ?? null),
        conclusion: latestRun.conclusion ?? null,
        created_at: latestRun.created_at || new Date().toISOString(),
        artifact_url: ''
      };

      setDappHistory((prev) => [initialHistoryItem, ...prev.filter((h) => h.id !== historyId)]);
      setLiveBuild((prev) => ({
        ...prev,
        phase: latestRun.status === 'completed' ? 'completed' : 'polling',
        dispatchStatus: 'success',
        dispatchTime: ctx.sentAt,
        runId,
        runUrl: latestRun.html_url || '',
        runNotFoundTimeout: false,
        errorMessage: undefined,
        githubStatus:
          latestRun.status === 'completed'
            ? 'completed'
            : latestRun.status === 'in_progress'
            ? 'in_progress'
            : 'queued',
        githubConclusion: latestRun.conclusion ?? null,
        lastPolledAt: new Date().toLocaleTimeString('id-ID')
      }));

      // Step 3: Polling langsung ke GET /repos/{owner}/{repo}/actions/runs/{run_id} tiap 5 detik sampai status = completed
      let pollAttempts = 0;
      const maxPollAttempts = 120; // 10 menit
      while (latestRun.status !== 'completed' && pollAttempts < maxPollAttempts) {
        await new Promise((r) => setTimeout(r, 5000));
        if (pollingRunTokenRef.current !== myPollToken) return;
        pollAttempts++;

        const runRes = await fetch(
          `https://api.github.com/repos/${ctx.username}/${ctx.repo}/actions/runs/${runId}`,
          {
            headers: {
              'Authorization': `Bearer ${ctx.token}`,
              'Accept': 'application/vnd.github+json'
            }
          }
        );
        if (!runRes.ok) continue;

        latestRun = await runRes.json();
        const pollTimeStr = new Date().toLocaleTimeString('id-ID');
        const nextMappedStatus = mapStatus(latestRun.status, latestRun.conclusion ?? null);

        setLiveBuild((prev) => ({
          ...prev,
          phase: latestRun.status === 'completed' ? 'completed' : 'polling',
          runUrl: latestRun.html_url || prev.runUrl,
          githubStatus:
            latestRun.status === 'completed'
              ? 'completed'
              : latestRun.status === 'in_progress'
              ? 'in_progress'
              : 'queued',
          githubConclusion: latestRun.conclusion ?? null,
          lastPolledAt: pollTimeStr
        }));

        setDappHistory((prev) =>
          prev.map((h) =>
            h.id === historyId
              ? {
                  ...h,
                  status: nextMappedStatus,
                  conclusion: latestRun.conclusion ?? null,
                  run_url: latestRun.html_url || h.run_url
                }
              : h
          )
        );
      }

      if (latestRun.status !== 'completed') {
        throw new Error('Polling timeout setelah 10 menit. Periksa status build langsung di GitHub.');
      }

      // Step 4: Jika completed & success, ambil artifact download URL
      if (latestRun.conclusion === 'success') {
        const artifactUrl = await fetchArtifactDownloadUrl(ctx.username, ctx.repo, ctx.token, runId);
        setLiveBuild((prev) => ({
          ...prev,
          phase: 'completed',
          githubStatus: 'completed',
          githubConclusion: 'success',
          artifactUrl
        }));
        setDappHistory((prev) =>
          prev.map((h) =>
            h.id === historyId
              ? {
                  ...h,
                  status: 'completed',
                  conclusion: 'success',
                  artifact_url: artifactUrl,
                  run_url: latestRun.html_url || h.run_url
                }
              : h
          )
        );
        setIsBuildingApk(false);
        showToast('Build APK di GitHub Actions selesai (success)!', 'success');
      } else {
        const errDetail = `Workflow selesai dengan conclusion: ${latestRun.conclusion || 'failure'}.`;
        setLiveBuild((prev) => ({
          ...prev,
          phase: 'completed',
          githubStatus: 'completed',
          githubConclusion: latestRun.conclusion || 'failure',
          errorMessage: errDetail
        }));
        setDappHistory((prev) =>
          prev.map((h) =>
            h.id === historyId
              ? {
                  ...h,
                  status: 'failed',
                  conclusion: latestRun.conclusion || 'failure',
                  error_message: errDetail,
                  run_url: latestRun.html_url || h.run_url
                }
              : h
          )
        );
        setIsBuildingApk(false);
        showToast(`Build di GitHub Gagal: ${latestRun.conclusion || 'failure'}`, 'error');
      }
    } catch (err: any) {
      const errMsg = err?.message || 'Terjadi kesalahan komunikasi dengan GitHub Actions API.';
      setIsBuildingApk(false);
      setLiveBuild((prev) => ({
        ...prev,
        phase: 'error',
        errorMessage: errMsg
      }));
      showToast(errMsg, 'error');
    }
  };

  // CEK LAGI DAFTAR RUNS / STATUS RUN YANG SUDAH ADA (TANPA KIRIM DISPATCH DUPLIKAT)
  const handleRecheckExistingRun = async () => {
    const ctx = lastDispatchContextRef.current;
    if (!ctx) {
      showToast('Belum ada data pengiriman build sebelumnya.', 'info');
      return;
    }

    const myPollToken = Date.now();
    pollingRunTokenRef.current = myPollToken;
    setIsBuildingApk(true);
    setLiveBuild((prev) => ({
      ...prev,
      phase: prev.runId ? 'polling' : 'locating_run',
      dispatchStatus: 'success',
      runNotFoundTimeout: false,
      errorMessage: undefined
    }));
    showToast(
      liveBuild.runId
        ? `Mengecek ulang status RUN #${liveBuild.runId}...`
        : `Mengecek ulang daftar Runs sejak ${ctx.sentAt}...`,
      'info'
    );

    await locateAndTrackRun(ctx, myPollToken, liveBuild.runId);
  };

  // UNDUH FILE .APK BENERAN DARI ARTIFACT GITHUB
  const handleDownloadRealApk = async (artifactDownloadUrl?: string, customAppName?: string, fallbackRunUrl?: string) => {
    if (!artifactDownloadUrl) {
      showToast('Tautan artifact unduhan tidak ditemukan.', 'error');
      if (fallbackRunUrl) {
        window.open(fallbackRunUrl, '_blank');
      }
      return;
    }

    setIsDownloadingApk(true);
    showToast('Mengunduh berkas artifact dari GitHub Actions...', 'info');

    try {
      const res = await fetch(artifactDownloadUrl, {
        headers: {
          'Authorization': `Bearer ${githubToken.trim()}`,
          'Accept': 'application/vnd.github+json'
        }
      });

      if (!res.ok) {
        throw new Error(`Gagal mengunduh artifact (HTTP ${res.status}). Silakan unduh langsung dari log GitHub.`);
      }

      const zipBlob = await res.blob();
      const zip = await JSZip.loadAsync(zipBlob);

      // Cari berkas berekstensi .apk di dalam zip artifact
      const apkEntry = Object.values(zip.files).find((f) => f.name.toLowerCase().endsWith('.apk') && !f.dir);
      const fileNameBase = (customAppName || apkAppName || 'app').replace(/[^a-zA-Z0-9_-]/g, '_');

      if (apkEntry) {
        showToast('Mengekstrak file .apk dari artifact...', 'info');
        const apkBlob = await apkEntry.async('blob');
        const blobUrl = URL.createObjectURL(new Blob([apkBlob], { type: 'application/vnd.android.package-archive' }));
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = `${fileNameBase}.apk`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
        showToast('File .apk beneran berhasil diunduh!', 'success');
      } else {
        const zipUrl = URL.createObjectURL(zipBlob);
        const a = document.createElement('a');
        a.href = zipUrl;
        a.download = `${fileNameBase}-build.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(zipUrl);
        showToast('Artifact ZIP berhasil diunduh!', 'success');
      }
    } catch (err: any) {
      showToast(err.message || 'Gagal mengunduh via API. Membuka halaman GitHub Actions...', 'error');
      if (fallbackRunUrl) {
        window.open(fallbackRunUrl, '_blank');
      }
    } finally {
      setIsDownloadingApk(false);
    }
  };

  const handleDownloadHistoryItemApk = async (item: DappHistoryItem) => {
    let urlToDownload = item.artifact_url;
    if (!urlToDownload && item.run_id && githubToken.trim()) {
      const username = githubUsername.trim() || 'bimmjhi-commits';
      const repo = githubRepo.trim() || 'Vps-dapp-builder';
      urlToDownload = await fetchArtifactDownloadUrl(username, repo, githubToken.trim(), item.run_id);
      if (urlToDownload) {
        setDappHistory((prev) =>
          prev.map((h) => (h.id === item.id ? { ...h, artifact_url: urlToDownload } : h))
        );
      }
    }
    await handleDownloadRealApk(urlToDownload, item.app_name, item.run_url);
  };

  const handleSaveAsZipCurrent = async () => {
    const finalName = apkAppName.trim() || 'Aplikasi-Ku';
    const finalPkg = apkPackageName.trim() || 'com.namamu.app';
    const finalVer = apkVersion.trim() || '1.0';
    const zip = new JSZip();

    const normalizedUrl = apkUrl.trim() ? normalizeAndValidateAppUrl(apkUrl).url : '';
    const htmlContent =
      apkBuildMode === 'HTML' && htmlCodeText.trim()
        ? htmlCodeText
        : apkBuildMode === 'ZIP' && pendingZipUpload?.extractedIndexHtml
        ? pendingZipUpload.extractedIndexHtml
        : normalizedUrl
        ? `<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=${normalizedUrl}"><title>${finalName}</title></head><body><script>window.location.href="${normalizedUrl}";</script></body></html>`
        : `<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${finalName}</title></head><body><h1>${finalName}</h1></body></html>`;
    zip.file('index.html', htmlContent);

    const readmeTxt = `NAMA: ${finalName}
PACKAGE: ${finalPkg}
VERSI: ${finalVer}
MODE: ${apkBuildMode}
URL: ${apkBuildMode === 'URL' ? normalizedUrl || '-' : 'file:///android_asset/index.html'}
HTML_URL: ${zipPublicUrl || htmlCodePublicUrl || '-'}
ICON_URL: ${apkIconUrl || '(kosong)'}
GITHUB BUILDER: ${githubUsername}/${githubRepo} (build.yml)
LAYAR PENUH: ${apkFullscreen ? 'ON' : 'OFF'}`;
    zip.file('README.txt', readmeTxt);

    const content = await zip.generateAsync({ type: 'blob' });
    const blobUrl = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = `${finalName.replace(/[^a-zA-Z0-9_-]/g, '_')}-project.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(blobUrl);
    showToast('Project ZIP berhasil diunduh!', 'success');
  };

  const handleDeleteApkHistory = (id: string) => {
    setDappHistory((prev) => prev.filter((x) => x.id !== id));
    showToast('Aplikasi dihapus dari riwayat.', 'info');
  };

  // DAPP DOWNLOADER MODULE STATE
  const [selectedPlatform, setSelectedPlatform] = useState<string>('youtube');
  const [mediaUrl, setMediaUrl] = useState('');
  const [selectedFormat, setSelectedFormat] = useState<'mp4' | 'mp3' | 'm4a' | 'webm'>('mp4');
  const [selectedQuality, setSelectedQuality] = useState<'1080p' | '720p' | '480p' | '320kbps'>('1080p');

  const downloaderPlatforms = [
    {
      id: 'youtube',
      name: 'YOUTUBE',
      placeholder: 'Tempel Link YouTube...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
        </svg>
      )
    },
    {
      id: 'tiktok',
      name: 'TIKTOK',
      placeholder: 'Tempel Link TikTok...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.82.56-1.31 1.53-1.3 2.52.01 1.04.57 2.03 1.46 2.55.85.5 1.94.57 2.82.18.9-.38 1.57-1.22 1.73-2.18.12-1.32.06-2.65.07-3.98.01-4.22 0-8.44.02-12.66z" />
        </svg>
      )
    },
    {
      id: 'instagram',
      name: 'INSTAGRAM',
      placeholder: 'Tempel Link Instagram...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-none stroke-current stroke-2" viewBox="0 0 24 24">
          <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
          <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
        </svg>
      )
    },
    {
      id: 'facebook',
      name: 'FACEBOOK',
      placeholder: 'Tempel Link Facebook...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      )
    },
    {
      id: 'x',
      name: 'X',
      placeholder: 'Tempel Link X / Twitter...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
      )
    },
    {
      id: 'spotify',
      name: 'SPOTIFY',
      placeholder: 'Tempel Link Spotify...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M12 0C5.376 0 0 5.376 0 12s5.376 12 12 12 12-5.376 12-12S18.624 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.899 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.019zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141 C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.18-1.2-.18-1.38-.72-.18-.6.18-1.2.72-1.38 4.26-1.26 11.28-1.02 15.72 1.62.54.3.72 1.02.42 1.56-.3.42-1.02.6-1.56.3z"/>
        </svg>
      )
    },
    {
      id: 'pinterest',
      name: 'PINTEREST',
      placeholder: 'Tempel Link Pinterest...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M12 0C5.373 0 0 5.372 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/>
        </svg>
      )
    },
    {
      id: 'capcut',
      name: 'CAPCUT',
      placeholder: 'Tempel Link CapCut...',
      iconColor: 'text-[var(--nb-ink)]',
      icon: (
        <svg className="w-5 h-5 fill-none stroke-current stroke-2 stroke-linecap-round stroke-linejoin-round" viewBox="0 0 24 24">
          <circle cx="6" cy="6" r="3" />
          <circle cx="6" cy="18" r="3" />
          <line x1="20" y1="4" x2="8.12" y2="15.88" />
          <line x1="14.47" y1="14.47" x2="20" y2="20" />
          <line x1="8.12" y1="8.12" x2="12" y2="12" />
        </svg>
      )
    }
  ];

  const downloadProgressSteps = [
    'Menghubungkan ke Endpoint Server...',
    'Memproses Header & Format Media...',
    'Mengekstrak Stream Audio / Video...',
    'Menyiapkan Tautan Unduhan...'
  ];

  const [isDownloadingMedia, setIsDownloadingMedia] = useState(false);
  const [downloadStepIdx, setDownloadStepIdx] = useState(0);
  const [downloadStatus, setDownloadStatus] = useState<'idle' | 'running' | 'success' | 'failed'>('idle');
  const [downloadErrorMsg, setDownloadErrorMsg] = useState<string | null>(null);
  const [latestDownloadItem, setLatestDownloadItem] = useState<DownloadItem | null>(null);
  const [apiDownloadResult, setApiDownloadResult] = useState<ApiDownloadResult | null>(null);
  const [selectedQualityIdx, setSelectedQualityIdx] = useState<number>(0);
  const [endpointTestResults, setEndpointTestResults] = useState<Record<string, EndpointTestResult>>({});
  const [endpointTestingMap, setEndpointTestingMap] = useState<Record<string, boolean>>({});

  const [downloadHistory, setDownloadHistory] = useState<DownloadItem[]>(() => {
    const saved = localStorage.getItem('dapp_downloads');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('dapp_downloads', JSON.stringify(downloadHistory));
  }, [downloadHistory]);

  // ENDPOINTS MAP STATE (LOCALSTORAGE: 'dapp_endpoints' + 'endpoint_<platform>')
  const platformIds = ['youtube', 'tiktok', 'instagram', 'facebook', 'x', 'spotify', 'pinterest', 'capcut'];

  const syncIndividualEndpointKeys = (map: PlatformEndpointsMap) => {
    try {
      platformIds.forEach((pid) => {
        const val = map[pid]?.url?.trim() || '';
        if (val) {
          localStorage.setItem(`endpoint_${pid}`, val);
        } else {
          localStorage.removeItem(`endpoint_${pid}`);
        }
      });
    } catch {}
  };

  const [endpointsMap, setEndpointsMap] = useState<PlatformEndpointsMap>(() => {
    try {
      const saved = localStorage.getItem('dapp_endpoints');
      const parsed = saved ? JSON.parse(saved) : {};
      const result: PlatformEndpointsMap = {};
      platformIds.forEach((pid) => {
        const directKeyVal = localStorage.getItem(`endpoint_${pid}`);
        const url = directKeyVal !== null ? directKeyVal : (parsed[pid]?.url || '');
        result[pid] = {
          url,
          active: typeof parsed[pid]?.active === 'boolean' ? parsed[pid].active : Boolean(url.trim())
        };
      });
      return result;
    } catch {}

    const initial: PlatformEndpointsMap = {};
    platformIds.forEach((pid) => {
      initial[pid] = { url: '', active: false };
    });
    return initial;
  });

  useEffect(() => {
    localStorage.setItem('dapp_endpoints', JSON.stringify(endpointsMap));
    syncIndividualEndpointKeys(endpointsMap);
  }, [endpointsMap]);

  const handleToggleEndpoint = (pid: string, platName: string) => {
    setEndpointsMap((prev) => {
      const current = prev[pid] || { url: '', active: false };

      if (!current.active && !current.url.trim()) {
        showToast(`Endpoint ${platName} masih kosong, isi dulu`, 'error');
        return prev;
      }

      const nextActive = !current.active;
      showToast(
        nextActive ? `Endpoint ${platName} telah DIAKTIFKAN! ✅` : `Endpoint ${platName} DINONAKTIFKAN`,
        nextActive ? 'success' : 'info'
      );

      return {
        ...prev,
        [pid]: {
          ...current,
          active: nextActive
        }
      };
    });
  };

  const handleSaveEndpoint = (pid: string, platName: string) => {
    const current = endpointsMap[pid] || { url: '', active: false };
    if (!current.url.trim() && current.active) {
      setEndpointsMap((prev) => ({
        ...prev,
        [pid]: { ...prev[pid], active: false }
      }));
    }
    localStorage.setItem('dapp_endpoints', JSON.stringify(endpointsMap));
    syncIndividualEndpointKeys(endpointsMap);
    showToast(`Endpoint ${platName} berhasil disimpan! 💾`, 'success');
  };

  const handleTestEndpoint = async (pid: string, platName: string) => {
    // 1. Read real-time from localStorage 'dapp_endpoints'
    let currentMap: PlatformEndpointsMap = endpointsMap;
    try {
      const saved = localStorage.getItem('dapp_endpoints');
      if (saved) {
        currentMap = JSON.parse(saved);
      }
    } catch {}

    const config = currentMap[pid] || { url: '', active: false };
    const nowTimeStr = new Date().toLocaleTimeString('id-ID', { hour12: false });

    // If toggle = OFF / active = false
    if (!config.active) {
      setEndpointTestResults((prev) => ({
        ...prev,
        [pid]: {
          status: 'FALSE_INACTIVE',
          message: `Endpoint ${platName} tidak aktif. Toggle masih OFF, endpoint tidak akan dipakai di Downloader. Klik toggle ON untuk mengaktifkan.`,
          lastCheckedTime: nowTimeStr
        }
      }));
      return;
    }

    const urlTrimmed = config.url.trim();

    // Validate URL format (must start with http:// or https://)
    if (!urlTrimmed || (!urlTrimmed.startsWith('http://') && !urlTrimmed.startsWith('https://'))) {
      setEndpointTestResults((prev) => ({
        ...prev,
        [pid]: {
          status: 'FALSE_INVALID_URL',
          message: 'URL endpoint tidak valid. Harus diawali http:// atau https://',
          lastCheckedTime: nowTimeStr
        }
      }));
      return;
    }

    // Set testing in progress for this pid
    setEndpointTestingMap((prev) => ({ ...prev, [pid]: true }));

    const startTime = performance.now();
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 seconds timeout

    try {
      const response = await fetch(urlTrimmed, {
        method: 'GET',
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      const elapsedMs = Math.round(performance.now() - startTime);

      if (response.ok) {
        // Check if JSON response format
        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          setEndpointTestResults((prev) => ({
            ...prev,
            [pid]: {
              status: 'TRUE_ACTIVE',
              message: 'Endpoint siap dipakai di Downloader.',
              responseTimeMs: elapsedMs,
              httpStatus: response.status,
              lastCheckedTime: nowTimeStr
            }
          }));
        } else {
          setEndpointTestResults((prev) => ({
            ...prev,
            [pid]: {
              status: 'TRUE_NON_JSON',
              message: 'Server hidup tapi responnya bukan format downloader yang diharapkan.',
              responseTimeMs: elapsedMs,
              httpStatus: response.status,
              lastCheckedTime: nowTimeStr
            }
          }));
        }
      } else {
        setEndpointTestResults((prev) => ({
          ...prev,
          [pid]: {
            status: 'FALSE_ERROR',
            message: `Endpoint gagal merespon: HTTP ${response.status} ${response.statusText}`,
            responseTimeMs: elapsedMs,
            httpStatus: response.status,
            lastCheckedTime: nowTimeStr
          }
        }));
      }
    } catch (err: any) {
      clearTimeout(timeoutId);
      const elapsedMs = Math.round(performance.now() - startTime);
      const errMessage = err.name === 'AbortError' ? 'Timeout 8s (Waktu tunggu habis)' : (err.message || 'Network Error / CORS Error');

      setEndpointTestResults((prev) => ({
        ...prev,
        [pid]: {
          status: 'FALSE_ERROR',
          message: `Endpoint gagal merespon: ${errMessage}`,
          responseTimeMs: elapsedMs,
          lastCheckedTime: nowTimeStr
        }
      }));
    } finally {
      setEndpointTestingMap((prev) => ({ ...prev, [pid]: false }));
    }
  };

  const handleSaveAllEndpoints = () => {
    localStorage.setItem('dapp_endpoints', JSON.stringify(endpointsMap));
    syncIndividualEndpointKeys(endpointsMap);
    showToast('Semua Settings Endpoint Berhasil Disimpan! 💾', 'success');
  };

  const handleResetAllEndpoints = () => {
    const resetObj: PlatformEndpointsMap = {};
    platformIds.forEach((pid) => {
      resetObj[pid] = { url: '', active: false };
      localStorage.removeItem(`endpoint_${pid}`);
    });
    setEndpointsMap(resetObj);
    localStorage.setItem('dapp_endpoints', JSON.stringify(resetObj));
    showToast('Semua Endpoint dan Toggle telah Direset! 🔄', 'info');
  };

  const activeEndpointsCount = Object.values(endpointsMap).filter(
    (ep) => ep.active && ep.url.trim().length > 0
  ).length;

  const handleStartDownload = async () => {
    if (!mediaUrl.trim()) {
      showToast('Masukkan URL / Link media terlebih dahulu!', 'error');
      return;
    }

    const currentPlatformObj = downloaderPlatforms.find((p) => p.id === selectedPlatform) || downloaderPlatforms[0];

    // Selalu baca endpoint real-time dari Settings (localStorage 'endpoint_<platform>' / 'dapp_endpoints')
    let latestEndpointsMap: PlatformEndpointsMap = endpointsMap;
    try {
      const saved = localStorage.getItem('dapp_endpoints');
      if (saved) {
        latestEndpointsMap = JSON.parse(saved);
      }
    } catch {}

    const directEndpoint = localStorage.getItem(`endpoint_${selectedPlatform}`) || '';
    const epConfig = latestEndpointsMap[selectedPlatform];
    const rawEndpoint = (directEndpoint || epConfig?.url || '').trim();

    if (!rawEndpoint) {
      const errorMsg = 'Endpoint belum diisi di Settings';
      showToast(errorMsg, 'error');
      setIsDownloadingMedia(false);
      setDownloadStatus('failed');
      setDownloadErrorMsg(errorMsg);
      setApiDownloadResult(null);
      setTimeout(() => {
        const el = document.getElementById('downloader-status');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
      return;
    }

    if (!rawEndpoint.startsWith('http://') && !rawEndpoint.startsWith('https://')) {
      const errorMsg = 'URL endpoint di Settings tidak valid. Harus diawali http:// atau https://';
      showToast(errorMsg, 'error');
      setIsDownloadingMedia(false);
      setDownloadStatus('failed');
      setDownloadErrorMsg(errorMsg);
      setApiDownloadResult(null);
      return;
    }

    setIsDownloadingMedia(true);
    setDownloadStatus('running');
    setDownloadErrorMsg(null);
    setApiDownloadResult(null);

    setTimeout(() => {
      const el = document.getElementById('downloader-status');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);

    try {
      const encodedTarget = encodeURIComponent(mediaUrl.trim());
      let fetchUrl = '';

      if (rawEndpoint.includes('{url}')) {
        fetchUrl = rawEndpoint
          .replace('{url}', encodedTarget)
          .replace('{format}', selectedFormat)
          .replace('{platform}', selectedPlatform);
      } else if (rawEndpoint.endsWith('=')) {
        fetchUrl = `${rawEndpoint}${encodedTarget}`;
      } else if (/([?&])url=/.test(rawEndpoint)) {
        fetchUrl = rawEndpoint.replace(/([?&])url=[^&]*/, `$1url=${encodedTarget}`);
      } else {
        const connector = rawEndpoint.includes('?') ? '&' : '?';
        fetchUrl = `${rawEndpoint}${connector}url=${encodedTarget}`;
      }

      const response = await fetch(fetchUrl);

      if (!response.ok) {
        throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type') || '';
      const rawBodyText = await response.text();
      let parsedJson: any = null;

      if (contentType.includes('application/json') || rawBodyText.trim().startsWith('{') || rawBodyText.trim().startsWith('[')) {
        try {
          parsedJson = JSON.parse(rawBodyText);
        } catch {
          parsedJson = null;
        }
      }

      let parsedResult: ApiDownloadResult = { links: [] };

      if (parsedJson !== null) {
        const json = parsedJson;

        if ((typeof json.code === 'number' && json.code !== 0) || json.status === 'error' || json.status === false || json.ok === false || json.error) {
          const msg = json.msg || json.message || json.error || 'API mengembalikan status gagal';
          throw new Error(String(msg));
        }

        const rootData = (json.data && typeof json.data === 'object' && !Array.isArray(json.data))
          ? json.data
          : (json.result && typeof json.result === 'object' && !Array.isArray(json.result))
          ? json.result
          : json;

        const rawTitle = rootData.title || rootData.video_title || rootData.desc || rootData.name || json.title || '';
        const title = typeof rawTitle === 'string' ? rawTitle : String(rawTitle || '');

        const rawAuthor = rootData.author || rootData.uploader || rootData.creator || rootData.channel || rootData.artist || json.author;
        const author = typeof rawAuthor === 'string'
          ? rawAuthor
          : rawAuthor && typeof rawAuthor === 'object'
          ? String(rawAuthor.nickname || rawAuthor.name || rawAuthor.username || rawAuthor.unique_id || '')
          : '';

        const rawDuration = rootData.duration ?? rootData.length ?? json.duration;
        const duration = typeof rawDuration === 'number'
          ? `${rawDuration}s`
          : typeof rawDuration === 'string'
          ? rawDuration
          : '';

        const thumbnail = rootData.thumbnail || rootData.cover || rootData.origin_cover || rootData.image || rootData.pic || json.thumbnail || '';

        const rawLinks = rootData.links || rootData.qualities || rootData.downloads || rootData.urls || rootData.medias || rootData.formats || json.links || json.qualities || json.downloads || json.medias || [];

        let linksList: Array<{ quality: string; url: string; size?: string; format?: string }> = [];
        const addUniqueLink = (quality: string, urlVal?: string, sizeVal?: string, fmtVal?: string) => {
          if (!urlVal || typeof urlVal !== 'string' || !urlVal.startsWith('http')) return;
          if (!linksList.some((item) => item.url === urlVal)) {
            linksList.push({
              quality: quality || 'Original',
              url: urlVal,
              size: sizeVal || '',
              format: fmtVal || selectedFormat
            });
          }
        };

        if (Array.isArray(rawLinks) && rawLinks.length > 0) {
          rawLinks.forEach((item: any) => {
            if (typeof item === 'string') {
              addUniqueLink('Original', item);
            } else if (item && typeof item === 'object') {
              addUniqueLink(
                item.quality || item.resolution || item.label || item.format || item.ext || 'Original',
                item.url || item.download_url || item.link,
                item.size || item.formattedSize || item.fileSize || item.filesize || '',
                item.format || item.ext || selectedFormat
              );
            }
          });
        } else if (typeof rawLinks === 'object' && rawLinks !== null && !Array.isArray(rawLinks)) {
          Object.entries(rawLinks).forEach(([key, val]) => {
            if (typeof val === 'string') {
              addUniqueLink(key, val);
            } else if (typeof val === 'object' && val !== null && (val as any).url) {
              addUniqueLink((val as any).quality || key, (val as any).url, (val as any).size || '');
            }
          });
        }

        // Support direct response fields (TikWM, generic media downloaders, etc.)
        const isAudioSelected = selectedFormat === 'mp3' || selectedFormat === 'm4a';
        const musicUrl = rootData.audio_url || rootData.music || rootData.music_info?.play || rootData.audio || json.audio_url || json.music;

        if (isAudioSelected && musicUrl) {
          addUniqueLink(selectedFormat.toUpperCase(), musicUrl, '', selectedFormat);
        }

        addUniqueLink('HD (No Watermark)', rootData.hdplay || json.hdplay);
        addUniqueLink('No Watermark', rootData.play || rootData.nowm || rootData.no_watermark || json.play);
        addUniqueLink('With Watermark', rootData.wmplay || json.wmplay);
        addUniqueLink('Video', rootData.video_url || rootData.preview_url || rootData.stream_url || json.video_url);
        addUniqueLink('Download', rootData.download_url || rootData.url || json.download_url || json.url);

        if (!isAudioSelected && musicUrl) {
          addUniqueLink('Audio MP3', musicUrl, '', 'mp3');
        }

        const previewUrl = isAudioSelected
          ? (musicUrl || linksList[0]?.url || '')
          : (rootData.video_url || rootData.hdplay || rootData.play || rootData.nowm || rootData.preview_url || rootData.stream_url || rootData.wmplay || rootData.url || json.video_url || json.url || linksList[0]?.url || '');

        parsedResult = {
          title,
          author,
          duration,
          thumbnail,
          previewUrl: previewUrl || (linksList[0]?.url || ''),
          mediaType: isAudioSelected ? 'audio' : 'video',
          links: linksList
        };
      } else if (contentType.includes('text/html')) {
        throw new Error('Endpoint mengembalikan halaman HTML, bukan data JSON atau file media.');
      } else {
        parsedResult = {
          title: `${currentPlatformObj.name}_Media`,
          previewUrl: fetchUrl,
          mediaType: selectedFormat === 'mp3' || selectedFormat === 'm4a' ? 'audio' : 'video',
          links: [{ quality: 'Original', url: fetchUrl }]
        };
      }

      if (parsedResult.links.length === 0 && !parsedResult.previewUrl) {
        throw new Error('API tidak mengembalikan tautan unduhan yang valid.');
      }

      setApiDownloadResult(parsedResult);
      setSelectedQualityIdx(0);
      setDownloadStatus('success');
      showToast('Berhasil mendapatkan data media dari server! ⬇️', 'success');

      const firstLink = parsedResult.links[0]?.url || parsedResult.previewUrl || mediaUrl;
      const newItem: DownloadItem = {
        id: 'dl_' + Date.now(),
        title: parsedResult.title || `${currentPlatformObj.name}_Media`,
        url: mediaUrl,
        format: selectedFormat,
        quality: parsedResult.links[0]?.quality || 'Original',
        fileSize: parsedResult.links[0]?.size || '-',
        date: getTodayDateStr(),
        status: 'completed',
        downloadUrl: firstLink,
        thumbnail: parsedResult.thumbnail || undefined
      };
      setLatestDownloadItem(newItem);
      setDownloadHistory((prev) => [newItem, ...prev]);

    } catch (err: any) {
      const errorMsg = err.message || 'Gagal terhubung ke endpoint API.';
      setDownloadStatus('failed');
      setDownloadErrorMsg(errorMsg);
      setApiDownloadResult(null);
      showToast(`Gagal: ${errorMsg}`, 'error');
    } finally {
      setIsDownloadingMedia(false);
    }
  };

  const handleClearDownloadHistory = () => {
    if (downloadHistory.length === 0) {
      showToast('Tidak ada history download untuk dihapus.', 'info');
      return;
    }
    setDownloadHistory([]);
    localStorage.removeItem('dapp_downloads');
    showToast('Semua History Download telah dihapus!', 'success');
  };

  // Deployment Execution Step-By-Step State & Status
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployStep, setDeployStep] = useState(0);
  const [deployStatus, setDeployStatus] = useState<'idle' | 'running' | 'success' | 'failed'>('idle');
  const [deployErrorMsg, setDeployErrorMsg] = useState<string | null>(null);
  const [deployFailedStep, setDeployFailedStep] = useState<number | null>(null);
  const [deployLogs, setDeployLogs] = useState<string[]>([]);
  const [latestDeployedItem, setLatestDeployedItem] = useState<DeploymentItem | null>(null);

  // Polling Status Text (Logika 4)
  const [pollStatusText, setPollStatusText] = useState<string>('');

  // Auto-Scroll and Active Loading Progress Text
  const [loadingProgressIdx, setLoadingProgressIdx] = useState(0);

  const progressLoadingSteps = [
    'Mengupload file berkas project...',
    'Memvalidasi integritas HTML & konfigurasi...',
    'Menyiapkan subdomain & project di Vercel...',
    'Mengirim payload deployment ke Vercel...',
    'Menyinkronkan routing server & DNS...',
    'Memverifikasi sertifikat SSL HTTPS...',
    'Menyelesaikan link deploy...'
  ];

  useEffect(() => {
    if (isDeploying && deployStatus === 'running') {
      const interval = setInterval(() => {
        setLoadingProgressIdx((prev) => (prev + 1) % progressLoadingSteps.length);
      }, 800);
      return () => clearInterval(interval);
    } else {
      setLoadingProgressIdx(0);
    }
  }, [isDeploying, deployStatus, progressLoadingSteps.length]);

  const scrollToDeployStatus = () => {
    setTimeout(() => {
      const el = document.getElementById('deploy-status');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 60);
  };

  useEffect(() => {
    if (isDeploying) {
      scrollToDeployStatus();
    }
  }, [isDeploying]);

  // Token Verification Status (Logika 2 - Vercel)
  interface TokenVerificationStatus {
    checked: boolean;
    valid: boolean;
    accountName?: string;
    error?: string;
  }

  const [tokenVerification, setTokenVerification] = useState<TokenVerificationStatus>(() => {
    const saved = localStorage.getItem('dapp_token_verification');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.Vercel && typeof parsed.Vercel.checked === 'boolean') {
          return parsed.Vercel;
        }
        if (parsed && typeof parsed.checked === 'boolean') {
          return parsed;
        }
      } catch {}
    }
    return { checked: false, valid: false };
  });

  useEffect(() => {
    if (tokenVerification) {
      localStorage.setItem('dapp_token_verification', JSON.stringify({ Vercel: tokenVerification }));
    }
  }, [tokenVerification]);

  // Project Conflict Modal State (Logika 1)
  const [conflictModal, setConflictModal] = useState<{
    isOpen: boolean;
    projectName: string;
    existingInfo: {
      name: string;
      date: string;
      projectId?: string;
    };
    cachedRawCode: string;
  } | null>(null);

  // History Delete Modal State (Logika 5)
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    item: DeploymentItem;
    isDeleting?: boolean;
  } | null>(null);

  // Drag Highlights
  const [isDragging, setIsDragging] = useState(false);

  // History Search
  const [searchQuery, setSearchQuery] = useState('');

  // Selected File Information Helper (Indicator File Terpilih)
  let selectedFileName = '';
  let selectedFileSizeKb = '';
  if (uploadedZipFile) {
    selectedFileName = uploadedZipFile.name;
    selectedFileSizeKb = (uploadedZipFile.size / 1024).toFixed(1) + ' KB';
  } else if (uploadedHtmlFile) {
    selectedFileName = uploadedHtmlFile.name;
    selectedFileSizeKb = (uploadedHtmlFile.size / 1024).toFixed(1) + ' KB';
  } else if (pastedHtmlCode.trim()) {
    selectedFileName = 'kode-html-tempel.html';
    selectedFileSizeKb = (new Blob([pastedHtmlCode]).size / 1024).toFixed(1) + ' KB';
  }
  const hasSelectedFile = Boolean(selectedFileName);

  const handleResetFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setUploadedZipFile(null);
    setUploadedHtmlFile(null);
    setPastedHtmlCode('');
    const input = document.getElementById('mainFileInput') as HTMLInputElement | null;
    if (input) input.value = '';
    showToast('File telah dihapus. Silakan pilih file baru.', 'info');
  };

  // User Token Validation & Active Token Resolution
  const vercelStatus = validateVercelTokenSecurity(user.vercelToken);
  const activeUserToken = user.vercelToken.trim();
  const hasValidToken = vercelStatus.valid;

  // Logika 2: Token Vercel must be checked and valid to enable deploy
  const isTokenCheckedAndValid = Boolean(tokenVerification?.checked && tokenVerification?.valid);

  const handleSlugify = (val: string) => {
    const slug = val.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-');
    setProjectName(slug);
  };

  // LOGIKA 2: CEK TOKEN DENGAN API RESMI VERCEL
  const handleVerifyToken = async () => {
    const token = user.vercelToken.trim();
    if (!token) {
      setTokenVerification({ checked: true, valid: false, error: 'Token belum diisi. Masukkan token Vercel Anda.' });
      showToast('Masukkan token Vercel terlebih dahulu!', 'error');
      return;
    }

    setIsTestingPing(true);
    showToast('Memeriksa token Vercel...', 'info');

    try {
      const res = await fetch('https://api.vercel.com/v2/user', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.user) {
        const accountName = data.user.name || data.user.username || data.user.email || 'Vercel User';
        setTokenVerification({ checked: true, valid: true, accountName });
        showToast(`✅ Token Aktif - Akun: ${accountName}`, 'success');
      } else {
        setTokenVerification({ checked: true, valid: false, error: 'Token Salah / Expired. Cek lagi token kamu.' });
        showToast('❌ Token Salah / Expired. Cek lagi token kamu.', 'error');
      }
    } catch {
      setTokenVerification({ checked: true, valid: false, error: 'Token Salah / Expired. Cek lagi token kamu.' });
      showToast('❌ Token Salah / Expired. Cek lagi token kamu.', 'error');
    } finally {
      setIsTestingPing(false);
    }
  };

  const handleVercelTokenChange = (val: string) => {
    const updatedUser = { ...user, vercelToken: val };
    setUser(updatedUser);
    localStorage.setItem('dapp_user', JSON.stringify(updatedUser));
    setTokenVerification({ checked: false, valid: false });
  };

  // CLEAR HISTORY
  const handleClearAllHistory = () => {
    if (deployments.length === 0) {
      showToast('Riwayat deployment sudah kosong.', 'info');
      setDrawerOpen(false);
      return;
    }
    setDeployments([]);
    localStorage.removeItem('dapp_deployments');
    showToast('Semua riwayat deployment telah dihapus!', 'success');
    setDrawerOpen(false);
  };

  // EXPORT HISTORY TO JSON
  const handleExportHistory = () => {
    if (deployments.length === 0) {
      showToast('Tidak ada riwayat untuk diekspor.', 'info');
      return;
    }
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(deployments, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `dapp_project_history_${getTodayDateStr()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Riwayat deployment berhasil diekspor ke JSON!', 'success');
  };

  // LOGIKA 3: CEK FILE SEBELUM DEPLOY
  const validateFileBeforeDeploy = async (): Promise<{ valid: boolean; rawCode: string; error?: string }> => {
    // 1. Cek ketiadaan file
    if (!uploadedZipFile && !uploadedHtmlFile && !pastedHtmlCode.trim()) {
      return { valid: false, rawCode: '', error: 'Pilih file dulu bro!' };
    }

    // 2. Cek ukuran file 0 KB / kosong
    if (uploadedHtmlFile && uploadedHtmlFile.size === 0) {
      return { valid: false, rawCode: '', error: 'File kamu kosong (0 KB), tidak bisa di-deploy.' };
    }
    if (uploadedZipFile && uploadedZipFile.size === 0) {
      return { valid: false, rawCode: '', error: 'File kamu kosong (0 KB), tidak bisa di-deploy.' };
    }
    if (!uploadedHtmlFile && !uploadedZipFile && pastedHtmlCode.trim().length === 0) {
      return { valid: false, rawCode: '', error: 'File kamu kosong (0 KB), tidak bisa di-deploy.' };
    }

    // 3. Cek ukuran file > 10 MB (10 * 1024 * 1024 bytes)
    const MAX_SIZE = 10 * 1024 * 1024;
    if (uploadedHtmlFile && uploadedHtmlFile.size > MAX_SIZE) {
      return { valid: false, rawCode: '', error: 'File terlalu besar, maksimal 10 MB.' };
    }
    if (uploadedZipFile && uploadedZipFile.size > MAX_SIZE) {
      return { valid: false, rawCode: '', error: 'File terlalu besar, maksimal 10 MB.' };
    }
    if (pastedHtmlCode && new Blob([pastedHtmlCode]).size > MAX_SIZE) {
      return { valid: false, rawCode: '', error: 'File terlalu besar, maksimal 10 MB.' };
    }

    // 4. Cek ekstensi file bukan .html / .zip atau kode tidak mengandung tag <html> atau <div>
    if (uploadedHtmlFile) {
      const lowerName = uploadedHtmlFile.name.toLowerCase();
      if (!lowerName.endsWith('.html') && !lowerName.endsWith('.htm')) {
        return { valid: false, rawCode: '', error: 'File ini bukan HTML. Cek lagi file kamu.' };
      }
      const text = await uploadedHtmlFile.text();
      if (!/<html[\s>]|<div[\s>]|<body[\s>]|<!doctype/i.test(text)) {
        return { valid: false, rawCode: '', error: 'File ini bukan HTML. Cek lagi file kamu.' };
      }
      return { valid: true, rawCode: text };
    }

    if (pastedHtmlCode.trim()) {
      if (!/<html[\s>]|<div[\s>]/i.test(pastedHtmlCode)) {
        return { valid: false, rawCode: '', error: 'File ini bukan HTML. Cek lagi file kamu.' };
      }
      return { valid: true, rawCode: pastedHtmlCode };
    }

    if (uploadedZipFile) {
      const lowerName = uploadedZipFile.name.toLowerCase();
      if (!lowerName.endsWith('.zip')) {
        return { valid: false, rawCode: '', error: 'File ini bukan HTML. Cek lagi file kamu.' };
      }

      // 5. Cek di dalam ZIP harus ada index.html
      try {
        const zip = await JSZip.loadAsync(uploadedZipFile);
        const files = Object.keys(zip.files);
        const hasIndexHtml = files.some((fname) => /(^|\/)index\.html?$/i.test(fname) && !zip.files[fname].dir);
        if (!hasIndexHtml) {
          return { valid: false, rawCode: '', error: 'Di dalam ZIP tidak ada index.html' };
        }
        const indexKey = files.find((fname) => /(^|\/)index\.html?$/i.test(fname) && !zip.files[fname].dir);
        const extractedHtml = indexKey ? await zip.files[indexKey].async('string') : '';
        return { valid: true, rawCode: extractedHtml };
      } catch (err: any) {
        return { valid: false, rawCode: '', error: `Di dalam ZIP tidak ada index.html (${err.message || 'File ZIP rusak'})` };
      }
    }

    return { valid: false, rawCode: '', error: 'Pilih file dulu bro!' };
  };

  // LOGIKA 1: CEK NAMA PROJECT SUDAH DIPAKAI SEBELUM DEPLOY
  // LOGIKA 1: CEK NAMA PROJECT SUDAH DIPAKAI SEBELUM DEPLOY
  const checkProjectConflictBeforeDeploy = async (slug: string) => {
    const token = user.vercelToken.trim();
    if (!token) return { conflict: false };

    try {
      const res = await fetch(`https://api.vercel.com/v9/projects/${slug}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        const dateStr = data.updatedAt
          ? new Date(data.updatedAt).toLocaleDateString('id-ID', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
          : (data.createdAt ? new Date(data.createdAt).toLocaleDateString('id-ID', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Tidak diketahui');
        return {
          conflict: true,
          existingInfo: {
            name: data.name || slug,
            date: dateStr,
            projectId: data.id
          }
        };
      }
    } catch {
      // network or other error, assume not conflict
    }

    return { conflict: false };
  };

  // LOGIKA 1 - TIMPA & HAPUS YANG LAMA
  const handleOverwriteConflict = async () => {
    if (!conflictModal) return;
    const { projectName: slug, cachedRawCode } = conflictModal;
    setConflictModal(null);
    showToast(`Menghapus project lama '${slug}' di Vercel...`, 'info');

    const token = user.vercelToken.trim();

    try {
      const delRes = await fetch(`https://api.vercel.com/v9/projects/${slug}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!delRes.ok && delRes.status !== 404) {
        const d = await delRes.json().catch(() => ({}));
        throw new Error(d.error?.message || `Gagal menghapus project lama (${delRes.status})`);
      }

      // Hapus deployment lama dari history lokal jika ada
      setDeployments((prev) => prev.filter((d) => d.projectName.toLowerCase() !== slug.toLowerCase()));
      showToast(`Project lama '${slug}' dihapus. Menjalankan deployment baru...`, 'success');

      // Lanjutkan deploy file baru dengan nama yang sama (bypass conflict check)
      executeDeployment(slug, cachedRawCode);
    } catch (err: any) {
      showToast(`Gagal menghapus project lama: ${err.message}`, 'error');
    }
  };

  // LOGIKA 1 - GANTI NAMA JADI [nama-project]-v2
  const handleRenameConflict = () => {
    if (!conflictModal) return;
    const newName = `${conflictModal.projectName}-v2`;
    const cachedCode = conflictModal.cachedRawCode;
    setConflictModal(null);
    setProjectName(newName);
    showToast(`Nama diubah jadi '${newName}'. Memulai deploy...`, 'info');
    setTimeout(() => {
      executeDeployment(newName, cachedCode);
    }, 250);
  };

  // LOGIKA 5 - HAPUS PROJECT DARI HISTORY & API RESMI
  const handleDeleteHistoryConfirm = async (mode: 'history_only' | 'delete_remote') => {
    if (!deleteModal) return;
    const { item } = deleteModal;
    const token = user.vercelToken.trim();

    if (mode === 'history_only') {
      setDeployments((prev) => prev.filter((d) => d.id !== item.id));
      setDeleteModal(null);
      showToast('Project dihapus dari riwayat aplikasi.', 'info');
      return;
    }

    // mode === 'delete_remote'
    setDeleteModal((prev) => (prev ? { ...prev, isDeleting: true } : null));

    try {
      const res = await fetch(`https://api.vercel.com/v9/projects/${item.projectName}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok && res.status !== 404) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error?.message || `API Vercel error (${res.status})`);
      }
      showToast('Project berhasil dihapus dari Vercel', 'success');

      setDeployments((prev) => prev.filter((d) => d.id !== item.id));
      setDeleteModal(null);
    } catch (err: any) {
      showToast(`Gagal menghapus di server: ${err.message}`, 'error');
      setDeleteModal(null);
    }
  };

  // START DEPLOYMENT ORCHESTRATION (CEK TOKEN -> CEK FILE -> CEK NAMA CONFLICT -> EXECUTE DEPLOY)
  const handleStartDeployment = async () => {
    if (!projectName.trim()) {
      showToast('Harap masukkan nama project!', 'error');
      return;
    }

    // LOGIKA 2: Jangan izinkan tombol DEPLOY jika token belum dicek dan belum valid
    if (!isTokenCheckedAndValid) {
      showToast(`Cek Token Dulu di Pengaturan!`, 'error');
      setCurrentView('SETTINGS');
      return;
    }

    // LOGIKA 3: Validasi file sebelum deploy
    const fileValidation = await validateFileBeforeDeploy();
    if (!fileValidation.valid) {
      showToast(fileValidation.error || 'File tidak valid!', 'error');
      return;
    }

    const cleanSlug = projectName.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-');

    // LOGIKA 1: Cek nama project sudah dipakai atau belum
    showToast(`Memeriksa ketersediaan nama '${cleanSlug}' di Vercel...`, 'info');
    const conflictRes = await checkProjectConflictBeforeDeploy(cleanSlug);
    if (conflictRes.conflict && conflictRes.existingInfo) {
      setConflictModal({
        isOpen: true,
        projectName: cleanSlug,
        existingInfo: conflictRes.existingInfo,
        cachedRawCode: fileValidation.rawCode
      });
      return;
    }

    // Lolos semua pengecekan, lanjutkan deployment
    executeDeployment(cleanSlug, fileValidation.rawCode);
  };

  // EXECUTE DEPLOYMENT WITH REAL POLLING STATUS (LOGIKA 4)
  const executeDeployment = async (cleanSlug: string, validatedRawCode: string) => {
    const deployStartTime = Date.now();
    setIsDeploying(true);
    setDeployStatus('running');
    setDeployErrorMsg(null);
    setDeployFailedStep(null);
    setDeployStep(1);
    setPollStatusText('');
    setLatestDeployedItem(null);
    scrollToDeployStatus();

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const finalSourceType = uploadedZipFile ? 'ZIP' : uploadedHtmlFile ? 'HTML_FILE' : 'PASTE_HTML';

    const initialLogs: string[] = [
      `[${nowStr.split(' ')[1]}:01] Memulai deployment resmi ke ${platform}...`,
      `[${nowStr.split(' ')[1]}:02] Langkah 1: Validasi berkas project & otentikasi...`
    ];
    setDeployLogs(initialLogs);

    try {
      // -------------------------------------------------------------
      // LANGKAH 1: Validasi berkas project
      // -------------------------------------------------------------
      setDeployStep(1);
      await new Promise((resolve) => setTimeout(resolve, 500));

      const finalHtml = protectAndEncodeHtml(
        validatedRawCode || `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${cleanSlug}</title></head><body><h1>${cleanSlug} Live</h1></body></html>`,
        protectionMode,
        enableWatermark ? watermarkOwner : undefined
      );

      setDeployLogs((prev) => [
        ...prev,
        `[${nowStr.split(' ')[1]}:03] Validasi lolos (${protectionMode === 'ENCRYPT_CODE' ? 'Terkunci / Encrypted' : 'Polos / No Enc'}).`
      ]);

      // -------------------------------------------------------------
      // LANGKAH 2: Upload file ke Vercel / Netlify
      // -------------------------------------------------------------
      setDeployStep(2);
      setDeployLogs((prev) => [
        ...prev,
        `[${nowStr.split(' ')[1]}:04] Langkah 2: Menyiapkan project & upload file ke Vercel...`
      ]);

      let deployedUrl = '';
      let deploymentId = '';

      // Buat project di Vercel
      try {
        const projRes = await fetch('https://api.vercel.com/v9/projects', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${activeUserToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: cleanSlug,
            framework: null
          })
        });

        if (!projRes.ok && projRes.status !== 409) {
          const projData = await projRes.json().catch(() => ({}));
          if (projRes.status === 400 && /already in use|taken|conflict/i.test(JSON.stringify(projData))) {
            setDeployFailedStep(2);
            throw new Error('Nama project sudah dipakai, coba nama lain');
          }
        }
      } catch (projErr: any) {
        if (projErr.message && projErr.message.includes('sudah dipakai')) {
          setDeployFailedStep(2);
          throw projErr;
        }
      }

      await new Promise((resolve) => setTimeout(resolve, 600));

      // -------------------------------------------------------------
      // LANGKAH 3: Membuat deployment & Polling status beneran
      // -------------------------------------------------------------
      setDeployStep(3);
      setDeployLogs((prev) => [
        ...prev,
        `[${nowStr.split(' ')[1]}:06] Langkah 3: Mengirim file ke Vercel...`
      ]);

      const deployRes = await fetch('https://api.vercel.com/v13/deployments', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${activeUserToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: cleanSlug,
          project: cleanSlug,
          target: 'production',
          files: [{ file: 'index.html', data: finalHtml }],
          projectSettings: { framework: null }
        })
      });

      const deployData = await deployRes.json().catch(() => ({}));
      if (!deployRes.ok) {
        setDeployFailedStep(3);
        if (deployRes.status === 409 || /already in use|already taken|conflict/i.test(JSON.stringify(deployData))) {
          throw new Error('Nama project sudah dipakai, coba nama lain');
        }
        throw new Error(deployData.error?.message || deployData.message || `API Vercel (${deployRes.status}): Gagal deployment`);
      }

      deploymentId = deployData.id;
      deployedUrl = `https://${cleanSlug}.vercel.app`;

      // LOGIKA 4: POLLING STATUS DEPLOYMENT SETIAP 3 DETIK (SAMPAI READY)
      let isReady = deployData.readyState === 'READY';
      let elapsedSeconds = 0;
      const maxWaitSeconds = 60;

      while (!isReady && elapsedSeconds < maxWaitSeconds) {
        const statusText = `⏳ Menunggu Vercel membangun website... Status: BUILDING (${elapsedSeconds}s)`;
        setPollStatusText(statusText);
        setDeployLogs((prev) => [
          ...prev,
          `[${new Date().toISOString().substring(11, 19)}] ${statusText}`
        ]);

        await new Promise((r) => setTimeout(r, 3000));
        elapsedSeconds += 3;

        try {
          const checkRes = await fetch(`https://api.vercel.com/v13/deployments/${deploymentId}`, {
            headers: { 'Authorization': `Bearer ${activeUserToken}` }
          });
          if (checkRes.ok) {
            const checkData = await checkRes.json();
            const state = (checkData.readyState || checkData.status || '').toUpperCase();
            if (state === 'READY') {
              isReady = true;
              break;
            } else if (state === 'ERROR' || state === 'CANCELED' || state === 'FAILED') {
              setDeployFailedStep(3);
              throw new Error(checkData.errorMessage || checkData.error?.message || `Vercel deployment gagal (Status: ${state})`);
            }
          }
        } catch (pollErr: any) {
          if (pollErr.message && pollErr.message.includes('gagal')) throw pollErr;
        }
      }

      if (!isReady && elapsedSeconds >= maxWaitSeconds) {
        setPollStatusText('Masih dibangun, coba buka link dalam 1 menit.');
        setDeployLogs((prev) => [
          ...prev,
          `[${new Date().toISOString().substring(11, 19)}] ℹ️ Masih dibangun, coba buka link dalam 1 menit.`
        ]);
      }

      // -------------------------------------------------------------
      // LANGKAH 4: Membuat link deploy (Sukses)
      // -------------------------------------------------------------
      setDeployStep(4);
      setPollStatusText('');
      setDeployLogs((prev) => [
        ...prev,
        `[${nowStr.split(' ')[1]}:08] Langkah 4: Menerbitkan link deploy pendek: ${deployedUrl}`,
        `[${nowStr.split(' ')[1]}:09] Status: DEPLOY BERHASIL ✅`
      ]);

      // Minimal 1.5 detik loading delay agar transisi ke sukses terasa natural
      const elapsed = Date.now() - deployStartTime;
      if (elapsed < 1600) {
        await new Promise((resolve) => setTimeout(resolve, 1600 - elapsed));
      }
      setDeployStatus('success');

      const newItem: DeploymentItem = {
        id: `dep-${Date.now()}`,
        projectName: cleanSlug,
        platform: platform,
        tokenTypeUsed: 'personal',
        date: nowStr,
        status: 'Success',
        url: deployedUrl,
        sourceType: finalSourceType,
        fileName: uploadedZipFile?.name || uploadedHtmlFile?.name || 'index.html',
        encryptedMode: protectionMode,
        logs: [
          ...initialLogs,
          `[${nowStr.split(' ')[1]}:05] File berhasil diupload`,
          `[${nowStr.split(' ')[1]}:07] Status READY terverifikasi`,
          `[${nowStr.split(' ')[1]}:09] URL pendek: ${deployedUrl}`
        ]
      };

      setDeployments((prev) => [newItem, ...prev]);
      setLatestDeployedItem(newItem);

      showToast(`Website ${cleanSlug} DEPLOY BERHASIL! 🎉`, 'success');
    } catch (err: any) {
      const errorMsg = err.message || 'Terjadi kesalahan saat deployment.';
      setDeployStatus('failed');
      setDeployErrorMsg(errorMsg);
      showToast(`Deployment Gagal: ${errorMsg}`, 'error');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast('Disalin ke clipboard!', 'success');
  };

  const filteredDeployments = deployments.filter((d) =>
    d.projectName.toLowerCase().includes(searchQuery.toLowerCase()) || d.url.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Soft Minimalist Light Background (#EEF0F5)
  const mainBgClass = 'nb-page-bg';

  return (
    <div className={`min-h-screen ${mainBgClass} relative flex flex-col`}>

      {/* INITIAL OUTER SPACE + GLASS VIDEO LOADING SCREEN */}
      {showLoadingScreen && (
        <div
          id="loadingScreen"
          className={`fixed inset-0 z-[9999] bg-[#020108] overflow-hidden flex items-center justify-center p-4 transition-opacity duration-500 ease-in-out ${
            loadingFadeOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
          }`}
        >
          {/* 2 NEBULA BLURS */}
          <div className="pointer-events-none absolute -top-24 -left-24 w-80 h-80 rounded-full bg-[#FF6B00]/15 blur-[110px]" />
          <div className="pointer-events-none absolute -bottom-24 -right-24 w-96 h-96 rounded-full bg-[#7C3AED]/15 blur-[120px]" />

          {/* 100 TWINKLING STARS */}
          {spaceStars.map((star) => (
            <span
              key={star.id}
              className="space-star"
              style={{
                left: star.left,
                top: star.top,
                width: `${star.size}px`,
                height: `${star.size}px`,
                backgroundColor: star.color,
                animationDuration: star.duration,
                animationDelay: star.delay
              }}
            />
          ))}

          {/* SHOOTING STARS */}
          <span
            className="space-shooting-star"
            style={{ top: '14%', right: '10%', animationDelay: '0.4s', animationDuration: '5.5s' }}
          />
          <span
            className="space-shooting-star"
            style={{ top: '38%', right: '-5%', animationDelay: '2.8s', animationDuration: '7s' }}
          />

          {/* CENTER GLASS PANEL */}
          <div
            className="relative z-10 flex flex-col gap-4"
            style={{
              width: '340px',
              maxWidth: '90vw',
              padding: '20px',
              background: 'rgba(255, 255, 255, 0.08)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              borderRadius: '24px',
              boxShadow: '0 20px 60px rgba(0, 0, 0, 0.6)'
            }}
          >
            {/* a. VIDEO BANNER */}
            <div
              style={{
                width: '100%',
                aspectRatio: '16 / 9',
                borderRadius: '16px',
                overflow: 'hidden',
                border: '1px solid rgba(255, 255, 255, 0.15)',
                background: 'rgba(0, 0, 0, 0.5)'
              }}
            >
              <video
                ref={loadingVideoRef}
                autoPlay
                playsInline
                src={activeLoadingVideoSrc}
                onTimeUpdate={handleVideoTimeUpdate}
                onEnded={triggerCloseLoading}
                className="w-full h-full object-cover"
              />
            </div>

            {/* b. TEKS DI BAWAH VIDEO */}
            <div className="text-center space-y-1">
              <div className="text-xl font-black tracking-[2px] uppercase text-white">
                DAPP <span className="text-[#FF8A00]">PROJECT</span>
              </div>
              <p className="text-[11px] font-bold tracking-[1.5px] uppercase text-[#B0B0B0]">
                MEMUAT APLIKASI...
              </p>
            </div>

            {/* c. PROGRESS BAR INSIDE PANEL */}
            <div className="space-y-2">
              <div
                style={{
                  width: '100%',
                  height: '8px',
                  background: 'rgba(255, 255, 255, 0.15)',
                  borderRadius: '999px',
                  overflow: 'hidden'
                }}
              >
                <div
                  style={{
                    width: `${loadingProgress}%`,
                    height: '100%',
                    borderRadius: '999px',
                    background: 'linear-gradient(90deg, #FF6B00, #FF8A00)',
                    boxShadow: '0 0 14px rgba(255, 107, 0, 0.75)'
                  }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] font-bold text-[#B0B0B0] tabular-nums">
                <span>
                  {loadingProgress < 40
                    ? 'Memuat Deployer...'
                    : loadingProgress < 90
                    ? 'Memuat Downloader...'
                    : 'Siap!'}
                </span>
                <span className="text-[#FF8A00] font-black">{Math.round(loadingProgress)}%</span>
              </div>
            </div>
          </div>

          {/* TOMBOL SKIP DI BAWAH KANAN */}
          <button
            type="button"
            onClick={triggerCloseLoading}
            className="absolute bottom-5 right-5 sm:bottom-7 sm:right-7 z-20 px-4 py-2 sm:px-5 sm:py-2.5 rounded-full flex items-center gap-2 text-xs font-extrabold uppercase tracking-[1.5px] text-white bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 backdrop-blur-md transition-all shadow-[0_8px_30px_rgba(0,0,0,0.6)] cursor-pointer select-none group"
            title="Lewati loading screen"
            aria-label="Skip Loading Screen"
          >
            <span>SKIP</span>
            <SkipForward className="w-3.5 h-3.5 text-[#FF8A00] transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>
      )}

      {/* TOAST FEEDBACK NOTIFICATION */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3 rounded-[16px] bg-white border border-[#F0F0F0] text-[#111111] shadow-[0_8px_28px_rgba(0,0,0,0.08)] animate-in fade-in slide-in-from-top-2">
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-[#FF3B30] shrink-0" />}
          {toast.type === 'error' && <XCircle className="w-4 h-4 text-[#FF3B30] shrink-0" />}
          {toast.type === 'info' && <AlertCircle className="w-4 h-4 text-[#111111] shrink-0" />}
          <span className="text-xs font-bold tracking-[0.5px]">{toast.message}</span>
        </div>
      )}

      {/* HEADER BAR (SOFT MINIMALIST LIGHT UI) */}
      <header className="nb-header px-4 md:px-8 py-3.5 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3.5">
          <button
            onClick={() => setDrawerOpen(true)}
            className="w-11 h-11 rounded-[14px] transition-all border border-[#F0F0F0] bg-white text-[#111111] shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:bg-[#FAFAFC] active:scale-95 flex items-center justify-center shrink-0 cursor-pointer"
            title={appLang === 'en' ? 'Open Dashboard Menu' : 'Buka Menu Drawer Dashboard'}
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="select-none">
            <div className="flex items-center gap-1.5 leading-none">
              <span className="text-[24px] sm:text-[26px] font-black tracking-[1.5px] uppercase text-[#111111]">
                DAPP
              </span>
              <span className="text-[24px] sm:text-[26px] font-black tracking-[1.5px] uppercase text-[#FF3B30]">
                PROJECT
              </span>
            </div>
            <p className="text-[11px] text-[#8A8A8E] tracking-[2px] font-normal mt-0.5">
              Soft • Fast • Powerful
            </p>
          </div>
        </div>

        {/* POJOK KANAN ATAS: 2 IKON MINIMALIST PUTIH */}
        <div className="flex items-center gap-2 select-none">
          <div
            title={appLang === 'en' ? 'Fast' : 'Cepat'}
            className="w-10 h-10 rounded-[12px] bg-[#FF3B30] text-white flex items-center justify-center shrink-0 cursor-default pointer-events-none select-none shadow-[0_6px_16px_rgba(255,59,48,0.22)]"
          >
            <Zap className="w-[18px] h-[18px] text-white" />
          </div>

          <div
            title={appLang === 'en' ? 'Secure' : 'Aman'}
            className="w-10 h-10 rounded-[12px] border border-[#F0F0F0] bg-white text-[#FF3B30] flex items-center justify-center shrink-0 cursor-default pointer-events-none select-none shadow-[0_4px_14px_rgba(0,0,0,0.04)]"
          >
            <ShieldCheck className="w-[18px] h-[18px]" />
          </div>
        </div>
      </header>

      {/* ACCORDION DASHBOARD DRAWER (SOFT MINIMALIST WHITE) */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex p-2.5 sm:p-3.5">
          <div className="fixed inset-0 bg-black/25" onClick={() => setDrawerOpen(false)} />

          <div className="relative nb-drawer w-full max-w-[290px] sm:max-w-xs h-full flex flex-col z-10 overflow-hidden animate-in slide-in-from-left duration-200">
            
            {/* DRAWER BODY */}
            <div className="p-4 sm:p-5 flex-1 overflow-y-auto space-y-4">
              
              {/* BAGIAN ATAS: JUDUL & CLOSE */}
              <div className="flex items-center justify-between pb-3.5 border-b border-[#F0F0F0]">
                <div>
                  <div className="flex items-center gap-1.5 leading-none">
                    <span className="font-black text-lg tracking-[1.2px] text-[#111111] uppercase">DAPP</span>
                    <span className="font-black text-lg tracking-[1.2px] text-[#FF3B30] uppercase">
                      PROJECT
                    </span>
                  </div>
                  <p className="text-[10px] text-[#8A8A8E] tracking-[1.5px] font-normal mt-0.5">
                    Soft • Fast • Powerful
                  </p>
                </div>
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="w-9 h-9 rounded-[12px] border border-[#F0F0F0] bg-[#F7F8FC] text-[#111111] hover:bg-[#FFE9E9] hover:text-[#FF3B30] active:scale-95 transition-all flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* JUDUL KECIL: TOOLS */}
              <div className="pt-1">
                <span className="text-[11px] font-bold uppercase tracking-[1.5px] text-[#8A8A8E] block px-1">
                  TOOLS
                </span>
              </div>

              {/* ACCORDION 1: DEPLOYER */}
              <div className="space-y-1.5">
                {(() => {
                  const isDeployerSection =
                    currentView === 'DEPLOY' ||
                    currentView === 'SETTINGS' ||
                    currentView === 'HISTORY' ||
                    currentView === 'GUIDE' ||
                    openToolAccordion === 'deployer';
                  return (
                    <button
                      type="button"
                      onClick={() => toggleAccordion('deployer')}
                      className={`w-full px-4 py-3 rounded-[14px] flex items-center justify-between text-xs font-bold uppercase tracking-[1px] transition-colors cursor-pointer ${
                        isDeployerSection
                          ? 'bg-[#FFE9E9] text-[#FF3B30]'
                          : 'bg-[#F8F9FC] text-[#111111] hover:bg-[#F1F3F8]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <UploadCloud className={`w-4 h-4 shrink-0 ${isDeployerSection ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                        <span>DEPLOYER</span>
                      </div>
                      <ChevronRight
                        className={`w-4 h-4 transition-transform duration-200 ${
                          isDeployerSection ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'
                        } ${openToolAccordion === 'deployer' ? 'rotate-90' : 'rotate-0'}`}
                      />
                    </button>
                  );
                })()}

                {/* SUB-MENU ACCORDION 1: DEPLOYER */}
                <div
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${
                    openToolAccordion === 'deployer' ? 'max-h-96 opacity-100 mt-1.5' : 'max-h-0 opacity-0 mt-0'
                  }`}
                >
                  <div className="space-y-1.5 text-xs font-semibold pl-2.5 border-l border-[#F0F0F0] py-1">
                    <button
                      type="button"
                      onClick={() => {
                        goToPage('DEPLOY');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'DEPLOY'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <UploadCloud className={`w-4 h-4 shrink-0 ${currentView === 'DEPLOY' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span>Buat Deploy Baru</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        goToPage('SETTINGS');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'SETTINGS'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <Sliders className={`w-4 h-4 shrink-0 ${currentView === 'SETTINGS' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span>Settings Endpoint</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        goToPage('GUIDE');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'GUIDE'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <BookOpen className={`w-4 h-4 shrink-0 ${currentView === 'GUIDE' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span>Cara Penggunaan</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        goToPage('HISTORY');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'HISTORY'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <History className={`w-4 h-4 shrink-0 ${currentView === 'HISTORY' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span>Lihat History Deploy</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* ACCORDION 2: DOWNLOADER */}
              <div className="space-y-1.5">
                {(() => {
                  const isDownloaderSection =
                    currentView === 'DOWNLOADER' ||
                    currentView === 'DOWNLOADER_SETTINGS' ||
                    currentView === 'DOWNLOADER_HISTORY' ||
                    currentView === 'DOWNLOADER_GUIDE' ||
                    openToolAccordion === 'downloader';
                  return (
                    <button
                      type="button"
                      onClick={() => toggleAccordion('downloader')}
                      className={`w-full px-4 py-3 rounded-[14px] flex items-center justify-between text-xs font-bold uppercase tracking-[1px] transition-colors cursor-pointer ${
                        isDownloaderSection
                          ? 'bg-[#FFE9E9] text-[#FF3B30]'
                          : 'bg-[#F8F9FC] text-[#111111] hover:bg-[#F1F3F8]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Download className={`w-4 h-4 shrink-0 ${isDownloaderSection ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                        <span>DOWNLOADER</span>
                      </div>
                      <ChevronRight
                        className={`w-4 h-4 transition-transform duration-200 ${
                          isDownloaderSection ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'
                        } ${openToolAccordion === 'downloader' ? 'rotate-90' : 'rotate-0'}`}
                      />
                    </button>
                  );
                })()}

                {/* SUB-MENU ACCORDION 2: DOWNLOADER */}
                <div
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${
                    openToolAccordion === 'downloader' ? 'max-h-96 opacity-100 mt-1.5' : 'max-h-0 opacity-0 mt-0'
                  }`}
                >
                  <div className="space-y-1.5 text-xs font-semibold pl-2.5 border-l border-[#F0F0F0] py-1">
                    <button
                      type="button"
                      onClick={() => {
                        goToPage('DOWNLOADER');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'DOWNLOADER'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <Download className={`w-4 h-4 shrink-0 ${currentView === 'DOWNLOADER' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span>Download Baru</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        goToPage('DOWNLOADER_SETTINGS');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'DOWNLOADER_SETTINGS'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <Sliders className={`w-4 h-4 shrink-0 ${currentView === 'DOWNLOADER_SETTINGS' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span>Settings Endpoint</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        goToPage('DOWNLOADER_GUIDE');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'DOWNLOADER_GUIDE'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <BookOpen className={`w-4 h-4 shrink-0 ${currentView === 'DOWNLOADER_GUIDE' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span>Cara Penggunaan</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        goToPage('DOWNLOADER_HISTORY');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'DOWNLOADER_HISTORY'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <History className={`w-4 h-4 shrink-0 ${currentView === 'DOWNLOADER_HISTORY' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}`} />
                      <span className="tabular-nums">Lihat History Download ({downloadHistory.length})</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* ACCORDION 3: BUILDER (WEB TO APK) */}
              <div className="space-y-1.5">
                {(() => {
                  const isBuilderActive =
                    currentView === 'WEB_TO_APK' ||
                    currentView === 'APK_HISTORY' ||
                    openToolAccordion === 'builder';
                  return (
                    <button
                      type="button"
                      onClick={() => toggleAccordion('builder')}
                      className={`w-full px-4 py-3 rounded-[14px] flex items-center justify-between text-xs font-bold uppercase tracking-[1px] transition-colors cursor-pointer ${
                        isBuilderActive
                          ? 'bg-[#FFE9E9] text-[#FF3B30]'
                          : 'bg-[#F8F9FC] text-[#111111] hover:bg-[#F1F3F8]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Smartphone
                          className={`w-4 h-4 shrink-0 ${
                            isBuilderActive ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'
                          }`}
                        />
                        <span>BUILDER (WEB TO APK)</span>
                      </div>
                      <ChevronRight
                        className={`w-4 h-4 transition-transform duration-200 ${
                          isBuilderActive ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'
                        } ${openToolAccordion === 'builder' ? 'rotate-90' : 'rotate-0'}`}
                      />
                    </button>
                  );
                })()}

                {/* SUB-MENU ACCORDION 3: BUILDER */}
                <div
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${
                    openToolAccordion === 'builder' ? 'max-h-96 opacity-100 mt-1.5' : 'max-h-0 opacity-0 mt-0'
                  }`}
                >
                  <div className="space-y-1.5 text-xs font-semibold pl-2.5 border-l border-[#F0F0F0] py-1">
                    <button
                      type="button"
                      onClick={() => {
                        setApkSubView('BUILD');
                        goToPage('WEB_TO_APK');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'WEB_TO_APK' && apkSubView === 'BUILD'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <Smartphone
                        className={`w-4 h-4 shrink-0 ${
                          currentView === 'WEB_TO_APK' && apkSubView === 'BUILD'
                            ? 'text-[#FF3B30]'
                            : 'text-[#8A8A8E]'
                        }`}
                      />
                      <span>Buat APK Baru</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setApkSubView('SETTINGS');
                        goToPage('WEB_TO_APK');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'WEB_TO_APK' && apkSubView === 'SETTINGS'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <Sliders
                        className={`w-4 h-4 shrink-0 ${
                          currentView === 'WEB_TO_APK' && apkSubView === 'SETTINGS'
                            ? 'text-[#FF3B30]'
                            : 'text-[#8A8A8E]'
                        }`}
                      />
                      <span>Settings Endpoint</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setApkSubView('GUIDE');
                        goToPage('WEB_TO_APK');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'WEB_TO_APK' && apkSubView === 'GUIDE'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <BookOpen
                        className={`w-4 h-4 shrink-0 ${
                          currentView === 'WEB_TO_APK' && apkSubView === 'GUIDE'
                            ? 'text-[#FF3B30]'
                            : 'text-[#8A8A8E]'
                        }`}
                      />
                      <span>Cara Penggunaan</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        goToPage('APK_HISTORY');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className={`w-full px-3.5 py-2.5 rounded-[12px] text-left flex items-center gap-2.5 tracking-[0.5px] transition-colors cursor-pointer ${
                        currentView === 'APK_HISTORY'
                          ? 'bg-[#FFE9E9] text-[#FF3B30] font-bold'
                          : 'text-[#111111] hover:bg-[#F7F8FC]'
                      }`}
                    >
                      <History
                        className={`w-4 h-4 shrink-0 ${
                          currentView === 'APK_HISTORY' ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'
                        }`}
                      />
                      <span>Lihat History APK</span>
                    </button>
                  </div>
                </div>
              </div>

            </div>

            {/* SIDEBAR SEALED FOOTER WITH SINGLE ROUND WHITE SETTINGS BUTTON */}
            <div className="p-4 shrink-0 border-t border-[#F0F0F0] text-center space-y-3 select-none bg-[#FAFAFC]">
              <div className="flex justify-center">
                <button
                  type="button"
                  onClick={() => goToPage('pengaturanUmum')}
                  aria-label={appLang === 'en' ? 'General Settings' : 'Pengaturan Umum'}
                  title={appLang === 'en' ? 'General Settings' : 'Pengaturan Umum'}
                  className="nb-round-settings-btn"
                >
                  <Settings className="w-6 h-6 text-[#FF3B30]" />
                </button>
              </div>
              <div className="space-y-1">
                <p className="text-[11px] tracking-[1px] font-bold uppercase text-[#8A8A8E]">
                  POWERED BY - <span className="text-[#FF3B30] font-black">DAPP</span>
                </p>
                <p className="text-[11px] tracking-[1px] font-bold uppercase text-[#8A8A8E]">
                  VERSION - <span className="text-[#111111] font-black">1.0</span>
                </p>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* MAIN IN-PAGE CANVAS */}
      <main
        className={`flex-1 w-full mx-auto p-4 md:p-6 pb-6 md:pb-8 space-y-5 ${
          currentView === 'WEB_TO_APK' || currentView === 'APK_HISTORY' ? 'max-w-5xl' : 'max-w-2xl'
        }`}
      >

        {/* ================= VIEW 1: UPLOAD & PUBLISH VIEW ================= */}
        {currentView === 'DEPLOY' && (
          <div className="space-y-5 animate-in fade-in">


            <div className="space-y-1 pt-1 px-0.5">
              <h2 className="text-[15px] font-black uppercase tracking-[1px] flex items-center gap-2 text-[#111111]">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF3B30]" /> {appLang === 'en' ? 'UPLOAD & PUBLISH' : 'UPLOAD & PUBLISH'}
              </h2>
              <p className="text-xs text-[#8A8A8E] font-medium">
                {appLang === 'en' ? 'Turn HTML / ZIP into a live website.' : 'Ubah HTML / ZIP jadi website.'}
              </p>
            </div>

            {/* INPUT NAMA PROJECT WITH VERCEL BADGE PERSIS DI ATAS INPUT */}
            <div className="nb-card p-5 space-y-3.5">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="px-3 py-1 bg-[#FFE9E9] text-[#FF3B30] text-[11px] font-bold uppercase tracking-[0.8px] rounded-full inline-flex items-center gap-1.5">
                  ▲ VERCEL - AKTIF
                </span>

                {projectName.trim() ? (
                  <span className="text-[10px] font-bold uppercase tracking-[0.8px] bg-[#FFE9E9] text-[#FF3B30] px-3 py-1 rounded-full flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5 text-[#FF3B30]" /> SUBDOMAIN TERSEDIA
                  </span>
                ) : (
                  <span className="text-[10px] font-bold uppercase tracking-[0.8px] bg-[#F7F8FC] text-[#8A8A8E] px-3 py-1 rounded-full border border-[#F0F0F0]">
                    ⚠ NAMA PROJECT DIPERLUKAN
                  </span>
                )}
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-extrabold uppercase tracking-[0.8px] block text-[#111111]" data-i18n="project_name">
                  {appLang === 'en' ? translations.en.project_name : translations.id.project_name}
                </label>
                <div className="flex items-stretch">
                  <input
                    type="text"
                    value={projectName}
                    onChange={(e) => handleSlugify(e.target.value)}
                    placeholder={appLang === 'en' ? translations.en.placeholder_project_name : translations.id.placeholder_project_name}
                    data-i18n-placeholder="placeholder_project_name"
                    className="nb-input flex-1 !py-3.5 !px-4 !rounded-r-none border-r-0 text-xs font-semibold"
                  />
                  <span className="px-3.5 py-3.5 border border-[#E8E8E8] border-l-0 bg-[#F7F8FC] text-[#FF3B30] rounded-r-[14px] text-xs font-bold flex items-center">
                    .vercel.app
                  </span>
                </div>
              </div>
            </div>

            {/* CARD 2: [2] FILE WEBSITE (.HTML / .ZIP) */}
            <div className="nb-card p-5 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-extrabold uppercase tracking-[0.8px] flex items-center gap-2 text-[#111111]" data-i18n="website_file">
                  <span className="w-6 h-6 rounded-[10px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center text-[11px] font-black">2</span>
                  {appLang === 'en' ? translations.en.website_file : translations.id.website_file}
                </label>
                {hasSelectedFile && (
                  <span className="text-[10px] font-bold uppercase tracking-[0.8px] bg-[#FFE9E9] text-[#FF3B30] px-3 py-1 rounded-full flex items-center gap-1">
                    <Check className="w-3 h-3 text-[#FF3B30]" /> SIAP DEPLOY
                  </span>
                )}
              </div>

              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    const f = e.dataTransfer.files[0];
                    if (f.name.endsWith('.zip')) {
                      setUploadedZipFile(f);
                      setUploadedHtmlFile(null);
                      setPastedHtmlCode('');
                    } else {
                      setUploadedHtmlFile(f);
                      setUploadedZipFile(null);
                      setPastedHtmlCode('');
                    }
                    showToast(`File ${f.name} dipilih!`, 'info');
                  }
                }}
                className={`border p-5 rounded-[16px] transition-all cursor-pointer ${
                  hasSelectedFile
                    ? 'border-[#FF3B30]/40 bg-[#FFE9E9]/35'
                    : isDragging
                    ? 'border-[#FF3B30] bg-[#FFE9E9]/50'
                    : 'border-[#E8E8E8] bg-[#F7F8FC] hover:border-[#FF3B30]/40'
                }`}
              >
                <input
                  type="file"
                  accept=".html,.htm,.zip"
                  id="mainFileInput"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      const f = e.target.files[0];
                      if (f.name.endsWith('.zip')) {
                        setUploadedZipFile(f);
                        setUploadedHtmlFile(null);
                        setPastedHtmlCode('');
                      } else {
                        setUploadedHtmlFile(f);
                        setUploadedZipFile(null);
                        setPastedHtmlCode('');
                      }
                      showToast(`File ${f.name} dipilih!`, 'info');
                    }
                  }}
                />

                {hasSelectedFile ? (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                    <label htmlFor="mainFileInput" className="cursor-pointer flex items-center gap-3 text-left w-full sm:w-auto">
                      <div className="p-2 rounded-[12px] bg-[#FF3B30] text-white shrink-0">
                        <CheckCircle2 className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-[#111111]">
                          File Terpilih: {selectedFileName} - {selectedFileSizeKb} - Siap Deploy
                        </p>
                        <p className="text-[11px] text-[#8A8A8E] font-medium">
                          Ketuk area ini untuk mengganti berkas dari penyimpanan
                        </p>
                      </div>
                    </label>

                    <button
                      type="button"
                      onClick={handleResetFile}
                      className="nb-btn-black px-3 py-1.5 text-[11px] flex items-center gap-1 shrink-0 cursor-pointer"
                      title="Hapus file"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Ganti File</span>
                    </button>
                  </div>
                ) : (
                  <label htmlFor="mainFileInput" className="cursor-pointer flex items-center justify-center gap-3">
                    <div className="p-2.5 rounded-[12px] bg-[#FFE9E9] text-[#FF3B30]">
                      <FileArchive className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">
                      Ketuk untuk pilih file .html atau .zip
                    </span>
                  </label>
                )}
              </div>

              <div className="text-center text-[10px] font-bold text-[#8A8A8E] uppercase tracking-[2px]">
                — ATAU —
              </div>

              <div>
                <textarea
                  rows={8}
                  value={pastedHtmlCode}
                  onChange={(e) => {
                    setPastedHtmlCode(e.target.value);
                    if (e.target.value.trim()) {
                      setUploadedHtmlFile(null);
                      setUploadedZipFile(null);
                    }
                  }}
                  placeholder={appLang === 'en' ? translations.en.placeholder_paste_html : translations.id.placeholder_paste_html}
                  data-i18n-placeholder="placeholder_paste_html"
                  className="nb-input w-full !p-4 text-xs font-medium"
                />
              </div>
            </div>

            {/* CARD 3: 🔒 LINDUNGI CODE (OPSIONAL) - 2 SIMPLE CHOICES ONLY */}
            <div className="nb-card p-5 space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-extrabold uppercase tracking-[0.8px] flex items-center gap-2 text-[#111111]" data-i18n="protect_code">
                  <span className="p-1.5 rounded-[10px] bg-[#FFE9E9] text-[#FF3B30]">
                    <Lock className="w-3.5 h-3.5" />
                  </span>
                  {appLang === 'en' ? translations.en.protect_code : translations.id.protect_code}
                </label>
                {protectionMode === 'ENCRYPT_CODE' && (
                  <span className="text-[10px] font-bold uppercase tracking-[0.8px] bg-[#FFE9E9] text-[#FF3B30] px-3 py-1 rounded-full flex items-center gap-1">
                    <Lock className="w-3 h-3 text-[#FF3B30]" /> TERKUNCI
                  </span>
                )}
              </div>

              {/* ONLY 2 SIMPLE CHOICES */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <button
                  type="button"
                  onClick={() => setProtectionMode('NO_ENC')}
                  className={`p-3.5 text-center flex items-center justify-center cursor-pointer ${
                    protectionMode === 'NO_ENC'
                      ? 'nb-btn-primary'
                      : 'nb-btn-secondary'
                  }`}
                >
                  <div className="font-bold text-xs sm:text-sm tracking-[0.8px] flex items-center justify-center gap-1.5">
                    <span>NO ENC</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setProtectionMode('ENCRYPT_CODE')}
                  className={`p-3.5 text-center flex items-center justify-center cursor-pointer ${
                    protectionMode === 'ENCRYPT_CODE'
                      ? 'nb-btn-primary'
                      : 'nb-btn-secondary'
                  }`}
                >
                  <div className="font-bold text-xs sm:text-sm tracking-[0.8px] flex items-center justify-center gap-1.5">
                    <span>ENCRYPT CODE</span>
                    <span>🔒</span>
                  </div>
                </button>
              </div>

              {/* DISCLAIMER TEXT */}
              <p className="text-[11px] text-[#8A8A8E] italic font-medium">
                "ENCRYPT CODE membuat code susah dibaca & disalin, tapi bukan 100% tidak bisa dibobol."
              </p>

              {/* DIGITAL WATERMARK TOGGLE */}
              <div className="pt-3 border-t border-[#F0F0F0] space-y-2.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="watermarkToggle" className="text-xs font-bold uppercase tracking-[0.5px] flex items-center gap-2 cursor-pointer text-[#111111]">
                    <span className="p-1.5 rounded-[10px] bg-[#FFE9E9] text-[#FF3B30]">
                      <Fingerprint className="w-3.5 h-3.5" />
                    </span>
                    <span>Digital Watermark Hak Cipta</span>
                  </label>

                  <div
                    id="watermarkToggle"
                    role="switch"
                    aria-checked={enableWatermark}
                    tabIndex={0}
                    onClick={() => setEnableWatermark(!enableWatermark)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        setEnableWatermark(!enableWatermark);
                      }
                    }}
                    className={`toggle ${enableWatermark ? 'active' : ''}`}
                    title="Toggle Digital Watermark Hak Cipta"
                  >
                    <div className="toggle-knob" />
                  </div>
                </div>

                {enableWatermark && (
                  <div className="nb-card-sub p-3.5 space-y-1.5 animate-in fade-in">
                    <label className="block text-[11px] font-semibold text-[#8A8A8E]">
                      Nama Pemilik / Tanda Tangan Hak Cipta:
                    </label>
                    <input
                      type="text"
                      value={watermarkOwner}
                      onChange={(e) => setWatermarkOwner(e.target.value)}
                      placeholder="contoh: Developer DAPP"
                      className="nb-input w-full !px-3.5 !py-2.5 text-xs font-semibold"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* TOKEN WARNING & VERIFICATION CARD */}
            {!isTokenCheckedAndValid && (
              <div className="nb-card p-4 border-[#FFD6D4] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-semibold animate-in fade-in">
                <div className="flex items-center gap-2.5 text-[#111111]">
                  <div className="p-2 rounded-[12px] bg-[#FFE9E9] text-[#FF3B30] shrink-0">
                    <AlertCircle className="w-4 h-4" />
                  </div>
                  <span className="font-bold">
                    {!activeUserToken
                      ? 'Isi Vercel Token dulu di Pengaturan'
                      : 'Token Vercel belum diverifikasi (Cek Token Dulu)'}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0 flex-wrap">
                  {activeUserToken && (
                    <button
                      type="button"
                      onClick={handleVerifyToken}
                      disabled={isTestingPing}
                      className="nb-btn-secondary px-3.5 py-2 text-[11px] flex items-center gap-1.5 cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5 text-[#FF3B30]" /> CEK TOKEN SEKARANG
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setCurrentView('SETTINGS')}
                    className="nb-btn-primary px-3.5 py-2 text-[11px] flex items-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Key className="w-3.5 h-3.5 text-white" /> BUKA PENGATURAN
                  </button>
                </div>
              </div>
            )}

            {/* SINGLE DEPLOY SEKARANG BUTTON */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                disabled={!isTokenCheckedAndValid || isDeploying}
                onClick={handleStartDeployment}
                className={`w-full h-[56px] min-h-[56px] text-sm flex items-center justify-center gap-2.5 ${
                  isDeploying
                    ? 'nb-btn-primary opacity-85 cursor-not-allowed'
                    : isTokenCheckedAndValid
                    ? 'nb-btn-primary cursor-pointer'
                    : 'nb-btn-secondary opacity-60 cursor-not-allowed'
                }`}
                title={isDeploying ? 'Deploying...' : !isTokenCheckedAndValid ? 'Cek Token Dulu' : 'Deploy sekarang'}
              >
                {isDeploying ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin text-white" />
                    <span>Deploying... ⏳</span>
                  </>
                ) : (
                  <>
                    <UploadCloud className={`w-5 h-5 ${isTokenCheckedAndValid ? 'text-white' : 'text-[#FF3B30]'}`} />
                    <span>{isTokenCheckedAndValid ? 'DEPLOY SEKARANG' : 'Cek Token Dulu'}</span>
                  </>
                )}
              </button>
            </div>

            {/* IN-LINE DEPLOYMENT EXECUTION RESULT BOX WITH AUTO-SCROLL */}
            {isDeploying && (
              <div
                id="deploy-status"
                style={{ scrollMarginTop: '90px' }}
                className="scroll-mt-[90px] nb-card p-5 sm:p-6 space-y-5 animate-in fade-in transition-all"
              >
                {/* CARD HEADER */}
                <div className="flex items-center justify-between border-b border-[#F0F0F0] pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className={`w-3 h-3 rounded-full ${
                      deployStatus === 'success'
                        ? 'bg-[#FF3B30]'
                        : deployStatus === 'failed'
                        ? 'bg-[#FF3B30]'
                        : 'bg-[#FF3B30] animate-ping'
                    }`} />
                    <h3 className="font-black text-sm tracking-[0.8px] uppercase text-[#111111]">
                      PROSES DEPLOY {platform.toUpperCase()}
                    </h3>
                  </div>
                  {(deployStatus === 'success' || deployStatus === 'failed') && (
                    <button
                      onClick={() => setIsDeploying(false)}
                      className="nb-btn-secondary p-1.5 cursor-pointer"
                      title="Tutup Status"
                    >
                      <X className="w-4 h-4 text-[#FF3B30]" />
                    </button>
                  )}
                </div>

                {/* STATE 1: LOADING */}
                {deployStatus === 'running' && (
                  <div className="py-2 space-y-4 animate-in fade-in text-center">
                    <div className="relative inline-flex items-center justify-center">
                      <div className="w-14 h-14 rounded-[18px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center">
                        <RefreshCw className="w-6 h-6 animate-spin" />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-base font-black uppercase tracking-[0.8px] text-[#111111]">
                        Sedang Deploy ke {platform}...
                      </h4>
                      <p className="text-xs font-bold text-[#FF3B30] min-h-[1.5rem] transition-all duration-300">
                        {progressLoadingSteps[loadingProgressIdx]}
                      </p>
                    </div>

                    {/* PROGRESS BAR */}
                    <div className="w-full max-w-md mx-auto space-y-1.5">
                      <div className="w-full bg-[#EEF0F5] rounded-full h-3 overflow-hidden">
                        <div
                          className="bg-[#FF3B30] h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${Math.min(95, Math.max(20, (deployStep / 4) * 100 + (loadingProgressIdx % 3) * 5))}%`
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] font-bold text-[#8A8A8E] tabular-nums">
                        <span>Langkah {deployStep} dari 4</span>
                        <span>{pollStatusText || 'Sedang diproses...'}</span>
                      </div>
                    </div>

                    {/* 4 LANGKAH BERURUTAN */}
                    <div className="nb-card-sub p-3.5 text-left space-y-2.5">
                      {[
                        { step: 1, title: 'Langkah 1: Validasi berkas project' },
                        { step: 2, title: `Langkah 2: Upload file ke ${platform}` },
                        { step: 3, title: 'Langkah 3: Membuat deployment' },
                        { step: 4, title: 'Langkah 4: Membuat link deploy' },
                      ].map((item) => {
                        const isRunning = deployStep === item.step;
                        const isSuccess = deployStep > item.step;

                        return (
                          <div key={item.step} className="flex items-center gap-2.5 text-xs font-bold">
                            {isSuccess ? (
                              <CheckCircle2 className="w-4 h-4 text-[#FF3B30] shrink-0" />
                            ) : isRunning ? (
                              <RefreshCw className="w-4 h-4 text-[#FF3B30] animate-spin shrink-0" />
                            ) : (
                              <div className="w-4 h-4 rounded-full border border-[#D1D5DB] bg-white shrink-0" />
                            )}
                            <span className={isSuccess ? 'text-[#FF3B30]' : isRunning ? 'text-[#111111]' : 'text-[#8A8A8E]'}>
                              {item.title}
                            </span>
                            {isRunning && (
                              <span className="text-[10px] text-[#FF3B30] font-bold">
                                (Sedang berjalan...)
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* STATE 2: SUKSES */}
                {deployStatus === 'success' && latestDeployedItem && (
                  <div className="py-3 space-y-4 text-center animate-in zoom-in-95 duration-300">
                    <div className="w-16 h-16 rounded-[20px] bg-[#FF3B30] flex items-center justify-center mx-auto shadow-[0_8px_20px_rgba(255,59,48,0.25)]">
                      <CheckCircle2 className="w-9 h-9 text-white" />
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-xl font-black text-[#111111] tracking-[0.8px] uppercase">
                        Deploy Berhasil!
                      </h4>
                      <p className="text-xs text-[#8A8A8E] font-medium">
                        Website <span className="text-[#FF3B30] font-bold">{latestDeployedItem.projectName}</span> kini aktif dan siap diakses online.
                      </p>
                    </div>

                    {/* KOTAK LINK HASIL DEPLOY */}
                    <div className="p-4 bg-[#FFE9E9]/60 border border-[#FFD6D4] rounded-[16px] text-center space-y-2">
                      <p className="text-[10px] uppercase tracking-[0.8px] font-extrabold text-[#FF3B30] flex items-center justify-center gap-1.5">
                        <Check className="w-3.5 h-3.5" /> LINK HASIL DEPLOY RESMI:
                      </p>
                      <a
                        href={latestDeployedItem.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-base sm:text-lg font-extrabold text-[#111111] hover:text-[#FF3B30] underline break-all block py-1"
                      >
                        {latestDeployedItem.url}
                      </a>
                    </div>

                    {/* TOMBOL BUKA WEBSITE & COPY LINK */}
                    <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
                      <button
                        type="button"
                        onClick={() => copyToClipboard(latestDeployedItem.url)}
                        className="nb-btn-secondary flex-1 h-[50px] px-4 text-xs flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Copy className="w-4 h-4 text-[#FF3B30]" /> Copy Link
                      </button>
                      <a
                        href={latestDeployedItem.url}
                        target="_blank"
                        rel="noreferrer"
                        className="nb-btn-primary flex-1 h-[50px] px-4 text-xs flex items-center justify-center gap-2"
                      >
                        <ExternalLink className="w-4 h-4 text-white" /> Buka Website
                      </a>
                    </div>
                  </div>
                )}

                {/* STATE 3: GAGAL */}
                {deployStatus === 'failed' && (
                  <div className="py-3 space-y-4 text-center animate-in zoom-in-95 duration-300">
                    <div className="w-16 h-16 rounded-[20px] bg-[#FFE9E9] flex items-center justify-center mx-auto">
                      <XCircle className="w-9 h-9 text-[#FF3B30]" />
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-xl font-black text-[#FF3B30] uppercase tracking-[0.8px]">
                        Deployment Gagal
                      </h4>
                      <p className="text-xs text-[#8A8A8E] font-medium">
                        Terjadi kendala saat melakukan deployment ke {platform}.
                      </p>
                    </div>

                    <div className="p-4 rounded-[16px] bg-[#FFF5F5] border border-[#FFD6D4] text-xs text-[#111111] space-y-1.5 text-left">
                      <p className="font-extrabold flex items-center gap-1.5 text-[#FF3B30] uppercase tracking-[0.8px]">
                        <ShieldAlert className="w-4 h-4 shrink-0" />
                        <span>Pesan Error API:</span>
                      </p>
                      <p className="break-all font-medium text-[#8A8A8E]">{deployErrorMsg || 'Respon API tidak berhasil. Periksa kembali token atau file Anda.'}</p>
                    </div>

                    <div className="pt-1 flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsDeploying(false);
                          setTimeout(() => {
                            handleStartDeployment();
                          }, 100);
                        }}
                        className="nb-btn-primary flex-1 h-[48px] px-4 text-xs flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <RefreshCw className="w-4 h-4 text-white" /> Coba Lagi
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsDeploying(false)}
                        className="nb-btn-secondary h-[48px] px-4 text-xs cursor-pointer"
                      >
                        Tutup
                      </button>
                    </div>
                  </div>
                )}

                {/* LOG TERMINAL */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-bold uppercase tracking-[0.8px] text-[#8A8A8E] block">
                    Log Aktivitas Deployment:
                  </span>
                  <div className="bg-[#F7F8FC] p-3.5 rounded-[14px] text-[11px] text-[#111111] h-24 overflow-y-auto border border-[#E8E8E8] text-left font-medium">
                    {deployLogs.map((l, i) => (
                      <div key={i}>{l}</div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= VIEW 2: SETTINGS PAGE VIEW ================= */}
        {currentView === 'SETTINGS' && (
          <div className="space-y-5 animate-in fade-in">
            <div className="flex items-center justify-between">
              <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111]">
                {appLang === 'en' ? 'Settings' : 'Pengaturan'}
              </h1>
              <button
                type="button"
                onClick={() => setCurrentView('DEPLOY')}
                className="nb-btn-secondary px-3.5 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 text-[#FF3B30]" /> {appLang === 'en' ? 'Back' : 'Kembali'}
              </button>
            </div>

            {/* CONNECT ACCOUNT */}
            <div className="nb-card p-5 space-y-4">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-xs font-extrabold uppercase tracking-[0.8px] flex items-center gap-2 text-[#111111]">
                  <span className="p-1.5 rounded-[10px] bg-[#FFE9E9] text-[#FF3B30]">
                    <Key className="w-3.5 h-3.5" />
                  </span>
                  CONNECT ACCOUNT (PRIBADI)
                </span>
                <span className={`text-[10px] font-bold uppercase tracking-[0.8px] px-3 py-1 rounded-full ${
                  hasValidToken
                    ? 'bg-[#FFE9E9] text-[#FF3B30]'
                    : 'bg-[#F7F8FC] text-[#8A8A8E] border border-[#F0F0F0]'
                }`}>
                  {hasValidToken ? 'TOKEN VERCEL AKTIF' : 'TOKEN VERCEL BELUM DIISI'}
                </span>
              </div>

              <p className="text-xs text-[#8A8A8E] font-medium leading-relaxed">
                Masukkan Vercel Token milik Anda di bawah ini. Token disimpan di localStorage browser dan dipakai selamanya untuk deployment langsung ke Vercel via API resmi.
              </p>

              <div className="space-y-2.5 pt-3 border-t border-[#F0F0F0]">
                <div className="flex justify-between text-[11px] font-bold uppercase tracking-[0.8px]">
                  <span className="text-[#111111]">Vercel Token (PAT Saya)</span>
                  <span className={vercelStatus.valid ? 'text-[#FF3B30]' : 'text-[#8A8A8E]'}>
                    {vercelStatus.label}
                  </span>
                </div>

                <div className="relative">
                  <input
                    type={showVercelToken ? 'text' : 'password'}
                    value={user.vercelToken}
                    onChange={(e) => handleVercelTokenChange(e.target.value)}
                    placeholder="vercel_pat_..."
                    className={`nb-input w-full !pl-3.5 !pr-10 !py-3 text-xs font-semibold ${
                      user.vercelToken && !vercelStatus.valid ? '!border-[#FF3B30]' : ''
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowVercelToken(!showVercelToken)}
                    className="absolute right-3 top-3 text-[#8A8A8E] hover:text-[#FF3B30] cursor-pointer"
                  >
                    {showVercelToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                <div className="flex items-center gap-3 flex-wrap">
                  <button
                    type="button"
                    onClick={handleVerifyToken}
                    disabled={isTestingPing || !user.vercelToken.trim()}
                    className="nb-btn-primary px-4 py-2.5 text-xs flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-white" /> CEK TOKEN
                  </button>
                  <span className="text-[10px] font-medium text-[#8A8A8E]">
                    Validasi ke API GET /v2/user
                  </span>
                </div>

                {tokenVerification.checked && (
                  tokenVerification.valid ? (
                    <div className="p-3 bg-[#FFE9E9] border border-[#FFD6D4] rounded-[14px] text-[#FF3B30] text-xs font-bold flex items-center gap-2">
                      <span>✅ Token Aktif - Akun: {tokenVerification.accountName || 'Vercel User'}</span>
                    </div>
                  ) : (
                    <div className="p-3 bg-[#FFF5F5] border border-[#FFD6D4] rounded-[14px] text-[#FF3B30] text-xs font-bold flex items-center gap-2">
                      <span>❌ Token Salah / Expired. Cek lagi token kamu.</span>
                    </div>
                  )
                )}
              </div>
            </div>



          </div>
        )}

        {/* ================= VIEW 3: HISTORY DEPLOY VIEW ================= */}
        {currentView === 'HISTORY' && (
          <div className="space-y-5 animate-in fade-in">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] tabular-nums">
                {appLang === 'en' ? `Deploy History (${deployments.length})` : `History Deploy (${deployments.length})`}
              </h1>
              <div className="flex items-center gap-2">
                {deployments.length > 0 && (
                  <button
                    type="button"
                    onClick={handleExportHistory}
                    className="nb-btn-secondary px-3 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
                    title="Ekspor riwayat ke file JSON"
                  >
                    <Download className="w-3.5 h-3.5 text-[#FF3B30]" /> {appLang === 'en' ? 'Export JSON' : 'Ekspor JSON'}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setCurrentView('DEPLOY')}
                  className="nb-btn-secondary px-3 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 text-[#FF3B30]" /> {appLang === 'en' ? 'Back' : 'Kembali'}
                </button>
              </div>
            </div>

            {deployments.length > 0 && (
              <div className="relative">
                <Search className="w-4 h-4 text-[#8A8A8E] absolute left-3.5 top-3.5 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari project..."
                  className="nb-input w-full !pl-10 !pr-3.5 !py-3 text-xs font-semibold"
                />
              </div>
            )}

            {filteredDeployments.length === 0 ? (
              <div className="nb-card p-8 text-center text-[#8A8A8E] space-y-2.5">
                <div className="w-12 h-12 rounded-[16px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center mx-auto">
                  <History className="w-6 h-6" />
                </div>
                <p className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">Belum ada history deploy.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredDeployments.map((dep) => (
                  <div key={dep.id} className="nb-card p-4 space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-extrabold text-sm text-[#111111] uppercase tracking-[0.8px]">
                        {dep.projectName}
                      </span>
                      <span className="px-3 py-0.5 rounded-full text-[10px] font-bold bg-[#FFE9E9] text-[#FF3B30] uppercase tracking-[0.8px]">
                        {dep.platform}
                      </span>
                    </div>

                    <p className="text-xs text-[#8A8A8E] font-medium break-all">{dep.url}</p>

                    <div className="flex items-center justify-between pt-2.5 border-t border-[#F0F0F0] text-xs gap-2 flex-wrap">
                      <span className="text-[11px] font-medium text-[#8A8A8E] tabular-nums">{dep.date}</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => copyToClipboard(dep.url)}
                          className="nb-btn-secondary px-3 py-1.5 text-xs cursor-pointer"
                        >
                          Salin
                        </button>
                        <a
                          href={dep.url}
                          target="_blank"
                          rel="noreferrer"
                          className="nb-btn-primary px-3.5 py-1.5 text-xs"
                        >
                          Buka
                        </a>
                        <button
                          type="button"
                          onClick={() => setDeleteModal({ isOpen: true, item: dep })}
                          className="nb-btn-black px-3 py-1.5 text-xs flex items-center gap-1 cursor-pointer"
                          title="Hapus project"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Hapus
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* HAPUS SEMUA HISTORY DEPLOY (DI DALAM HALAMAN HISTORY DEPLOY) */}
            <div className="rounded-[16px] bg-[#FFE9E9]/70 border border-[#FFD6D4] p-4 sm:p-5">
              <button
                type="button"
                disabled={deployments.length === 0}
                onClick={handleClearAllHistory}
                className="w-full py-3.5 px-4 rounded-[14px] bg-[#FF3B30] hover:bg-[#E0342A] disabled:bg-[#FF3B30]/40 disabled:cursor-not-allowed text-white text-xs sm:text-sm font-black uppercase tracking-[0.8px] flex items-center justify-center gap-2 shadow-[0_6px_18px_rgba(255,59,48,0.22)] transition-all cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>{appLang === 'en' ? 'Clear Deploy History' : 'Hapus History Deploy'}</span>
              </button>
            </div>
          </div>
        )}

        {/* ================= VIEW 4: GUIDE VIEW ================= */}
        {currentView === 'GUIDE' && (
          <div className="space-y-5 animate-in fade-in">
            <div className="flex items-center justify-between">
              <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111]">
                {appLang === 'en' ? 'User Guide' : 'Cara Penggunaan'}
              </h1>
              <button
                type="button"
                onClick={() => setCurrentView('DEPLOY')}
                className="nb-btn-secondary px-3 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 text-[#FF3B30]" /> {appLang === 'en' ? 'Back' : 'Kembali'}
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="nb-card p-4 space-y-1">
                <p className="text-[#111111] font-extrabold text-sm uppercase tracking-[0.8px]">1. Target Platform Deploy</p>
                <p className="text-xs text-[#8A8A8E] font-medium leading-relaxed">Aplikasi terhubung langsung dan resmi ke platform Vercel dengan domain *.vercel.app.</p>
              </div>

              <div className="nb-card p-4 space-y-1">
                <p className="text-[#111111] font-extrabold text-sm uppercase tracking-[0.8px]">2. Masukkan Nama Project</p>
                <p className="text-xs text-[#8A8A8E] font-medium leading-relaxed">Ketik nama unik untuk subdomain website Anda (contoh: portofolio-ku).</p>
              </div>

              <div className="nb-card p-4 space-y-1">
                <p className="text-[#111111] font-extrabold text-sm uppercase tracking-[0.8px]">3. Pilih File atau Tempel Kode</p>
                <p className="text-xs text-[#8A8A8E] font-medium leading-relaxed">Ketuk area upload untuk memilih file .html / .zip ATAU tempelkan kode HTML lengkap di kolom teks.</p>
              </div>

              <div className="nb-card p-4 space-y-1">
                <p className="text-[#111111] font-extrabold text-sm uppercase tracking-[0.8px]">4. Lindungi Code (Opsional)</p>
                <p className="text-xs text-[#8A8A8E] font-medium leading-relaxed">Pilih 'ENCRYPT CODE 🔒' untuk otomatis membungkus HTML ke dalam JS Loader + proteksi ringan klik kanan & Ctrl+U.</p>
              </div>
            </div>
          </div>
        )}

        {/* ================= VIEW 5: DAPP DOWNLOADER VIEW ================= */}
        {currentView === 'DOWNLOADER' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in">
            {/* TOP BAR */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <span className="text-xs font-bold uppercase tracking-[0.8px] px-3.5 py-1.5 rounded-full bg-[#FFE9E9] text-[#FF3B30] flex items-center gap-2 tabular-nums">
                <Download className="w-4 h-4 text-[#FF3B30]" />
                <span>{appLang === 'en' ? `DAPP DOWNLOADER • ACTIVE ENDPOINTS: ${activeEndpointsCount} / 8` : `DAPP DOWNLOADER • ENDPOINT AKTIF: ${activeEndpointsCount} / 8`}</span>
              </span>

              <button
                onClick={() => setCurrentView('DOWNLOADER_SETTINGS')}
                className="nb-btn-secondary text-xs px-3.5 py-2 flex items-center gap-1.5 cursor-pointer"
              >
                <Sliders className="w-4 h-4 text-[#FF3B30]" />
                <span>{appLang === 'en' ? 'Endpoint Settings' : 'Settings Endpoint'}</span>
              </button>
            </div>

            {/* MAIN CARD: FORM INPUT LINK MEDIA */}
            <div className="nb-card p-5 sm:p-7 space-y-6">
              <div className="space-y-1">
                <h1 className="text-xl md:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
                  <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
                    <Download className="w-5 h-5" />
                  </span>
                  <span>DAPP DOWNLOADER</span>
                </h1>
                <p className="text-xs text-[#8A8A8E] font-medium leading-relaxed">
                  Tempel URL / Link video, audio, atau berkas media di bawah ini untuk memproses dan mengunduh berkas secara instan.
                </p>
              </div>

              {/* 1. SECTION: PILIH PLATFORM */}
              <div className="space-y-2.5">
                <label className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111] block">
                  PILIH PLATFORM
                </label>
                <div className="grid grid-cols-4 gap-2 sm:gap-3">
                  {downloaderPlatforms.map((plat) => {
                    const isActive = selectedPlatform === plat.id;
                    return (
                      <button
                        key={plat.id}
                        type="button"
                        onClick={() => setSelectedPlatform(plat.id)}
                        className={`flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-[16px] transition-all cursor-pointer aspect-square sm:aspect-auto sm:h-20 active:scale-[0.97] ${
                          isActive
                            ? 'bg-[#FF3B30] text-white border border-[#FF3B30] shadow-[0_6px_16px_rgba(255,59,48,0.22)]'
                            : 'bg-white text-[#111111] border border-[#F0F0F0] shadow-[0_4px_14px_rgba(0,0,0,0.04)] hover:border-[#FF3B30]/40 hover:bg-[#FAFAFC]'
                        }`}
                      >
                        <div className={`mb-1 flex items-center justify-center ${isActive ? 'text-white' : 'text-[#FF3B30]'}`}>
                          {plat.icon}
                        </div>
                        <span className="text-[10px] sm:text-[11px] font-bold tracking-[0.8px] uppercase truncate w-full text-center">
                          {plat.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. INPUT LINK / URL MEDIA */}
              <div className="space-y-2">
                <label className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111] block">
                  URL / LINK MEDIA
                </label>
                <div className="relative flex items-center">
                  <LinkIcon className="w-4 h-4 text-[#8A8A8E] absolute left-3.5 pointer-events-none" />
                  <input
                    type="url"
                    value={mediaUrl}
                    onChange={(e) => setMediaUrl(e.target.value)}
                    placeholder={
                      downloaderPlatforms.find((p) => p.id === selectedPlatform)?.placeholder || 'Tempel Link...'
                    }
                    className="nb-input w-full !pl-10 !pr-28 !py-3.5 text-xs font-semibold"
                  />
                  <div className="absolute right-2 flex items-center gap-1">
                    {mediaUrl && (
                      <button
                        type="button"
                        onClick={() => setMediaUrl('')}
                        className="p-1.5 text-[#8A8A8E] hover:text-[#FF3B30] transition-all cursor-pointer"
                        title="Hapus Link"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const text = await navigator.clipboard.readText();
                          if (text) {
                            setMediaUrl(text);
                            showToast('Link berhasil ditempel!', 'success');
                          }
                        } catch {
                          showToast('Gagal membaca clipboard', 'error');
                        }
                      }}
                      className="px-2.5 py-1.5 rounded-[10px] bg-[#FF3B30] text-white text-[11px] font-bold uppercase tracking-[0.8px] shadow-[0_4px_12px_rgba(255,59,48,0.2)] hover:brightness-95 active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Tempel</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* 3. FORMAT MEDIA */}
              <div className="space-y-2 pt-1">
                <label className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111] block">
                  FORMAT MEDIA
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { id: 'mp4', label: 'MP4', sub: 'Video' },
                    { id: 'mp3', label: 'MP3', sub: 'Audio' },
                    { id: 'm4a', label: 'M4A', sub: 'Audio' },
                    { id: 'webm', label: 'WEBM', sub: 'Video' }
                  ].map((fmt) => (
                    <button
                      key={fmt.id}
                      type="button"
                      onClick={() => setSelectedFormat(fmt.id as any)}
                      className={`p-3 text-center cursor-pointer ${
                        selectedFormat === fmt.id
                          ? 'nb-btn-primary'
                          : 'nb-btn-secondary'
                      }`}
                    >
                      <div className="text-xs font-extrabold tracking-[0.8px]">{fmt.label}</div>
                      <div className="text-[10px] opacity-80">{fmt.sub}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* 4. TOMBOL UNDUH SEKARANG */}
              <div className="pt-2">
                <button
                  type="button"
                  disabled={isDownloadingMedia || !mediaUrl.trim()}
                  onClick={handleStartDownload}
                  className="nb-btn-primary w-full h-[56px] min-h-[56px] px-6 disabled:opacity-45 disabled:cursor-not-allowed text-sm flex items-center justify-center gap-2.5 cursor-pointer"
                >
                  {isDownloadingMedia ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin text-white" />
                      <span>Memproses dari server...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 text-white" />
                      <span>UNDUH SEKARANG</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* STATUS & RESULTS CARD (#downloader-status) */}
            {(downloadStatus !== 'idle' || isDownloadingMedia) && (
              <div
                id="downloader-status"
                className="nb-card p-6 space-y-5 animate-in fade-in slide-in-from-bottom-4 duration-300"
              >
                <div className="flex items-center justify-between border-b border-[#F0F0F0] pb-4">
                  <span className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111] flex items-center gap-2">
                    <span className="p-1.5 rounded-[10px] bg-[#FFE9E9] text-[#FF3B30]">
                      <Zap className="w-3.5 h-3.5" />
                    </span>
                    <span>HASIL PROSES MEDIA</span>
                  </span>
                  <span className="text-xs font-medium text-[#8A8A8E]">DAPP Downloader v1.0</span>
                </div>

                {/* STATE 1: RUNNING / REAL FETCH LOADING */}
                {downloadStatus === 'running' && (
                  <div className="space-y-4 text-center py-8">
                    <div className="inline-flex p-4 rounded-[18px] bg-[#FFE9E9] text-[#FF3B30]">
                      <RefreshCw className="w-8 h-8 animate-spin" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-base font-black uppercase tracking-[0.8px] text-[#111111]">Memproses dari server...</h3>
                      <p className="text-xs text-[#8A8A8E] font-medium">
                        Menghubungkan dan mengambil data media dari API Endpoint...
                      </p>
                    </div>
                  </div>
                )}

                {/* STATE 2: SUCCESS RESULT (MEDIA & DATA ASLI API) */}
                {downloadStatus === 'success' && apiDownloadResult && (
                  <div className="space-y-5">
                    <div className="flex items-start gap-4 p-4 rounded-[16px] bg-[#FFE9E9]/60 border border-[#FFD6D4] text-[#111111]">
                      <CheckCircle2 className="w-8 h-8 text-[#FF3B30] shrink-0 mt-0.5" />
                      <div className="space-y-1 flex-1">
                        <h3 className="text-base font-black uppercase tracking-[0.8px] text-[#111111]">Media Berhasil Ditemukan!</h3>
                        <p className="text-xs text-[#8A8A8E] font-medium">
                          Data media resmi berhasil didapatkan dari server API endpoint.
                        </p>
                      </div>
                    </div>

                    {/* MEDIA PREVIEW ASLI DARI API */}
                    {(apiDownloadResult.previewUrl || apiDownloadResult.thumbnail) && (
                      <div className="space-y-2">
                        <label className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111] block">
                          PREVIEW MEDIA ASLI
                        </label>
                        <div className="rounded-[16px] overflow-hidden bg-[#F7F8FC] border border-[#F0F0F0] flex items-center justify-center p-2">
                          {apiDownloadResult.mediaType === 'audio' ? (
                            <div className="w-full space-y-3 p-3">
                              {apiDownloadResult.thumbnail && (
                                shouldShowPreview ? (
                                  <img
                                    src={apiDownloadResult.thumbnail}
                                    alt={apiDownloadResult.title || 'Audio Cover'}
                                    className="w-full max-h-56 object-contain rounded-[12px]"
                                  />
                                ) : (
                                  <div className="w-full h-36 rounded-[12px] bg-white border border-[#F0F0F0] flex flex-col items-center justify-center gap-2 text-[#8A8A8E]">
                                    <ImageOff className="w-7 h-7" />
                                    <span className="text-[10px] font-bold uppercase tracking-[0.8px]">PREVIEW GAMBAR NON-AKTIF</span>
                                  </div>
                                )
                              )}
                              <audio
                                controls
                                preload={shouldShowPreview ? 'metadata' : 'none'}
                                src={apiDownloadResult.previewUrl || (apiDownloadResult.links[0]?.url)}
                                className="w-full"
                              />
                            </div>
                          ) : apiDownloadResult.previewUrl ? (
                            shouldShowPreview ? (
                              <video
                                controls
                                src={apiDownloadResult.previewUrl}
                                poster={apiDownloadResult.thumbnail}
                                className="w-full max-h-80 rounded-[12px] object-contain"
                              />
                            ) : (
                              <div className="w-full space-y-3 p-3">
                                <div className="w-full h-36 rounded-[12px] bg-white border border-[#F0F0F0] flex flex-col items-center justify-center gap-2 text-[#8A8A8E]">
                                  <ImageOff className="w-7 h-7" />
                                  <span className="text-[10px] font-bold uppercase tracking-[0.8px]">PREVIEW GAMBAR NON-AKTIF</span>
                                </div>
                                <video
                                  controls
                                  preload="none"
                                  src={apiDownloadResult.previewUrl}
                                  className="w-full max-h-60 rounded-[12px] object-contain"
                                />
                              </div>
                            )
                          ) : shouldShowPreview ? (
                            <img
                              src={apiDownloadResult.thumbnail}
                              alt={apiDownloadResult.title || 'Thumbnail'}
                              className="w-full max-h-80 rounded-[12px] object-contain"
                            />
                          ) : (
                            <div className="w-full h-44 rounded-[12px] bg-white border border-[#F0F0F0] flex flex-col items-center justify-center gap-2 text-[#8A8A8E]">
                              <ImageOff className="w-8 h-8" />
                              <span className="text-[10px] font-bold uppercase tracking-[0.8px]">PREVIEW GAMBAR NON-AKTIF</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* DETAILS ASLI DARI API (TITLE, AUTHOR, DURATION) */}
                    {(apiDownloadResult.title || apiDownloadResult.author || apiDownloadResult.duration) && (
                      <div className="nb-card-sub p-4 space-y-2">
                        {apiDownloadResult.title && (
                          <div className="text-sm font-extrabold text-[#111111] leading-snug">
                            {apiDownloadResult.title}
                          </div>
                        )}
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#8A8A8E] font-medium tabular-nums">
                          {apiDownloadResult.author && (
                            <span>Author: <strong className="text-[#111111]">{apiDownloadResult.author}</strong></span>
                          )}
                          {apiDownloadResult.duration && (
                            <span>Durasi: <strong className="text-[#111111]">{apiDownloadResult.duration}</strong></span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* KUALITAS DINAMIS HANYA DARI RESPONS API */}
                    {apiDownloadResult.links.length > 0 && (
                      <div className="space-y-2">
                        <label className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111] block tabular-nums">
                          PILIH KUALITAS DARI SERVER ({apiDownloadResult.links.length} TAUTAN TERSEDIA)
                        </label>
                        <div className="flex flex-wrap gap-2">
                          {apiDownloadResult.links.map((linkItem, idx) => {
                            const isSelected = selectedQualityIdx === idx;
                            return (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setSelectedQualityIdx(idx)}
                                className={`px-3.5 py-2 text-xs cursor-pointer ${
                                  isSelected
                                    ? 'nb-btn-primary'
                                    : 'nb-btn-secondary'
                                }`}
                              >
                                <span>{linkItem.quality.toUpperCase()}</span>
                                {linkItem.size && <span className="ml-1.5 opacity-80 text-[10px]">({linkItem.size})</span>}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* 3 TOMBOL AKSI BENERAN */}
                    {(() => {
                      const activeLinkItem = apiDownloadResult.links[selectedQualityIdx] || apiDownloadResult.links[0];
                      const activeUrl = activeLinkItem?.url || apiDownloadResult.previewUrl || mediaUrl;

                      const sortedLinks = [...apiDownloadResult.links].sort((a, b) => {
                        const numA = parseInt(a.quality.replace(/\D/g, '')) || 0;
                        const numB = parseInt(b.quality.replace(/\D/g, '')) || 0;
                        return numB - numA;
                      });
                      const highestLink = sortedLinks[0] || activeLinkItem;
                      const highestLabel = highestLink?.quality || 'TERBAIK';

                      return (
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                          {/* TOMBOL 1: DOWNLOAD */}
                          <a
                            href={activeUrl}
                            download={apiDownloadResult.title || 'media'}
                            target="_blank"
                            rel="noreferrer"
                            className="nb-btn-primary h-[48px] px-4 text-xs flex items-center justify-center gap-2 cursor-pointer text-center"
                          >
                            <Download className="w-4 h-4 text-white" />
                            <span>DOWNLOAD</span>
                          </a>

                          {/* TOMBOL 2: BAGIKAN */}
                          <button
                            type="button"
                            onClick={async () => {
                              const shareData = {
                                title: apiDownloadResult.title || 'DAPP Downloader',
                                text: apiDownloadResult.title ? `Unduh Media: ${apiDownloadResult.title}` : 'Media Link',
                                url: activeUrl
                              };
                              if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
                                try {
                                  await navigator.share(shareData);
                                  showToast('Berhasil membagikan link media!', 'success');
                                } catch {
                                  // Share canceled
                                }
                              } else {
                                try {
                                  await navigator.clipboard.writeText(activeUrl);
                                  showToast('Link disalin ke clipboard!', 'success');
                                } catch {
                                  showToast('Gagal menyalin link', 'error');
                                }
                              }
                            }}
                            className="nb-btn-secondary h-[48px] px-4 text-xs flex items-center justify-center gap-2 cursor-pointer text-center"
                          >
                            <Share2 className="w-4 h-4 text-[#FF3B30]" />
                            <span>BAGIKAN</span>
                          </button>

                          {/* TOMBOL 3: DOWNLOAD [HIGHEST_QUALITY] */}
                          <a
                            href={highestLink?.url || activeUrl}
                            download={apiDownloadResult.title || 'media'}
                            target="_blank"
                            rel="noreferrer"
                            className="nb-btn-secondary h-[48px] px-4 text-xs flex items-center justify-center gap-2 cursor-pointer text-center"
                          >
                            <Download className="w-4 h-4 text-[#FF3B30]" />
                            <span>DOWNLOAD {highestLabel.toUpperCase()}</span>
                          </a>
                        </div>
                      );
                    })()}
                  </div>
                )}

                {/* STATE 3: FAILED */}
                {downloadStatus === 'failed' && (
                  <div className="space-y-4 p-5 rounded-[16px] bg-[#FFF5F5] border border-[#FFD6D4] text-center">
                    <XCircle className="w-8 h-8 text-[#FF3B30] mx-auto" />
                    <div className="space-y-1">
                      <h3 className="text-base font-black text-[#111111] uppercase tracking-[0.8px]">Gagal Memproses Unduhan</h3>
                      <p className="text-xs text-[#8A8A8E] font-medium">{downloadErrorMsg || 'Gagal terhubung ke endpoint API.'}</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleStartDownload}
                      className="nb-btn-primary px-5 py-2.5 text-xs inline-flex items-center gap-2 cursor-pointer"
                    >
                      <RefreshCw className="w-4 h-4 text-white" />
                      <span>Coba Lagi</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ================= VIEW 6: DOWNLOADER SETTINGS VIEW ================= */}
        {currentView === 'DOWNLOADER_SETTINGS' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in pb-4">
            {/* HEADER */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E5E7EB]">
              <div>
                <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
                  <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
                    <Sliders className="w-5 h-5" />
                  </span>
                  <span>{appLang === 'en' ? 'ENDPOINT SETTINGS' : 'SETTINGS ENDPOINT'}</span>
                </h1>
                <p className="text-xs text-[#8A8A8E] font-medium mt-1">
                  {appLang === 'en'
                    ? 'Enter downloader API endpoint URLs for each platform and enable via toggle.'
                    : 'Masukkan endpoint API downloader untuk tiap platform. Aktifkan dengan toggle untuk menggunakannya.'}
                </p>
              </div>

              <div className="flex items-center gap-3 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-[0.8px] px-3.5 py-1.5 rounded-full bg-[#FFE9E9] text-[#FF3B30] tabular-nums">
                  {appLang === 'en' ? `ACTIVE ENDPOINTS: ${activeEndpointsCount} / 8` : `ENDPOINT AKTIF: ${activeEndpointsCount} / 8`}
                </span>
                <button
                  onClick={() => setCurrentView('DOWNLOADER')}
                  className="nb-btn-secondary px-3.5 py-2 text-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <ArrowLeft className="w-4 h-4 text-[#FF3B30]" />
                  <span>{appLang === 'en' ? 'Back' : 'Kembali'}</span>
                </button>
              </div>
            </div>

            {/* 8 PLATFORM ENDPOINT CARDS (VERTIKAL 1 KOLOM) */}
            <div className="space-y-4">
              {downloaderPlatforms.map((plat) => {
                const ep = endpointsMap[plat.id] || { url: '', active: false };
                return (
                  <div
                    key={plat.id}
                    className="nb-card p-4 sm:p-5 space-y-3.5"
                  >
                    {/* BARIS ATAS CARD */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-[12px] bg-[#FFE9E9] text-[#FF3B30]">
                          {plat.icon}
                        </div>
                        <span className="text-sm font-extrabold text-[#111111] tracking-[0.8px] uppercase">
                          {plat.name}
                        </span>
                      </div>

                      <div className="flex items-center gap-2.5">
                        <span className={`text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-[0.8px] ${
                          ep.active
                            ? 'bg-[#FFE9E9] text-[#FF3B30]'
                            : 'bg-[#F7F8FC] text-[#8A8A8E] border border-[#F0F0F0]'
                        }`}>
                          {ep.active ? 'AKTIF' : 'OFF'}
                        </span>

                        <div
                          role="switch"
                          aria-checked={ep.active}
                          tabIndex={0}
                          onClick={() => handleToggleEndpoint(plat.id, plat.name)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              handleToggleEndpoint(plat.id, plat.name);
                            }
                          }}
                          className={`toggle ${ep.active ? 'active' : ''}`}
                          title={`Toggle ${plat.name}`}
                        >
                          <div className="toggle-knob" />
                        </div>
                      </div>
                    </div>

                    {/* LABEL & INPUT URL */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold text-[#111111] uppercase tracking-[0.8px] block">
                        ENDPOINT API {plat.name}
                      </label>
                      <input
                        type="url"
                        value={ep.url}
                        onChange={(e) => {
                          const newUrl = e.target.value;
                          setEndpointsMap((prev) => {
                            const prevEntry = prev[plat.id] || { url: '', active: false };
                            const hadUrl = Boolean(prevEntry.url.trim());
                            const hasUrlNow = Boolean(newUrl.trim());
                            return {
                              ...prev,
                              [plat.id]: {
                                url: newUrl,
                                active: !hasUrlNow ? false : (!hadUrl ? true : prevEntry.active)
                              }
                            };
                          });
                        }}
                        placeholder={`https://api-contoh.com/download?url=`}
                        className="nb-input w-full !px-3.5 !py-3 text-xs font-semibold"
                      />
                    </div>

                    {/* ACTION BUTTONS */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleSaveEndpoint(plat.id, plat.name)}
                        className="nb-btn-primary px-4 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5 text-white" />
                        <span>Simpan</span>
                      </button>

                      <button
                        type="button"
                        disabled={endpointTestingMap[plat.id]}
                        onClick={() => handleTestEndpoint(plat.id, plat.name)}
                        className="nb-btn-secondary px-4 py-2 disabled:opacity-50 text-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        {endpointTestingMap[plat.id] ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#FF3B30]" />
                            <span>Mengecek...</span>
                          </>
                        ) : (
                          <>
                            <Zap className="w-3.5 h-3.5 text-[#FF3B30]" />
                            <span>Test / Cek</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* HASIL TEST RESULT DISPLAY */}
                    {endpointTestResults[plat.id] && (() => {
                      const res = endpointTestResults[plat.id];
                      const isTrue = res.status === 'TRUE_ACTIVE';
                      const isNonJson = res.status === 'TRUE_NON_JSON';
                      const isInactive = res.status === 'FALSE_INACTIVE';

                      const bgClass = isTrue
                        ? 'bg-[#FFE9E9]/60 border-[#FFD6D4] text-[#111111]'
                        : isNonJson
                        ? 'bg-[#F7F8FC] border-[#E8E8E8] text-[#111111]'
                        : isInactive
                        ? 'bg-[#F7F8FC] border-[#F0F0F0] text-[#8A8A8E]'
                        : 'bg-[#FFF5F5] border-[#FFD6D4] text-[#FF3B30]';

                      return (
                        <div className={`mt-3 p-3.5 rounded-[14px] border space-y-1.5 text-xs animate-in fade-in ${bgClass}`}>
                          <div className="flex items-center justify-between gap-2 flex-wrap font-bold pb-1.5 border-b border-black/5">
                            <span className="uppercase tracking-[0.8px]">
                              {isTrue
                                ? 'STATUS: TRUE / AKTIF ✅'
                                : isNonJson
                                ? 'STATUS: TRUE tapi FORMAT TIDAK DIKENAL'
                                : isInactive
                                ? 'STATUS: FALSE / NON-AKTIF'
                                : 'STATUS: FALSE / ERROR ❌'}
                            </span>
                            <span className="text-[10px] opacity-80 tabular-nums">Terakhir dicek: {res.lastCheckedTime}</span>
                          </div>

                          <div className="text-[11px] font-medium leading-relaxed">
                            {res.message}
                          </div>

                          {res.responseTimeMs !== undefined && (
                            <div className="text-[11px] font-bold opacity-95 pt-0.5 tabular-nums">
                              Waktu Respon: {res.responseTimeMs}ms {res.httpStatus ? `(HTTP ${res.httpStatus})` : ''}
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                );
              })}
            </div>

            {/* GLOBAL BOTTOM ACTION BUTTONS */}
            <div className="pt-4 border-t border-[#E5E7EB] flex flex-col sm:flex-row items-center gap-3">
              <button
                type="button"
                onClick={handleSaveAllEndpoints}
                className="nb-btn-primary w-full sm:flex-1 h-[52px] px-6 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4 text-white" />
                <span>SIMPAN SEMUA ENDPOINT</span>
              </button>

              <button
                type="button"
                onClick={handleResetAllEndpoints}
                className="nb-btn-black w-full sm:w-auto h-[52px] px-6 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Trash2 className="w-4 h-4 text-[#FF3B30]" />
                <span>RESET SEMUA</span>
              </button>
            </div>
          </div>
        )}

        {/* ================= VIEW 7: DOWNLOADER HISTORY VIEW ================= */}
        {currentView === 'DOWNLOADER_HISTORY' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5 tabular-nums">
                <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
                  <History className="w-5 h-5" />
                </span>
                <span>{appLang === 'en' ? `Download History (${downloadHistory.length})` : `History Download (${downloadHistory.length})`}</span>
              </h1>
              <button
                onClick={() => setCurrentView('DOWNLOADER')}
                className="nb-btn-secondary px-3 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 text-[#FF3B30]" />
                <span>{appLang === 'en' ? 'Back to Downloader' : 'Kembali ke Downloader'}</span>
              </button>
            </div>

            {downloadHistory.length === 0 ? (
              <div className="nb-card p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-[16px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center mx-auto">
                  <Download className="w-6 h-6" />
                </div>
                <p className="text-xs font-bold uppercase tracking-[0.8px] text-[#8A8A8E]">Belum ada history unduhan media.</p>
                <button
                  onClick={() => setCurrentView('DOWNLOADER')}
                  className="nb-btn-primary px-5 py-2.5 text-xs inline-flex items-center gap-2 cursor-pointer"
                >
                  <span>Mulai Unduh Media</span>
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {downloadHistory.map((item) => (
                  <div key={item.id} className="nb-card p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-start gap-3.5 min-w-0">
                      {shouldShowPreview && item.thumbnail ? (
                        <img
                          src={item.thumbnail}
                          alt={item.title}
                          className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-[14px] border border-[#F0F0F0] shrink-0 bg-[#F7F8FC]"
                        />
                      ) : (
                        <div
                          className="w-16 h-16 sm:w-20 sm:h-20 rounded-[14px] border border-[#F0F0F0] bg-[#F7F8FC] flex flex-col items-center justify-center gap-1 shrink-0 text-[#8A8A8E]"
                          title={shouldShowPreview ? 'Tidak ada thumbnail' : 'Preview gambar dinonaktifkan'}
                        >
                          <ImageOff className="w-5 h-5" />
                          <span className="text-[8px] font-bold uppercase tracking-[0.5px]">NO IMG</span>
                        </div>
                      )}
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-extrabold text-sm text-[#111111] break-words">{item.title}</span>
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#FFE9E9] text-[#FF3B30] uppercase tracking-[0.8px]">
                            {item.format} • {item.quality}
                          </span>
                        </div>
                        <p className="text-xs text-[#8A8A8E] font-medium break-all">{item.url}</p>
                        <p className="text-[11px] font-medium text-[#8A8A8E] tabular-nums">{item.fileSize} • {item.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <a
                        href={item.downloadUrl || item.url}
                        download={item.title}
                        target="_blank"
                        rel="noreferrer"
                        className="nb-btn-primary px-3.5 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5 text-white" />
                        <span>Unduh</span>
                      </a>
                      <button
                        onClick={() => {
                          setDownloadHistory((prev) => prev.filter((d) => d.id !== item.id));
                          showToast('Item history dihapus!', 'info');
                        }}
                        className="nb-btn-black p-2 text-xs cursor-pointer"
                        title="Hapus"
                      >
                        <Trash2 className="w-4 h-4 text-[#FF3B30]" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* HAPUS SEMUA HISTORY DOWNLOAD (DI DALAM HALAMAN HISTORY DOWNLOAD) */}
            <div className="rounded-[16px] bg-[#FFE9E9]/70 border border-[#FFD6D4] p-4 sm:p-5">
              <button
                type="button"
                disabled={downloadHistory.length === 0}
                onClick={handleClearDownloadHistory}
                className="w-full py-3.5 px-4 rounded-[14px] bg-[#FF3B30] hover:bg-[#E0342A] disabled:bg-[#FF3B30]/40 disabled:cursor-not-allowed text-white text-xs sm:text-sm font-black uppercase tracking-[0.8px] flex items-center justify-center gap-2 shadow-[0_6px_18px_rgba(255,59,48,0.22)] transition-all cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>{appLang === 'en' ? 'Clear Download History' : 'Hapus History Download'}</span>
              </button>
            </div>
          </div>
        )}

        {/* ================= VIEW 8: DOWNLOADER GUIDE VIEW ================= */}
        {currentView === 'DOWNLOADER_GUIDE' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
                <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
                  <BookOpen className="w-5 h-5" />
                </span>
                <span>{appLang === 'en' ? 'DAPP Downloader Guide' : 'Cara Penggunaan DAPP Downloader'}</span>
              </h1>
              <button
                onClick={() => setCurrentView('DOWNLOADER')}
                className="nb-btn-secondary px-3 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 text-[#FF3B30]" />
                <span>{appLang === 'en' ? 'Back to Downloader' : 'Kembali ke Downloader'}</span>
              </button>
            </div>

            <div className="nb-card p-6 md:p-8 space-y-4 text-xs">
              <div className="nb-card-sub p-4 space-y-1">
                <p className="text-sm font-extrabold text-[#111111] uppercase tracking-[0.8px]">1. Tempel Link Media</p>
                <p className="text-[#8A8A8E] font-medium leading-relaxed">
                  Salin URL / link video atau audio dari platform apapun, lalu tempelkan pada kolom input di halaman DAPP Downloader.
                </p>
              </div>

              <div className="nb-card-sub p-4 space-y-1">
                <p className="text-sm font-extrabold text-[#111111] uppercase tracking-[0.8px]">2. Pilih Format Media</p>
                <p className="text-[#8A8A8E] font-medium leading-relaxed">
                  Pilih format output yang Anda inginkan (MP4 Video, MP3 Audio, M4A Audio, atau WEBM Video). Kualitas akan ditampilkan langsung dari respon API server.
                </p>
              </div>

              <div className="nb-card-sub p-4 space-y-1">
                <p className="text-sm font-extrabold text-[#111111] uppercase tracking-[0.8px]">3. Klik Unduh & Simpan Berkas</p>
                <p className="text-[#8A8A8E] font-medium leading-relaxed">
                  Klik tombol UNDUH SEKARANG. Halaman akan mengambil data dari server endpoint aktif lalu menampilkan preview dan tautan unduhan asli.
                </p>
              </div>

              <div className="nb-card-sub p-4 space-y-1">
                <p className="text-sm font-extrabold text-[#111111] uppercase tracking-[0.8px]">4. Konfigurasi Endpoint Kustom</p>
                <p className="text-[#8A8A8E] font-medium leading-relaxed">
                  Buka menu Settings Endpoint untuk memasukkan URL Endpoint API Downloader tiap platform dan aktifkan toggle switch-nya.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ================= VIEW: BUILDER (WEB TO APK PRO - TANPA HISTORY DI BAWAH) ================= */}
        {currentView === 'WEB_TO_APK' && (
          <ApkBuilderView
            apkSubView={apkSubView}
            setApkSubView={setApkSubView}
            githubUsername={githubUsername}
            setGithubUsername={setGithubUsername}
            githubRepo={githubRepo}
            setGithubRepo={setGithubRepo}
            githubToken={githubToken}
            setGithubToken={setGithubToken}
            imgbbApiKey={imgbbApiKey}
            setImgbbApiKey={setImgbbApiKey}
            showGithubToken={showGithubToken}
            setShowGithubToken={setShowGithubToken}
            apkBuildMode={apkBuildMode}
            setApkBuildMode={setApkBuildMode}
            apkAppName={apkAppName}
            onAppNameChange={handleAppNameChange}
            apkPackageName={apkPackageName}
            setApkPackageName={setApkPackageName}
            apkVersion={apkVersion}
            setApkVersion={setApkVersion}
            apkUrl={apkUrl}
            setApkUrl={setApkUrl}
            apkFullscreen={apkFullscreen}
            setApkFullscreen={setApkFullscreen}
            zipFileMeta={zipFileMeta}
            zipPublicUrl={zipPublicUrl}
            isUploadingZip={isUploadingZip}
            zipUploadError={zipUploadError}
            onProcessZipFile={handleProcessZipFile}
            onRetryZipUpload={handleRetryZipUpload}
            onClearZipFile={handleClearZipFile}
            htmlCodeText={htmlCodeText}
            setHtmlCodeText={handleHtmlCodeChange}
            htmlCodePublicUrl={htmlCodePublicUrl}
            isUploadingHtmlCode={isUploadingHtmlCode}
            htmlCodeUploadError={htmlCodeUploadError}
            htmlMissingTagWarning={htmlMissingTagWarning}
            onConfirmProceedWithoutHtmlTag={() => handleStartRealApkBuild(true)}
            onClearHtmlCode={handleClearHtmlCode}
            deployments={deployments}
            apkIconUrl={apkIconUrl}
            apkLogoBase64={apkLogoBase64}
            apkIconDimensions={apkIconDimensions}
            isUploadingIcon={isUploadingIcon}
            apkIconError={apkIconError}
            hasPendingIconUpload={!!pendingIconUpload}
            onProcessIconFile={handleProcessIconFile}
            onRetryIconUpload={handleRetryPendingIconUpload}
            onClearIcon={handleClearIcon}
            validatePackageNameFormat={validatePackageNameFormat}
            normalizeAndValidateAppUrl={normalizeAndValidateAppUrl}
            isBuildingApk={isBuildingApk}
            isDownloadingApk={isDownloadingApk}
            liveBuild={liveBuild}
            lastDispatchedPayload={lastDispatchedPayload}
            onStartBuild={handleStartRealApkBuild}
            onRecheckRun={handleRecheckExistingRun}
            onSaveAsZip={handleSaveAsZipCurrent}
            onDownloadApk={(artifactUrl, appName) =>
              handleDownloadRealApk(artifactUrl, appName, liveBuild.runUrl)
            }
            onCopy={copyToClipboard}
            showToast={showToast}
          />
        )}

        {/* ================= VIEW: HISTORY BUILD APK (FULL PAGE - REAL dapp_history) ================= */}
        {currentView === 'APK_HISTORY' && (
          <ApkHistoryView
            historyItems={dappHistory}
            isDownloadingApk={isDownloadingApk}
            refreshingIds={refreshingHistoryIds}
            onRefreshItemStatus={handleRefreshHistoryItemStatus}
            onDownloadItemApk={handleDownloadHistoryItemApk}
            onDeleteItem={handleDeleteApkHistory}
            onClearAll={() => {
              setDappHistory([]);
              try {
                localStorage.setItem('dapp_history', JSON.stringify([]));
              } catch {}
              showToast('Semua riwayat build dihapus.', 'info');
            }}
            onGoToBuilder={() => {
              setApkSubView('BUILD');
              goToPage('WEB_TO_APK');
            }}
            onCopy={copyToClipboard}
            showToast={showToast}
          />
        )}

        {/* ================= VIEW 9: PENGATURAN UMUM VIEW ================= */}
        {currentView === 'pengaturanUmum' && (
          <div className="space-y-5 animate-in fade-in pb-4">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
                <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
                  <Settings className="w-5 h-5" />
                </span>
                <span data-i18n="general_settings">{appLang === 'en' ? translations.en.general_settings : translations.id.general_settings}</span>
              </h1>
              <button
                type="button"
                onClick={() => setCurrentView('DEPLOY')}
                className="nb-btn-secondary px-3.5 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4 text-[#FF3B30]" /> <span data-i18n="back">{appLang === 'en' ? translations.en.back : translations.id.back}</span>
              </button>
            </div>

            {/* SECTION 1: INFO PERANGKAT (SEPARATE SOFT WHITE CARDS - NO RENAME BUTTON) */}
            <div className="space-y-3">
              <span className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111] block px-1" data-i18n="device_info">
                {appLang === 'en' ? translations.en.device_info : translations.id.device_info}
              </span>

              {/* CARD NAMA PERANGKAT */}
              <div className="soft-info-card p-5 space-y-1.5">
                <p className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#8A8A8E]" data-i18n="device">
                  {appLang === 'en' ? translations.en.device : translations.id.device}
                </p>
                <p className="text-lg sm:text-xl font-black uppercase tracking-[0.8px] text-[#111111] leading-snug break-words">
                  {deviceInfo.headline}
                </p>
                <p className="text-[11px] font-medium uppercase tracking-[0.8px] text-[#8A8A8E]">
                  TERDETEKSI: {deviceInfo.detectedText}
                </p>
              </div>

              {/* GRID KARTU TELEMETRI TERPISAH (BATERAI, CPU, FPS, NETWORK) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* KARTU BATERAI */}
                <div className="soft-info-card p-4 space-y-2">
                  <p className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#8A8A8E]" data-i18n="battery">
                    {appLang === 'en' ? translations.en.battery : translations.id.battery}
                  </p>
                  {batteryInfo.supported && batteryInfo.level !== null ? (
                    <>
                      <div className="flex items-baseline justify-between gap-2 flex-wrap">
                        <span className="text-2xl font-black uppercase tracking-[0.8px] text-[#111111] tabular-nums">
                          {batteryInfo.level}%
                        </span>
                        <span
                          className={`text-[10px] font-bold uppercase tracking-[0.8px] px-2.5 py-1 rounded-full ${
                            batteryInfo.charging
                              ? 'bg-[#FFE9E9] text-[#FF3B30]'
                              : 'bg-[#F7F8FC] text-[#8A8A8E] border border-[#F0F0F0]'
                          }`}
                        >
                          {batteryInfo.charging ? 'MENGISI' : 'TIDAK MENGISI'}
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-[#EEF0F5] rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full bg-[#FF3B30]"
                          style={{ width: `${Math.max(0, Math.min(100, batteryInfo.level))}%` }}
                        />
                      </div>
                    </>
                  ) : (
                    <p className="text-base font-extrabold uppercase tracking-[0.8px] text-[#8A8A8E]">
                      TIDAK DIDUKUNG
                    </p>
                  )}
                </div>

                {/* KARTU CPU */}
                <div className="soft-info-card p-4 space-y-1.5 flex flex-col justify-between">
                  <p className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#8A8A8E]">
                    CPU
                  </p>
                  <p className="text-xl sm:text-2xl font-black uppercase tracking-[0.8px] text-[#111111] tabular-nums">
                    {cpuInfo.cores !== null ? `${cpuInfo.cores} CORE` : 'UNKNOWN'} - {cpuInfo.loadPct}%
                  </p>
                </div>

                {/* KARTU FPS */}
                <div className="soft-info-card p-4 space-y-1.5">
                  <p className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#8A8A8E]">
                    FPS
                  </p>
                  <div className="flex items-baseline justify-between gap-2 flex-wrap">
                    <span className="text-2xl font-black uppercase tracking-[0.8px] text-[#111111] tabular-nums">
                      {fpsValue} FPS
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-[0.8px] px-2.5 py-1 rounded-full ${
                        fpsValue >= 60
                          ? 'bg-[#FFE9E9] text-[#FF3B30]'
                          : 'bg-[#F7F8FC] text-[#8A8A8E] border border-[#F0F0F0]'
                      }`}
                    >
                      {fpsValue >= 60 ? 'LANCAR' : fpsValue >= 30 ? 'SEDANG' : 'LAG'}
                    </span>
                  </div>
                  <p className="text-[10px] font-medium uppercase tracking-[0.5px] text-[#8A8A8E]">
                    60 FPS = LANCAR, 30-59 = SEDANG, &lt;30 = LAG
                  </p>
                </div>

                {/* KARTU NETWORK */}
                <div className="soft-info-card p-4 space-y-1.5 flex flex-col justify-between">
                  <p className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#8A8A8E]">
                    NETWORK
                  </p>
                  <p className="text-lg sm:text-xl font-black uppercase tracking-[0.8px] text-[#111111]">
                    {networkInfo.typeLabel} • {networkInfo.online ? 'ONLINE' : 'OFFLINE'}
                  </p>
                </div>
              </div>

              {/* KARTU REFRESH INFO PERANGKAT */}
              <div className="soft-info-card p-4 flex items-center justify-between gap-3 flex-wrap">
                <span className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#8A8A8E] tabular-nums">
                  TERAKHIR UPDATE: {lastUpdatedTime}
                </span>
                <button
                  type="button"
                  onClick={handleRefreshDeviceInfo}
                  className="nb-btn-primary px-4 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-white" />
                  <span>REFRESH INFO</span>
                </button>
              </div>
            </div>

             {/* CARD 2: BAHASA */}
            <div className="nb-card p-5 space-y-3.5">
              <span className="text-xs font-extrabold uppercase tracking-[0.8px] block text-[#111111]" data-i18n="language">
                {appLang === 'en' ? translations.en.language : translations.id.language}
              </span>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => changeLanguage('id')}
                  className={`${appLang === 'id' ? 'nb-btn-primary' : 'nb-btn-secondary'} h-[46px] px-4 text-xs cursor-pointer text-center`}
                >
                  INDONESIA
                </button>
                <button
                  type="button"
                  onClick={() => changeLanguage('en')}
                  className={`${appLang === 'en' ? 'nb-btn-primary' : 'nb-btn-secondary'} h-[46px] px-4 text-xs cursor-pointer text-center`}
                >
                  ENGLISH
                </button>
              </div>
            </div>

            {/* CARD 3: PREFERENSI (5 FITUR PERFORM) */}
            <div className="nb-card p-5 space-y-3.5">
              <span className="text-xs font-extrabold uppercase tracking-[0.8px] flex items-center gap-2 text-[#111111]" data-i18n="preferences">
                <span className="p-1.5 rounded-[10px] bg-[#FFE9E9] text-[#FF3B30]">
                  <Zap className="w-3.5 h-3.5" />
                </span>
                {appLang === 'en' ? translations.en.preferences : translations.id.preferences}
              </span>

              {/* A. ANIMASI */}
              <div className="flex items-center justify-between gap-3 pt-1">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]" data-i18n="animation">
                    {appLang === 'en' ? translations.en.animation : translations.id.animation}
                  </p>
                  <p className="text-[11px] text-[#8A8A8E] font-medium" data-i18n="animation_desc">
                    {appLang === 'en' ? translations.en.animation_desc : translations.id.animation_desc}
                  </p>
                </div>
                <div
                  role="switch"
                  aria-checked={prefAnimasi}
                  tabIndex={0}
                  onClick={togglePrefAnimasi}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      togglePrefAnimasi();
                    }
                  }}
                  className={`toggle ${prefAnimasi ? 'active' : ''}`}
                  title="Toggle Animasi"
                >
                  <div className="toggle-knob" />
                </div>
              </div>

              {/* B. KECEPATAN TRANSISI / DELAY */}
              <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#F0F0F0]">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">KECEPATAN TRANSISI / DELAY</p>
                  <p className="text-[11px] text-[#8A8A8E] font-medium">Matikan untuk pindah halaman langsung tanpa delay</p>
                </div>
                <div
                  role="switch"
                  aria-checked={prefDelay}
                  tabIndex={0}
                  onClick={togglePrefDelay}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      togglePrefDelay();
                    }
                  }}
                  className={`toggle ${prefDelay ? 'active' : ''}`}
                  title="Toggle Kecepatan Transisi / Delay"
                >
                  <div className="toggle-knob" />
                </div>
              </div>

              {/* C. MODE HEMAT / MODE RINGAN */}
              <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#F0F0F0]">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">MODE HEMAT / MODE RINGAN</p>
                  <p className="text-[11px] text-[#8A8A8E] font-medium">Matikan animasi, kurangi shadow, & sembunyikan preview</p>
                </div>
                <div
                  role="switch"
                  aria-checked={prefHemat}
                  tabIndex={0}
                  onClick={togglePrefHemat}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      togglePrefHemat();
                    }
                  }}
                  className={`toggle ${prefHemat ? 'active' : ''}`}
                  title="Toggle Mode Hemat / Mode Ringan"
                >
                  <div className="toggle-knob" />
                </div>
              </div>

              {/* D. EFEK SHADOW TEBAL */}
              <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#F0F0F0]">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">EFEK SHADOW TEBAL</p>
                  <p className="text-[11px] text-[#8A8A8E] font-medium">Matikan untuk kurangi glow & shadow saat scroll</p>
                </div>
                <div
                  role="switch"
                  aria-checked={prefShadow}
                  tabIndex={0}
                  onClick={togglePrefShadow}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      togglePrefShadow();
                    }
                  }}
                  className={`toggle ${prefShadow ? 'active' : ''}`}
                  title="Toggle Efek Shadow Tebal"
                >
                  <div className="toggle-knob" />
                </div>
              </div>

              {/* E. PREVIEW GAMBAR / THUMBNAIL */}
              <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#F0F0F0]">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">PREVIEW GAMBAR / THUMBNAIL</p>
                  <p className="text-[11px] text-[#8A8A8E] font-medium">Sembunyikan thumbnail di History & Downloader untuk hemat kuota</p>
                </div>
                <div
                  role="switch"
                  aria-checked={prefPreview}
                  tabIndex={0}
                  onClick={togglePrefPreview}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      togglePrefPreview();
                    }
                  }}
                  className={`toggle ${prefPreview ? 'active' : ''}`}
                  title="Toggle Preview Gambar / Thumbnail"
                >
                  <div className="toggle-knob" />
                </div>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* ================= MODAL 1: CONFLICT NAMA PROJECT (LOGIKA 1) ================= */}
      {conflictModal && conflictModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/30 animate-in fade-in">
          <div className="w-full max-w-md nb-card p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black text-[#111111] uppercase tracking-[0.8px]">Nama Project Sudah Dipakai!</h3>
                <p className="text-xs text-[#8A8A8E] font-medium">Vercel: {conflictModal.projectName}</p>
              </div>
            </div>

            <div className="nb-card-sub p-4 text-xs space-y-1.5">
              <p className="font-semibold text-[#111111]">
                Nama <span className="text-[#FF3B30] font-extrabold">{conflictModal.projectName}</span> sudah dipakai di Vercel!
              </p>
              <p className="text-[11px] text-[#8A8A8E]">
                <strong className="text-[#111111]">Isi project lama:</strong> {conflictModal.existingInfo.name} • Tanggal deploy lama: {conflictModal.existingInfo.date}
              </p>
              <p className="text-[11px] text-[#8A8A8E] pt-1 font-semibold">
                Mau bagaimana?
              </p>
            </div>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleOverwriteConflict}
                className="nb-btn-black w-full py-3 px-4 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Trash2 className="w-4 h-4 text-[#FF3B30]" /> TIMPA & HAPUS YANG LAMA
              </button>

              <button
                type="button"
                onClick={handleRenameConflict}
                className="nb-btn-primary w-full py-3 px-4 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-white" /> GANTI NAMA JADI {conflictModal.projectName}-v2
              </button>

              <button
                type="button"
                onClick={() => setConflictModal(null)}
                className="nb-btn-secondary w-full py-2.5 px-4 text-xs cursor-pointer"
              >
                BATAL
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL 2: HAPUS PROJECT DARI HISTORY (LOGIKA 5) ================= */}
      {deleteModal && deleteModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/30 animate-in fade-in">
          <div className="w-full max-w-md nb-card p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black text-[#111111] uppercase tracking-[0.8px]">Hapus Project?</h3>
                <p className="text-xs text-[#8A8A8E] font-medium">{deleteModal.item.projectName}</p>
              </div>
            </div>

            <div className="nb-card-sub p-4 text-xs space-y-1.5">
              <p className="font-semibold text-[#111111]">
                Hapus project <span className="text-[#FF3B30] font-extrabold">{deleteModal.item.projectName}</span>?
              </p>
              <p className="text-[11px] text-[#8A8A8E]">
                URL: <span className="break-all text-[#111111] font-semibold">{deleteModal.item.url}</span>
              </p>
            </div>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                disabled={deleteModal.isDeleting}
                onClick={() => handleDeleteHistoryConfirm('history_only')}
                className="nb-btn-secondary w-full py-3 px-4 text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <FileCode className="w-4 h-4 text-[#FF3B30]" /> HAPUS HISTORY SAJA
              </button>

              <button
                type="button"
                disabled={deleteModal.isDeleting}
                onClick={() => handleDeleteHistoryConfirm('delete_remote')}
                className="nb-btn-black w-full py-3 px-4 text-xs flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {deleteModal.isDeleting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-[#FF3B30]" /> Menghapus di Vercel...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4 text-[#FF3B30]" /> HAPUS JUGA DI VERCEL
                  </>
                )}
              </button>

              <button
                type="button"
                disabled={deleteModal.isDeleting}
                onClick={() => setDeleteModal(null)}
                className="nb-btn-secondary w-full py-2.5 px-4 text-xs cursor-pointer"
              >
                BATAL
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
