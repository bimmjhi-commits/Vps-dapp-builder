export type ApkBuildMode = 'URL' | 'ZIP' | 'HTML';

export interface ZipFileMeta {
  name: string;
  sizeBytes: number;
}

export interface DappHistoryItem {
  id: string;
  app_name: string;
  app_url: string;
  package_name: string;
  version_name: string;
  icon_url: string;
  fullscreen: boolean;
  html_mode?: 'url' | 'zip' | 'html' | 'file';
  html_url?: string;
  html_file_name?: string;
  run_id: number | null;
  run_url: string;
  status: 'queued' | 'in_progress' | 'completed' | 'failed';
  conclusion: string | null;
  created_at: string;
  artifact_url: string;
  error_message?: string;
}

export interface DispatchedPayload {
  ref: string;
  inputs: {
    app_name: string;
    app_url: string;
    package_name: string;
    version_name: string;
    icon_url: string;
    fullscreen: 'true' | 'false';
    source_type: 'url' | 'zip' | 'html';
    html_url?: string;
    html_code_url?: string;
  };
  sentAt: string;
}

export interface LiveBuildState {
  phase: 'idle' | 'dispatching' | 'locating_run' | 'polling' | 'completed' | 'error';
  dispatchStatus: 'idle' | 'loading' | 'success' | 'error';
  dispatchTime?: string;
  dispatchError?: string;
  runId: number | null;
  runUrl: string;
  githubStatus: 'queued' | 'in_progress' | 'completed' | null;
  githubConclusion: string | null;
  lastPolledAt?: string;
  locateElapsedSec?: number;
  runNotFoundTimeout?: boolean;
  targetBranch?: string;
  artifactUrl: string;
  errorMessage?: string;
}

