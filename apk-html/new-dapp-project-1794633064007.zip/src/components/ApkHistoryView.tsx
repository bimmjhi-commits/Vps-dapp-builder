import React, { useState, useMemo } from 'react';
import {
  History,
  Search,
  Trash2,
  Download,
  RefreshCw,
  Loader2,
  CheckCircle2,
  XCircle,
  Share2,
  ChevronDown,
  Plus,
  AlertTriangle
} from 'lucide-react';
import { DappHistoryItem } from '../types/apk';

interface ApkHistoryViewProps {
  historyItems: DappHistoryItem[];
  isDownloadingApk: boolean;
  refreshingIds: Record<string, boolean>;
  onRefreshItemStatus: (item: DappHistoryItem) => Promise<void>;
  onDownloadItemApk: (item: DappHistoryItem) => Promise<void>;
  onDeleteItem: (id: string) => void;
  onClearAll: () => void;
  onGoToBuilder: () => void;
  onCopy: (text: string) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

type HistoryFilter = 'ALL' | 'SUCCESS' | 'FAILED' | 'BUILDING';
type HistorySort = 'NEWEST' | 'OLDEST' | 'NAME_ASC';

export const formatRealDateTime = (isoOrDateStr: string): string => {
  const date = new Date(isoOrDateStr);
  if (Number.isNaN(date.getTime())) return isoOrDateStr;
  const datePart = date.toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
  const timePart = date
    .toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    })
    .replace(':', '.');
  return `${datePart}, ${timePart}`;
};

export const getRealStatusMeta = (item: DappHistoryItem) => {
  if (item.status === 'queued' || item.status === 'in_progress') {
    return {
      key: 'BUILDING' as const,
      label: 'Building',
      badgeClass: 'bg-amber-50 text-amber-700 border-amber-200',
      icon: <Loader2 className="w-3 h-3 animate-spin" />
    };
  }
  if (item.status === 'completed' && item.conclusion === 'success') {
    return {
      key: 'SUCCESS' as const,
      label: 'Berhasil',
      badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      icon: <CheckCircle2 className="w-3 h-3" />
    };
  }
  return {
    key: 'FAILED' as const,
    label: 'Gagal',
    badgeClass: 'bg-[#FFE9E9] text-[#FF3B30] border-[#FFD6D4]',
    icon: <XCircle className="w-3 h-3" />
  };
};

const getModeBadgeLabel = (item: DappHistoryItem): 'URL' | 'ZIP' | 'HTML' => {
  if (item.html_mode === 'zip') return 'ZIP';
  if (item.html_mode === 'html' || item.html_mode === 'file') return 'HTML';
  return 'URL';
};

export const ApkHistoryView: React.FC<ApkHistoryViewProps> = ({
  historyItems,
  isDownloadingApk,
  refreshingIds,
  onRefreshItemStatus,
  onDownloadItemApk,
  onDeleteItem,
  onClearAll,
  onGoToBuilder,
  onCopy,
  showToast
}) => {
  // HISTORY (default terbuka)
  const [isHistoryOpen, setIsHistoryOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<HistoryFilter>('ALL');
  const [sortBy, setSortBy] = useState<HistorySort>('NEWEST');
  const [confirmDeleteItemId, setConfirmDeleteItemId] = useState<string | null>(null);
  const [brokenIconIds, setBrokenIconIds] = useState<Record<string, boolean>>({});

  // HAPUS SEMUA HISTORY (always visible at bottom with confirmation)
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  const handleShareItem = async (item: DappHistoryItem) => {
    const shareUrl = item.run_url || item.artifact_url || item.app_url;
    if (!shareUrl) {
      showToast('Tidak ada tautan yang tersedia untuk dibagikan.', 'error');
      return;
    }

    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      try {
        await navigator.share({
          title: item.app_name,
          text: `${item.app_name} (${item.package_name} • v${item.version_name})`,
          url: shareUrl
        });
        return;
      } catch (err: any) {
        if (err?.name === 'AbortError') {
          return;
        }
      }
    }

    onCopy(shareUrl);
    showToast('Link disalin', 'success');
  };

  const filteredAndSortedItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase().replace(/^#/, '');

    const filtered = historyItems.filter((item) => {
      const meta = getRealStatusMeta(item);
      if (filterStatus !== 'ALL' && meta.key !== filterStatus) return false;
      if (!q) return true;
      const matchName = item.app_name.toLowerCase().includes(q);
      const matchPkg = item.package_name.toLowerCase().includes(q);
      const matchRun = item.run_id ? String(item.run_id).includes(q) : false;
      return matchName || matchPkg || matchRun;
    });

    return [...filtered].sort((a, b) => {
      if (sortBy === 'NAME_ASC') {
        return a.app_name.localeCompare(b.app_name, 'id');
      }
      const timeA = new Date(a.created_at).getTime() || 0;
      const timeB = new Date(b.created_at).getTime() || 0;
      return sortBy === 'NEWEST' ? timeB - timeA : timeA - timeB;
    });
  }, [historyItems, searchQuery, filterStatus, sortBy]);

  return (
    <div className="space-y-4 animate-in fade-in pb-4">
      {/* HEADER */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2.5 flex-wrap">
          <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
            <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
              <History className="w-5 h-5" />
            </span>
            <span>History Web to APK</span>
          </h1>
          <span className="text-xs font-black px-3.5 py-1.5 rounded-full bg-white border border-[#E8E8E8] text-[#111111] tabular-nums shadow-2xs">
            Total {historyItems.length} APK
          </span>
        </div>
      </div>

      {/* HISTORY (COLLAPSIBLE, DEFAULT OPEN) */}
      <section className="rounded-[16px] bg-white border border-[#E8E8E8] shadow-[0_4px_20px_rgba(0,0,0,0.04)] overflow-hidden">
        <button
          type="button"
          onClick={() => setIsHistoryOpen((prev) => !prev)}
          className="w-full px-4 sm:px-5 py-4 flex items-center justify-between gap-3 text-left hover:bg-[#FAFAFC] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3 min-w-0">
            <span className="w-9 h-9 rounded-[12px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center shrink-0">
              <History className="w-4 h-4" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-black uppercase tracking-[0.6px] text-[#111111]">
                History
              </p>
              <p className="text-[11px] font-medium text-[#8A8A8E] tabular-nums">
                {historyItems.length === 0
                  ? 'Belum ada riwayat APK'
                  : `Menampilkan ${filteredAndSortedItems.length} dari ${historyItems.length} APK`}
              </p>
            </div>
          </div>

          <ChevronDown
            className={`w-4 h-4 text-[#8A8A8E] transition-transform duration-200 shrink-0 ${
              isHistoryOpen ? 'rotate-180 text-[#FF3B30]' : 'rotate-0'
            }`}
          />
        </button>

        {isHistoryOpen && (
          <div className="px-4 sm:px-5 pb-5 pt-3 border-t border-[#F0F0F0] space-y-4">
            {/* SEARCH, FILTER & SORT CONTROLS */}
            {historyItems.length > 0 && (
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row gap-2.5">
                  <div className="relative flex-1 flex items-center">
                    <Search className="w-4 h-4 text-[#8A8A8E] absolute left-3.5 pointer-events-none" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Cari nama app atau package name..."
                      className="nb-input w-full !pl-10 !py-2.5 text-xs font-semibold"
                    />
                  </div>

                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as HistorySort)}
                    className="nb-input !py-2.5 !px-3.5 text-xs font-bold text-[#111111] sm:w-44 cursor-pointer"
                  >
                    <option value="NEWEST">Terbaru</option>
                    <option value="OLDEST">Terlama</option>
                    <option value="NAME_ASC">Nama A-Z</option>
                  </select>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {(
                    [
                      { id: 'ALL', label: 'Semua' },
                      { id: 'SUCCESS', label: 'Berhasil' },
                      { id: 'FAILED', label: 'Gagal' },
                      { id: 'BUILDING', label: 'Building' }
                    ] as const
                  ).map((tab) => {
                    const active = filterStatus === tab.id;
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setFilterStatus(tab.id)}
                        className={`px-3.5 py-1.5 rounded-full text-xs font-extrabold transition-all cursor-pointer ${
                          active
                            ? 'bg-[#FF3B30] text-white shadow-[0_4px_12px_rgba(255,59,48,0.22)]'
                            : 'bg-[#F7F8FC] text-[#8A8A8E] hover:text-[#111111] border border-[#E8E8E8]'
                        }`}
                      >
                        {tab.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* EMPTY STATE OR LIST */}
            {historyItems.length === 0 ? (
              <div className="rounded-[14px] bg-[#FAFAFC] border border-[#F0F0F0] p-8 text-center space-y-3.5">
                <div className="w-14 h-14 rounded-2xl bg-[#FFE9E9] text-[#FF3B30] mx-auto flex items-center justify-center font-black text-xl">
                  <History className="w-7 h-7" />
                </div>
                <p className="text-sm font-black text-[#111111]">Belum ada APK</p>
                <button
                  type="button"
                  onClick={onGoToBuilder}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-[12px] bg-[#FF3B30] hover:bg-[#E0342A] text-white text-xs font-black uppercase tracking-[0.8px] shadow-[0_6px_18px_rgba(255,59,48,0.28)] cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Buat Sekarang</span>
                </button>
              </div>
            ) : filteredAndSortedItems.length === 0 ? (
              <div className="rounded-[14px] bg-[#FAFAFC] border border-[#F0F0F0] p-6 text-center space-y-2">
                <p className="text-xs font-bold text-[#8A8A8E]">
                  Tidak ada hasil yang cocok dengan pencarian/filter Anda.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setFilterStatus('ALL');
                  }}
                  className="text-xs font-black text-[#FF3B30] hover:underline cursor-pointer"
                >
                  Reset Filter
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredAndSortedItems.map((item) => {
                  const meta = getRealStatusMeta(item);
                  const modeLabel = getModeBadgeLabel(item);
                  const isRefreshing = !!refreshingIds[item.id];
                  const isSuccess = item.status === 'completed' && item.conclusion === 'success';
                  const isBuilding = item.status === 'queued' || item.status === 'in_progress';
                  const trimmedIconUrl = (item.icon_url || '').trim();
                  const hasValidIconScheme = /^https?:\/\/|^data:image\//i.test(trimmedIconUrl);
                  const showRealIcon = Boolean(hasValidIconScheme && !brokenIconIds[item.id]);
                  const initialLetter = (item.app_name || 'A').trim().charAt(0).toUpperCase();
                  const isConfirmingDelete = confirmDeleteItemId === item.id;

                  return (
                    <div
                      key={item.id}
                      className="rounded-[14px] bg-[#FAFAFC] border border-[#EAECEF] p-4 space-y-3 hover:border-[#FF3B30]/35 transition-all"
                    >
                      <div className="flex items-start gap-3.5">
                        {/* KIRI: ICON APK 56x56 */}
                        <div className="w-14 h-14 rounded-[14px] shrink-0 overflow-hidden border border-[#E8E8E8] bg-gradient-to-b from-[#FF3B30] to-[#C81E1E] flex items-center justify-center shadow-2xs">
                          {showRealIcon ? (
                            <img
                              src={trimmedIconUrl}
                              alt={item.app_name}
                              onError={() =>
                                setBrokenIconIds((prev) => ({ ...prev, [item.id]: true }))
                              }
                              onLoad={(e) => {
                                if (
                                  e.currentTarget.naturalWidth < 2 ||
                                  e.currentTarget.naturalHeight < 2
                                ) {
                                  setBrokenIconIds((prev) => ({ ...prev, [item.id]: true }));
                                }
                              }}
                              className="w-full h-full object-cover object-center block"
                            />
                          ) : (
                            <span className="text-[36px] font-black leading-none text-white select-none">
                              {initialLetter}
                            </span>
                          )}
                        </div>

                        {/* KANAN: NAMA + METADATA + STATUS */}
                        <div className="min-w-0 flex-1 space-y-1.5">
                          <div className="flex items-center justify-between gap-2 flex-wrap">
                            <h3 className="text-sm sm:text-base font-black text-[#111111] truncate">
                              {item.app_name}
                            </h3>
                            <span
                              className={`inline-flex items-center gap-1 text-[10px] font-black px-2.5 py-0.5 rounded-full border shrink-0 ${meta.badgeClass}`}
                            >
                              {meta.icon}
                              <span>{meta.label}</span>
                            </span>
                          </div>

                          <p className="text-[11px] font-semibold text-[#6E6E73] leading-relaxed break-words">
                            v{item.version_name} • {item.package_name} • {modeLabel} •{' '}
                            {formatRealDateTime(item.created_at)}
                          </p>

                          {item.error_message && meta.key === 'FAILED' && (
                            <p className="text-[11px] font-mono text-[#FF3B30] bg-[#FFE9E9]/70 border border-[#FFD6D4] rounded-[10px] px-2.5 py-1.5 break-words">
                              {item.error_message}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* TOMBOL AKSI: [Install] [Bagikan] [Hapus] (+ [Refresh Status] jika Building) */}
                      <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-[#EAECEF]">
                        <button
                          type="button"
                          disabled={!isSuccess || isDownloadingApk}
                          onClick={() => onDownloadItemApk(item)}
                          className={`px-3.5 py-2 rounded-[10px] text-xs font-black uppercase tracking-[0.5px] flex items-center gap-1.5 transition-all ${
                            isSuccess
                              ? 'bg-[#FF3B30] hover:bg-[#E0342A] text-white shadow-[0_4px_12px_rgba(255,59,48,0.22)] cursor-pointer'
                              : 'bg-white text-[#AAAAAA] border border-[#E8E8E8] cursor-not-allowed'
                          }`}
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Install</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleShareItem(item)}
                          className="px-3.5 py-2 rounded-[10px] bg-white hover:bg-[#F0F1F5] border border-[#E8E8E8] text-[#111111] text-xs font-bold uppercase tracking-[0.5px] flex items-center gap-1.5 transition-all cursor-pointer"
                        >
                          <Share2 className="w-3.5 h-3.5 text-[#FF3B30]" />
                          <span>Bagikan</span>
                        </button>

                        {isBuilding && item.run_id && (
                          <button
                            type="button"
                            disabled={isRefreshing}
                            onClick={() => onRefreshItemStatus(item)}
                            className="px-3.5 py-2 rounded-[10px] bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 text-xs font-extrabold uppercase tracking-[0.5px] flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-60"
                          >
                            <RefreshCw
                              className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`}
                            />
                            <span>Refresh Status</span>
                          </button>
                        )}

                        {isConfirmingDelete ? (
                          <div className="flex items-center gap-1.5 ml-auto bg-[#FFE9E9] border border-[#FFD6D4] px-2.5 py-1.5 rounded-[10px]">
                            <span className="text-[11px] font-bold text-[#FF3B30]">
                              Hapus item ini?
                            </span>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteItemId(null)}
                              className="px-2.5 py-1 rounded-[8px] bg-white text-[#111111] text-[10px] font-bold uppercase cursor-pointer"
                            >
                              Batal
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteItem(item.id);
                                setConfirmDeleteItemId(null);
                              }}
                              className="px-2.5 py-1 rounded-[8px] bg-[#FF3B30] text-white text-[10px] font-black uppercase cursor-pointer"
                            >
                              Ya, Hapus
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteItemId(item.id)}
                            className="px-3.5 py-2 rounded-[10px] bg-white hover:bg-[#FFE9E9] border border-[#E8E8E8] hover:border-[#FFD6D4] text-[#8A8A8E] hover:text-[#FF3B30] text-xs font-bold uppercase tracking-[0.5px] flex items-center gap-1.5 transition-all cursor-pointer ml-auto"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Hapus</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </section>

      {/* SECTION 3 - HAPUS SEMUA HISTORY (ALWAYS VISIBLE PINK BOX AT BOTTOM) */}
      <section
        id="apk-history-clear-section"
        className="rounded-[16px] bg-[#FFE9E9]/70 border border-[#FFD6D4] p-4 sm:p-5 space-y-3"
      >
        {confirmClearAll ? (
          <div className="space-y-3 text-center">
            <div className="flex items-center justify-center gap-2 text-[#FF3B30]">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <p className="text-xs sm:text-sm font-extrabold">
                Yakin hapus semua {historyItems.length} history? Tindakan ini tidak bisa dibatalkan
              </p>
            </div>
            <div className="flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setConfirmClearAll(false)}
                className="px-5 py-2.5 rounded-[12px] bg-white border border-[#E8E8E8] text-[#111111] text-xs font-extrabold uppercase tracking-[0.6px] cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearAll();
                  setConfirmClearAll(false);
                }}
                className="px-5 py-2.5 rounded-[12px] bg-[#FF3B30] hover:bg-[#E0342A] text-white text-xs font-black uppercase tracking-[0.6px] shadow-[0_4px_14px_rgba(255,59,48,0.28)] cursor-pointer"
              >
                Ya, Hapus Semua
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            disabled={historyItems.length === 0}
            onClick={() => setConfirmClearAll(true)}
            className="w-full py-3.5 px-4 rounded-[14px] bg-[#FF3B30] hover:bg-[#E0342A] disabled:bg-[#FF3B30]/40 disabled:cursor-not-allowed text-white text-xs sm:text-sm font-black uppercase tracking-[0.8px] flex items-center justify-center gap-2 shadow-[0_6px_18px_rgba(255,59,48,0.22)] transition-all cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>Hapus Semua History</span>
          </button>
        )}
      </section>
    </div>
  );
};
