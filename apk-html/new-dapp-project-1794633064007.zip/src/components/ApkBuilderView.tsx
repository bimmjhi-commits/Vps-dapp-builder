import React, { useState, useRef, useEffect } from 'react';
import {
  Smartphone,
  Settings,
  ArrowLeft,
  Globe,
  UploadCloud,
  Trash2,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Download,
  Code2,
  Eye,
  EyeOff,
  ChevronDown,
  Loader2,
  FileArchive,
  ClipboardPaste,
  Share2,
  Play,
  BookOpen,
  Maximize2,
  Minimize2,
  X
} from 'lucide-react';
import { ApkBuildMode, DispatchedPayload, LiveBuildState, ZipFileMeta } from '../types/apk';

interface ApkBuilderViewProps {
  // Builder Settings
  apkSubView: 'BUILD' | 'SETTINGS' | 'GUIDE';
  setApkSubView: (v: 'BUILD' | 'SETTINGS' | 'GUIDE') => void;
  githubUsername: string;
  setGithubUsername: (v: string) => void;
  githubRepo: string;
  setGithubRepo: (v: string) => void;
  githubToken: string;
  setGithubToken: (v: string) => void;
  imgbbApiKey: string;
  setImgbbApiKey: (v: string) => void;
  showGithubToken: boolean;
  setShowGithubToken: (v: boolean) => void;

  // 3 Build Modes: URL | ZIP | HTML
  apkBuildMode: ApkBuildMode;
  setApkBuildMode: (mode: ApkBuildMode) => void;

  // Shared Card 1 & Card 2 & Card 3 inputs
  apkAppName: string;
  onAppNameChange: (v: string) => void;
  apkPackageName: string;
  setApkPackageName: (v: string) => void;
  apkVersion: string;
  setApkVersion: (v: string) => void;
  apkUrl: string;
  setApkUrl: (v: string) => void;
  apkFullscreen: boolean;
  setApkFullscreen: React.Dispatch<React.SetStateAction<boolean>>;

  // Mode ZIP state
  zipFileMeta: ZipFileMeta | null;
  zipPublicUrl: string;
  isUploadingZip: boolean;
  zipUploadError: string;
  onProcessZipFile: (file: File) => Promise<void>;
  onRetryZipUpload: () => Promise<string | null>;
  onClearZipFile: () => void;

  // Mode HTML (paste source code) state
  htmlCodeText: string;
  setHtmlCodeText: (code: string) => void;
  htmlCodePublicUrl: string;
  isUploadingHtmlCode: boolean;
  htmlCodeUploadError: string;
  htmlMissingTagWarning: boolean;
  onConfirmProceedWithoutHtmlTag: () => void;
  onClearHtmlCode: () => void;

  // Deployer quick-fill URLs (helper in Mode URL)
  deployments: Array<{ id: string; projectName: string; url: string }>;

  // Icon upload state
  apkIconUrl: string;
  apkLogoBase64: string;
  apkIconDimensions: { width: number; height: number } | null;
  isUploadingIcon: boolean;
  apkIconError: string;
  hasPendingIconUpload: boolean;
  onProcessIconFile: (file: File) => Promise<void>;
  onRetryIconUpload: () => Promise<string | null>;
  onClearIcon: () => void;

  // Validators
  validatePackageNameFormat: (raw: string) => { valid: boolean; packageName: string; error?: string };
  normalizeAndValidateAppUrl: (raw: string) => { valid: boolean; url: string; error?: string };

  // Build & Actions
  isBuildingApk: boolean;
  isDownloadingApk: boolean;
  liveBuild: LiveBuildState;
  lastDispatchedPayload: DispatchedPayload | null;
  onStartBuild: (forceIgnoreMissingHtmlTag?: boolean) => void;
  onRecheckRun: () => void;
  onSaveAsZip: () => void;
  onDownloadApk: (artifactUrl: string, appName: string) => void;
  onCopy: (text: string) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const SAMPLE_HTML_TEMPLATE = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Aplikasi Saya</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #EEF0F5;
      color: #111111;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .card {
      background: #FFFFFF;
      border-radius: 18px;
      padding: 28px;
      max-width: 400px;
      width: 100%;
      text-align: center;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
    }
    h1 { color: #FF3B30; font-size: 22px; margin-bottom: 10px; }
    p { color: #636366; font-size: 14px; line-height: 1.5; margin-bottom: 18px; }
    button {
      background: #FF3B30;
      color: #FFFFFF;
      border: none;
      padding: 12px 20px;
      border-radius: 12px;
      font-weight: 700;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Aplikasi Offline Siap</h1>
    <p>Aplikasi ini berjalan offline langsung dari source code HTML Anda.</p>
    <button onclick="alert('Halo dari aplikasi HTML!')">Tes Tombol</button>
  </div>
</body>
</html>`;

export const ApkBuilderView: React.FC<ApkBuilderViewProps> = ({
  apkSubView,
  setApkSubView,
  githubUsername,
  setGithubUsername,
  githubRepo,
  setGithubRepo,
  githubToken,
  setGithubToken,
  imgbbApiKey,
  setImgbbApiKey,
  showGithubToken,
  setShowGithubToken,
  apkBuildMode,
  setApkBuildMode,
  apkAppName,
  onAppNameChange,
  apkPackageName,
  setApkPackageName,
  apkVersion,
  setApkVersion,
  apkUrl,
  setApkUrl,
  apkFullscreen,
  setApkFullscreen,
  zipFileMeta,
  zipPublicUrl,
  isUploadingZip,
  zipUploadError,
  onProcessZipFile,
  onRetryZipUpload,
  onClearZipFile,
  htmlCodeText,
  setHtmlCodeText,
  htmlCodePublicUrl,
  isUploadingHtmlCode,
  htmlCodeUploadError,
  htmlMissingTagWarning,
  onConfirmProceedWithoutHtmlTag,
  onClearHtmlCode,
  deployments,
  apkIconUrl,
  apkLogoBase64,
  apkIconDimensions,
  isUploadingIcon,
  apkIconError,
  hasPendingIconUpload,
  onProcessIconFile,
  onRetryIconUpload,
  onClearIcon,
  validatePackageNameFormat,
  normalizeAndValidateAppUrl,
  isBuildingApk,
  isDownloadingApk,
  liveBuild,
  lastDispatchedPayload,
  onStartBuild,
  onRecheckRun,
  onSaveAsZip,
  onDownloadApk,
  onCopy,
  showToast
}) => {
  const [isDraggingIcon, setIsDraggingIcon] = useState(false);
  const [isDraggingZip, setIsDraggingZip] = useState(false);
  const [isHtmlEditorFullscreen, setIsHtmlEditorFullscreen] = useState(false);
  const [previewIconFailed, setPreviewIconFailed] = useState(false);
  const [confirmNewDispatch, setConfirmNewDispatch] = useState(false);
  const [codeCheckResult, setCodeCheckResult] = useState<{
    checked: boolean;
    isEmpty: boolean;
    hasHtmlTag: boolean;
    hasBodyTag: boolean;
    hasDoctype: boolean;
  } | null>(null);

  const codeTextareaRef = useRef<HTMLTextAreaElement | null>(null);
  const lineNumbersRef = useRef<HTMLDivElement | null>(null);
  const fullscreenLineNumbersRef = useRef<HTMLDivElement | null>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleIconDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingIcon(false);
    if (isUploadingIcon) return;
    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile) {
      await onProcessIconFile(droppedFile);
    }
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      await onProcessIconFile(selected);
    }
  };

  const handleZipDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingZip(false);
    if (isUploadingZip) return;
    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile) {
      await onProcessZipFile(droppedFile);
    }
  };

  const handleZipInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      await onProcessZipFile(selected);
    }
  };

  const handlePasteFromClipboard = async () => {
    try {
      if (!navigator.clipboard?.readText) {
        showToast('Browser tidak mendukung baca clipboard otomatis. Tekan Ctrl+V di kolom kode.', 'info');
        codeTextareaRef.current?.focus();
        return;
      }
      const clipText = await navigator.clipboard.readText();
      if (!clipText.trim()) {
        showToast('Clipboard masih kosong.', 'info');
        return;
      }
      setHtmlCodeText(clipText);
      setCodeCheckResult(null);
      showToast('Kode HTML berhasil di-paste dari clipboard!', 'success');
    } catch {
      showToast('Izin clipboard ditolak browser. Tekan Ctrl+V langsung di kolom kode.', 'error');
      codeTextareaRef.current?.focus();
    }
  };

  const handleValidateHtmlCode = () => {
    const trimmed = htmlCodeText.trim();
    if (!trimmed) {
      setCodeCheckResult({
        checked: true,
        isEmpty: true,
        hasHtmlTag: false,
        hasBodyTag: false,
        hasDoctype: false
      });
      showToast('Kode HTML masih kosong, paste dulu.', 'error');
      return;
    }
    const lower = trimmed.toLowerCase();
    const hasHtmlTag = /<html[\s>]/i.test(lower) && /<\/html>/i.test(lower);
    const hasBodyTag = /<body[\s>]/i.test(lower);
    const hasDoctype = lower.includes('<!doctype');

    setCodeCheckResult({
      checked: true,
      isEmpty: false,
      hasHtmlTag,
      hasBodyTag,
      hasDoctype
    });

    if (!hasHtmlTag) {
      showToast('Peringatan: tag <html> lengkap tidak ditemukan.', 'info');
    } else if (!hasBodyTag) {
      showToast('Tag <html> ada, namun tag <body> belum ditemukan.', 'info');
    } else {
      showToast('Validasi kode HTML lengkap (<html> & <body> ditemukan)!', 'success');
    }
  };

  const handleShareApk = async () => {
    const appTitle = apkAppName.trim() || 'Aplikasi APK';
    const shareTarget = liveBuild.artifactUrl || liveBuild.runUrl;
    if (!shareTarget) {
      showToast('Link unduhan belum tersedia.', 'error');
      return;
    }
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `${appTitle} (APK)`,
          text: `Download APK ${appTitle} (${apkPackageName})`,
          url: shareTarget
        });
        return;
      } catch (err: any) {
        if (err?.name === 'AbortError') return;
      }
    }
    onCopy(shareTarget);
    showToast('Link disalin', 'success');
  };

  const activePreviewIcon = (apkIconUrl || apkLogoBase64).trim();
  const isValidPreviewUrl = Boolean(
    activePreviewIcon && (/^https?:\/\//i.test(activePreviewIcon) || /^data:image\//i.test(activePreviewIcon))
  );
  const showUploadedIconPreview = isValidPreviewUrl && !previewIconFailed;

  useEffect(() => {
    setPreviewIconFailed(false);
  }, [activePreviewIcon]);

  useEffect(() => {
    if (liveBuild.phase === 'idle' || liveBuild.phase === 'dispatching' || liveBuild.phase === 'locating_run') {
      setConfirmNewDispatch(false);
    }
  }, [liveBuild.phase]);

  const pkgValidation = validatePackageNameFormat(apkPackageName);
  const urlValidation = apkUrl.trim() ? normalizeAndValidateAppUrl(apkUrl) : null;
  const isAiStudioUrl = apkUrl.toLowerCase().includes('aistudio.google.com');

  const htmlLineCount = htmlCodeText ? htmlCodeText.split('\n').length : 1;
  const htmlCharCount = htmlCodeText.length;

  // SETTINGS SUBVIEW (INLINE)
  if (apkSubView === 'SETTINGS') {
    return (
      <div className="space-y-5 animate-in fade-in pb-8">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
            <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
              <Settings className="w-5 h-5" />
            </span>
            <span>PENGATURAN BUILDER</span>
          </h1>
          <button
            type="button"
            onClick={() => setApkSubView('BUILD')}
            className="nb-btn-secondary px-3.5 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-[#FF3B30]" />
            <span>Kembali ke Builder</span>
          </button>
        </div>

        <div className="rounded-[16px] bg-white border border-[#E8E8E8] shadow-[0_4px_20px_rgba(0,0,0,0.04)] p-5 sm:p-6 space-y-4">
          <div>
            <h2 className="text-sm font-extrabold uppercase tracking-[0.8px] text-[#111111]">
              KONFIGURASI GITHUB ACTIONS BUILDER
            </h2>
            <p className="text-xs text-[#8A8A8E] mt-0.5 leading-relaxed">
              Terhubung ke workflow <span className="font-mono font-bold text-[#111111]">build.yml</span> di GitHub Actions untuk kompilasi file <span className="font-bold text-[#FF3B30]">.apk</span> secara nyata (Mode URL, ZIP, dan HTML).
            </p>
          </div>

          <div className="space-y-3.5 pt-1">
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111] block">
                GITHUB USERNAME
              </label>
              <input
                type="text"
                value={githubUsername}
                onChange={(e) => {
                  setGithubUsername(e.target.value);
                  localStorage.setItem('dapp_github_username', e.target.value);
                }}
                placeholder="bimmjhi-commits"
                className="nb-input w-full !py-3 !px-3.5 text-xs font-semibold"
              />
              <p className="text-[11px] text-[#8A8A8E]">
                Default: <span className="font-bold text-[#111111]">bimmjhi-commits</span>
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111] block">
                NAMA REPO
              </label>
              <input
                type="text"
                value={githubRepo}
                onChange={(e) => {
                  setGithubRepo(e.target.value);
                  localStorage.setItem('dapp_github_repo', e.target.value);
                }}
                placeholder="Vps-dapp-builder"
                className="nb-input w-full !py-3 !px-3.5 text-xs font-semibold"
              />
              <p className="text-[11px] text-[#8A8A8E]">
                Default: <span className="font-bold text-[#111111]">Vps-dapp-builder</span>
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-[0.8px] text-[#8A8A8E] block">
                WORKFLOW FILE
              </label>
              <div className="p-3 rounded-[14px] bg-[#F7F8FC] border border-[#E8E8E8] flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-[#111111]">build.yml</span>
                <span className="text-[10px] font-black uppercase text-[#FF3B30] bg-[#FFE9E9] px-2.5 py-0.5 rounded-full">
                  TERHUBUNG
                </span>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">
                  GITHUB TOKEN
                </label>
                {githubToken.trim() ? (
                  <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                    Token Terisi
                  </span>
                ) : (
                  <span className="text-[10px] font-black text-[#FF3B30] bg-[#FFE9E9] px-2.5 py-0.5 rounded-full">
                    Wajib Diisi
                  </span>
                )}
              </div>
              <div className="relative flex items-center">
                <input
                  type={showGithubToken ? 'text' : 'password'}
                  value={githubToken}
                  onChange={(e) => {
                    setGithubToken(e.target.value);
                    localStorage.setItem('dapp_github_token', e.target.value);
                  }}
                  placeholder="ghp_... atau github_pat_..."
                  className="nb-input w-full !py-3 !pl-3.5 !pr-10 text-xs font-semibold"
                />
                <button
                  type="button"
                  onClick={() => setShowGithubToken(!showGithubToken)}
                  className="absolute right-3 p-1 text-[#8A8A8E] hover:text-[#111111] cursor-pointer"
                >
                  {showGithubToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-[#8A8A8E] leading-relaxed">
                Personal Access Token (PAT) GitHub dengan scope <span className="font-bold text-[#111111]">repo</span> &amp; <span className="font-bold text-[#111111]">workflow</span> untuk memicu workflow dispatch, polling status, unduh artifact, dan upload icon/ZIP/HTML.
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-[0.8px] text-[#111111]">
                  IMGBB API KEY (OPSIONAL)
                </label>
                <span className="text-[10px] font-bold text-[#8A8A8E] bg-[#F7F8FC] px-2.5 py-0.5 rounded-full border border-[#E8E8E8]">
                  {imgbbApiKey.trim() ? 'Pakai ImgBB' : 'Default: Upload ke GitHub'}
                </span>
              </div>
              <input
                type="text"
                value={imgbbApiKey}
                onChange={(e) => {
                  setImgbbApiKey(e.target.value);
                  localStorage.setItem('dapp_imgbb_api_key', e.target.value);
                }}
                placeholder="Kosongkan untuk upload icon otomatis ke GitHub Repo"
                className="nb-input w-full !py-3 !px-3.5 text-xs font-semibold"
              />
              <p className="text-[11px] text-[#8A8A8E] leading-relaxed">
                Jika dikosongkan, icon otomatis diupload ke repositori GitHub (<span className="font-mono">apk-icons/</span>). Jika diisi, icon diupload ke ImgBB.
              </p>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
            <button
              type="button"
              onClick={async () => {
                if (!githubToken.trim()) {
                  showToast('Masukkan GitHub Token terlebih dahulu!', 'error');
                  return;
                }
                showToast('Pengaturan Builder berhasil disimpan!', 'success');
                setApkSubView('BUILD');
                if (hasPendingIconUpload && !apkIconUrl) {
                  await onRetryIconUpload();
                }
                if (zipFileMeta && !zipPublicUrl) {
                  await onRetryZipUpload();
                }
              }}
              className="nb-btn-primary w-full sm:flex-1 py-3.5 text-xs uppercase tracking-[0.8px] cursor-pointer"
            >
              SIMPAN &amp; KEMBALI
            </button>
          </div>
        </div>
      </div>
    );
  }

  // GUIDE SUBVIEW (CARA PENGGUNAAN BUILDER)
  if (apkSubView === 'GUIDE') {
    return (
      <div className="space-y-5 animate-in fade-in pb-8">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
            <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
              <BookOpen className="w-5 h-5" />
            </span>
            <span>CARA PENGGUNAAN WEB TO APK</span>
          </h1>
          <button
            type="button"
            onClick={() => setApkSubView('BUILD')}
            className="nb-btn-secondary px-3.5 py-2 text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 text-[#FF3B30]" />
            <span>Kembali ke Builder</span>
          </button>
        </div>

        <div className="rounded-[16px] bg-white border border-[#E8E8E8] shadow-[0_4px_20px_rgba(0,0,0,0.04)] p-5 sm:p-6 space-y-4 text-xs">
          <div className="nb-card-sub p-4 space-y-1">
            <p className="text-sm font-extrabold text-[#111111] uppercase tracking-[0.8px]">
              1. Atur GitHub Token di Settings Endpoint
            </p>
            <p className="text-[#8A8A8E] font-medium leading-relaxed">
              Masukkan Personal Access Token GitHub dengan akses repo &amp; workflow agar aplikasi dapat memicu GitHub Actions (<span className="font-mono font-bold text-[#111111]">build.yml</span>) dan mengupload aset secara otomatis.
            </p>
          </div>

          <div className="nb-card-sub p-4 space-y-1">
            <p className="text-sm font-extrabold text-[#111111] uppercase tracking-[0.8px]">
              2. Pilih Mode Sumber (URL / ZIP / HTML)
            </p>
            <p className="text-[#8A8A8E] font-medium leading-relaxed">
              Gunakan Mode <strong>URL</strong> untuk website publik, Mode <strong>ZIP</strong> untuk bundle offline yang berisi <span className="font-mono font-bold text-[#111111]">index.html</span>, atau Mode <strong>HTML</strong> untuk paste langsung source code HTML Anda.
            </p>
          </div>

          <div className="nb-card-sub p-4 space-y-1">
            <p className="text-sm font-extrabold text-[#111111] uppercase tracking-[0.8px]">
              3. Upload Icon &amp; Klik Buat APK
            </p>
            <p className="text-[#8A8A8E] font-medium leading-relaxed">
              Upload icon PNG/JPG (disarankan 512x512px) atau biarkan kosong untuk icon huruf default, lalu klik <strong>BUAT &amp; INSTAL APK</strong> dan pantau progres langsung dari GitHub API.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // KALKULASI PROGRESS BAR 100% DARI STATUS GITHUB API (DILARANG TIMER / FAKE INCREMENT)
  const getProgressFromApi = (): {
    percent: number;
    statusText: string;
    barColorClass: string;
    isSuccess: boolean;
    isFailed: boolean;
    isDispatchError: boolean;
    isRunTimeout: boolean;
    isLocating: boolean;
  } => {
    if (liveBuild.dispatchStatus === 'error') {
      return {
        percent: 0,
        statusText: 'Gagal Memicu Build',
        barColorClass: 'bg-[#FF3B30]',
        isSuccess: false,
        isFailed: true,
        isDispatchError: true,
        isRunTimeout: false,
        isLocating: false
      };
    }

    if (liveBuild.phase === 'error' && liveBuild.runNotFoundTimeout) {
      return {
        percent: 10,
        statusText: 'GitHub masih memproses, cek di Lihat Log / buka GitHub Actions manual',
        barColorClass: 'bg-amber-500',
        isSuccess: false,
        isFailed: false,
        isDispatchError: false,
        isRunTimeout: true,
        isLocating: false
      };
    }

    if (liveBuild.phase === 'error' && liveBuild.githubStatus !== 'completed') {
      return {
        percent: 0,
        statusText: 'Gagal Memeriksa Status Run',
        barColorClass: 'bg-[#FF3B30]',
        isSuccess: false,
        isFailed: true,
        isDispatchError: false,
        isRunTimeout: false,
        isLocating: false
      };
    }

    if (liveBuild.githubStatus === 'completed') {
      if (liveBuild.githubConclusion === 'success') {
        return {
          percent: 100,
          statusText: 'Selesai',
          barColorClass: 'bg-emerald-500',
          isSuccess: true,
          isFailed: false,
          isDispatchError: false,
          isRunTimeout: false,
          isLocating: false
        };
      }
      return {
        percent: 100,
        statusText: 'Build Gagal',
        barColorClass: 'bg-[#FF3B30]',
        isSuccess: false,
        isFailed: true,
        isDispatchError: false,
        isRunTimeout: false,
        isLocating: false
      };
    }

    if (liveBuild.githubStatus === 'in_progress') {
      return {
        percent: 70,
        statusText: 'Compiling...',
        barColorClass: 'bg-[#FF3B30]',
        isSuccess: false,
        isFailed: false,
        isDispatchError: false,
        isRunTimeout: false,
        isLocating: false
      };
    }

    if (liveBuild.githubStatus === 'queued') {
      return {
        percent: 30,
        statusText: 'Antrian Server...',
        barColorClass: 'bg-[#FF3B30]',
        isSuccess: false,
        isFailed: false,
        isDispatchError: false,
        isRunTimeout: false,
        isLocating: false
      };
    }

    if (liveBuild.phase === 'locating_run' || liveBuild.dispatchStatus === 'success') {
      const elapsed = liveBuild.locateElapsedSec ?? 5;
      return {
        percent: 10,
        statusText: `Mengirim ke GitHub... Menunggu Run dibuat... (${elapsed}s)`,
        barColorClass: 'bg-[#FF3B30]',
        isSuccess: false,
        isFailed: false,
        isDispatchError: false,
        isRunTimeout: false,
        isLocating: true
      };
    }

    return {
      percent: 5,
      statusText: 'Mengirim ke GitHub...',
      barColorClass: 'bg-[#FF3B30]',
      isSuccess: false,
      isFailed: false,
      isDispatchError: false,
      isRunTimeout: false,
      isLocating: true
    };
  };

  const progressInfo = getProgressFromApi();
  const displayAppName = apkAppName.trim() || 'Aplikasi-Ku';
  const displayFirstLetter = displayAppName.charAt(0).toUpperCase() || 'A';
  const displayPackage = apkPackageName.trim() || 'com.namamu.app';
  const displayVersion = apkVersion.trim() || '1.0';
  const sentTimeLabel = liveBuild.dispatchTime || lastDispatchedPayload?.sentAt || '-';

  return (
    <div className="space-y-5 animate-in fade-in pb-8">
      {/* HEADER BUILDER */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl sm:text-2xl font-black tracking-[0.8px] uppercase text-[#111111] flex items-center gap-2.5">
            <span className="p-2 rounded-[14px] bg-[#FFE9E9] text-[#FF3B30]">
              <Smartphone className="w-5 h-5" />
            </span>
            <span>WEB TO APK BUILDER</span>
          </h1>
          <p className="text-xs text-[#8A8A8E] font-medium mt-1">
            Target Workflow:{' '}
            <span className="font-mono font-bold text-[#111111]">
              {githubUsername || 'bimmjhi-commits'}/{githubRepo || 'Vps-dapp-builder'}
            </span>{' '}
            (<span className="font-mono text-[#FF3B30]">build.yml</span>)
          </p>
        </div>

        <button
          type="button"
          onClick={() => setApkSubView('SETTINGS')}
          className="px-3.5 py-2 rounded-[14px] border border-[#E8E8E8] bg-white text-[#111111] hover:text-[#FF3B30] hover:bg-[#FFE9E9] text-xs font-bold uppercase tracking-[0.8px] transition-all flex items-center gap-1.5 shadow-[0_2px_8px_rgba(0,0,0,0.03)] cursor-pointer"
        >
          <Settings className="w-4 h-4 text-[#FF3B30]" />
          <span>Pengaturan Builder</span>
          {!githubToken.trim() && (
            <span className="w-2 h-2 rounded-full bg-[#FF3B30]" title="Token belum diisi" />
          )}
        </button>
      </div>

      {/* FORM INPUT BUILDER (3 CARD, TANPA DUPLIKAT INPUT) */}
      <div className="space-y-4">
        {/* CARD 1 - INFORMASI APLIKASI */}
        <div className="rounded-[16px] bg-white border border-[#E8E8E8] shadow-[0_4px_20px_rgba(0,0,0,0.04)] p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <span className="w-6 h-6 rounded-[8px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center text-xs font-black">
              1
            </span>
            <h2 className="text-xs font-black uppercase tracking-[0.8px] text-[#111111]">
              Informasi Aplikasi
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#111111] block">
                App Name
              </label>
              <input
                type="text"
                value={apkAppName}
                onChange={(e) => onAppNameChange(e.target.value)}
                placeholder="contoh: Toko Saya"
                className="nb-input w-full !py-3 !px-3.5 text-xs font-semibold"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#111111] block">
                Package Name
              </label>
              <input
                type="text"
                value={apkPackageName}
                onChange={(e) => {
                  const sanitized = e.target.value.toLowerCase().replace(/[^a-z0-9._]/g, '');
                  setApkPackageName(sanitized);
                }}
                placeholder="com.namamu.app"
                className={`nb-input w-full !py-3 !px-3.5 text-xs font-mono font-semibold ${
                  apkPackageName && !pkgValidation.valid ? '!border-[#FF3B30] bg-[#FFE9E9]/30' : ''
                }`}
              />
              {apkPackageName && !pkgValidation.valid && (
                <p className="text-[10px] font-bold text-[#FF3B30]">
                  Wajib format com.xxx.xxx (huruf kecil semua)
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#111111] block">
                Version Name
              </label>
              <input
                type="text"
                value={apkVersion}
                onChange={(e) => setApkVersion(e.target.value)}
                placeholder="1.0"
                className="nb-input w-full !py-3 !px-3.5 text-xs font-semibold"
              />
            </div>
          </div>
        </div>

        {/* PILIHAN 3 TAB MODE DI ATAS CARD 2: [ URL ] [ ZIP ] [ HTML ] */}
        <div
          role="tablist"
          aria-label="Pilihan Sumber APK"
          className="rounded-[16px] bg-white border border-[#E8E8E8] shadow-[0_4px_20px_rgba(0,0,0,0.04)] p-2 grid grid-cols-3 gap-2"
        >
          {(
            [
              { id: 'URL', label: 'URL', icon: <Globe className="w-4 h-4 shrink-0" /> },
              { id: 'ZIP', label: 'ZIP', icon: <FileArchive className="w-4 h-4 shrink-0" /> },
              { id: 'HTML', label: 'HTML', icon: <Code2 className="w-4 h-4 shrink-0" /> }
            ] as const
          ).map((modeTab) => {
            const active = apkBuildMode === modeTab.id;
            return (
              <button
                key={modeTab.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setApkBuildMode(modeTab.id)}
                className={`py-3 px-3 rounded-[12px] text-xs font-black uppercase tracking-[0.8px] flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  active
                    ? 'bg-[#FF3B30] text-white shadow-[0_4px_14px_rgba(255,59,48,0.25)]'
                    : 'bg-[#F7F8FC] text-[#636366] hover:text-[#111111] hover:bg-[#EEF0F5]'
                }`}
              >
                {modeTab.icon}
                <span>{modeTab.label}</span>
              </button>
            );
          })}
        </div>

        {/* CARD 2 - KONTEN AKTIF SESUAI 1 MODE YANG DIPILIH + TOGGLE FULLSCREEN */}
        <div className="rounded-[16px] bg-white border border-[#E8E8E8] shadow-[0_4px_20px_rgba(0,0,0,0.04)] p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-[8px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center text-xs font-black">
                2
              </span>
              <h2 className="text-xs font-black uppercase tracking-[0.8px] text-[#111111]">
                {apkBuildMode === 'URL'
                  ? 'Website (Dari URL)'
                  : apkBuildMode === 'ZIP'
                  ? 'File ZIP (Offline)'
                  : 'Source Code HTML (Paste Kode)'}
              </h2>
            </div>

            <span className="text-[10px] font-black uppercase tracking-[0.6px] px-2.5 py-0.5 rounded-full bg-[#FFE9E9] text-[#FF3B30]">
              source_type=&quot;{apkBuildMode.toLowerCase()}&quot;
            </span>
          </div>

          {/* MODE URL */}
          {apkBuildMode === 'URL' && (
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-[0.8px] text-[#111111] block">
                App URL
              </label>
              <div className="relative flex items-center">
                <Globe className="w-4 h-4 text-[#8A8A8E] absolute left-3.5 pointer-events-none" />
                <input
                  type="url"
                  value={apkUrl}
                  onChange={(e) => setApkUrl(e.target.value)}
                  onBlur={() => {
                    if (apkUrl.trim() && !/^https?:\/\//i.test(apkUrl.trim())) {
                      setApkUrl(`https://${apkUrl.trim().replace(/^\/+/, '')}`);
                    }
                  }}
                  placeholder="https://namaweb.vercel.app"
                  className={`nb-input w-full !pl-10 !py-3.5 text-xs font-semibold ${
                    urlValidation && !urlValidation.valid ? '!border-[#FF3B30] bg-[#FFE9E9]/30' : ''
                  }`}
                />
              </div>

              {urlValidation && !urlValidation.valid ? (
                <div className="p-3 rounded-[12px] bg-[#FFE9E9]/80 border border-[#FF3B30]/30 space-y-2">
                  <p className="text-[11px] font-bold text-[#FF3B30] flex items-start gap-1.5">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{urlValidation.error}</span>
                  </p>
                  {isAiStudioUrl && (
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => setApkBuildMode('ZIP')}
                        className="text-[10px] font-black uppercase tracking-[0.5px] px-3 py-1.5 rounded-[8px] bg-[#111111] text-white cursor-pointer"
                      >
                        Pakai Mode ZIP
                      </button>
                      <button
                        type="button"
                        onClick={() => setApkBuildMode('HTML')}
                        className="text-[10px] font-black uppercase tracking-[0.5px] px-3 py-1.5 rounded-[8px] bg-[#FF3B30] text-white cursor-pointer"
                      >
                        Pakai Mode HTML
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-[11px] text-[#8A8A8E]">
                  Otomatis menambahkan <span className="font-mono font-bold text-[#111111]">https://</span> jika belum ada.
                </p>
              )}

              {deployments.length > 0 && (
                <div className="pt-1.5 flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-[0.5px] text-[#8A8A8E]">
                    Dari Deployer:
                  </span>
                  {deployments.slice(0, 4).map((dep) => (
                    <button
                      key={dep.id}
                      type="button"
                      onClick={() => {
                        setApkUrl(dep.url);
                        if (!apkAppName.trim()) onAppNameChange(dep.projectName);
                      }}
                      className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-[#F7F8FC] hover:bg-[#FFE9E9] text-[#111111] hover:text-[#FF3B30] border border-[#E8E8E8] transition-colors cursor-pointer"
                    >
                      {dep.projectName}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* MODE ZIP */}
          {apkBuildMode === 'ZIP' && (
            <div className="space-y-3">
              <input
                type="file"
                id="apkZipFileInput"
                accept=".zip,application/zip,application/x-zip-compressed"
                onChange={handleZipInputChange}
                className="hidden"
              />

              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDraggingZip(true);
                }}
                onDragLeave={() => setIsDraggingZip(false)}
                onDrop={handleZipDrop}
                onClick={() => !isUploadingZip && document.getElementById('apkZipFileInput')?.click()}
                className={`rounded-[14px] border-2 border-dashed p-5 text-center transition-all cursor-pointer select-none ${
                  isDraggingZip
                    ? 'border-[#FF3B30] bg-[#FFE9E9]/40'
                    : 'border-[#E0E2EA] bg-[#F7F8FC] hover:border-[#FF3B30]/60 hover:bg-[#FAFAFC]'
                } ${isUploadingZip ? 'opacity-60 pointer-events-none' : ''}`}
              >
                <div className="flex flex-col items-center gap-1.5">
                  {isUploadingZip ? (
                    <Loader2 className="w-7 h-7 text-[#FF3B30] animate-spin" />
                  ) : (
                    <FileArchive className="w-7 h-7 text-[#FF3B30]" />
                  )}
                  <p className="text-xs font-extrabold text-[#111111]">
                    {isUploadingZip
                      ? 'Mengupload file .zip ke GitHub...'
                      : 'Drag & drop file .zip di sini, atau klik untuk pilih file'}
                  </p>
                  <p className="text-[11px] font-semibold text-[#8A8A8E]">
                    Hanya menerima file .zip (maks. 10 MB) dan wajib berisi index.html di dalamnya
                  </p>
                </div>
              </div>

              {zipFileMeta && (
                <div className="p-4 rounded-[14px] bg-[#F7F8FC] border border-[#E8E8E8] space-y-2.5">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-9 h-9 rounded-[10px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center shrink-0">
                        <FileArchive className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-black text-[#111111] truncate">{zipFileMeta.name}</p>
                        <p className="text-[11px] font-semibold text-[#8A8A8E]">
                          {formatFileSize(zipFileMeta.sizeBytes)} • index.html terverifikasi
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={onClearZipFile}
                      className="px-3 py-1.5 rounded-[10px] bg-white border border-[#E8E8E8] hover:bg-[#FFE9E9] text-[#FF3B30] text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Hapus File</span>
                    </button>
                  </div>

                  {zipPublicUrl && (
                    <div className="p-2.5 rounded-[10px] bg-emerald-50 border border-emerald-200 space-y-1">
                      <p className="text-[10px] font-black text-emerald-800 uppercase">
                        HTML_URL ZIP PUBLIK SIAP DIKIRIM (source_type=&quot;zip&quot;):
                      </p>
                      <p className="text-[11px] font-mono text-emerald-800 break-all">{zipPublicUrl}</p>
                    </div>
                  )}
                </div>
              )}

              {zipUploadError && (
                <div className="p-3 rounded-[12px] bg-[#FFE9E9]/80 border border-[#FF3B30]/30 space-y-2">
                  <p className="text-[11px] font-bold text-[#FF3B30] leading-relaxed">{zipUploadError}</p>
                  {zipFileMeta && (
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        disabled={isUploadingZip}
                        onClick={onRetryZipUpload}
                        className="text-[10px] font-extrabold px-3 py-1.5 rounded-[8px] bg-[#FF3B30] text-white hover:bg-[#E0342A] flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" /> Coba Upload Ulang
                      </button>
                      <button
                        type="button"
                        onClick={() => setApkSubView('SETTINGS')}
                        className="text-[10px] font-extrabold px-3 py-1.5 rounded-[8px] bg-white border border-[#FF3B30]/30 text-[#FF3B30] hover:bg-[#FFE9E9] cursor-pointer"
                      >
                        Buka Pengaturan Builder
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* MODE HTML - PASTE SOURCE CODE (TANPA UPLOAD FILE / DRAG & DROP) */}
          {apkBuildMode === 'HTML' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <label
                  htmlFor="htmlSourceTextarea"
                  className="text-[11px] font-black uppercase tracking-[0.8px] text-[#111111]"
                >
                  Paste Source Code HTML Di Sini
                </label>

                <span className="text-[11px] font-mono font-bold text-[#8A8A8E] tabular-nums">
                  {htmlLineCount} baris • {htmlCharCount.toLocaleString('id-ID')} karakter
                </span>
              </div>

              {/* TOOLBAR ATAS TEXTAREA */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handlePasteFromClipboard}
                  className="px-3 py-1.5 rounded-[10px] bg-[#111111] hover:bg-[#2C2C2E] text-white text-[11px] font-extrabold flex items-center gap-1.5 cursor-pointer"
                >
                  <ClipboardPaste className="w-3.5 h-3.5 text-[#FF3B30]" />
                  <span>Paste Dari Clipboard</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setHtmlCodeText(SAMPLE_HTML_TEMPLATE);
                    setCodeCheckResult(null);
                    showToast('Contoh HTML dimasukkan.', 'info');
                  }}
                  className="px-3 py-1.5 rounded-[10px] bg-[#F7F8FC] hover:bg-[#FFE9E9] border border-[#E8E8E8] text-[#111111] hover:text-[#FF3B30] text-[11px] font-extrabold flex items-center gap-1.5 cursor-pointer"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Contoh HTML</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onClearHtmlCode();
                    setCodeCheckResult(null);
                  }}
                  className="px-3 py-1.5 rounded-[10px] bg-white hover:bg-[#FFE9E9] border border-[#E8E8E8] text-[#8A8A8E] hover:text-[#FF3B30] text-[11px] font-bold flex items-center gap-1.5 cursor-pointer ml-auto"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Hapus</span>
                </button>
              </div>

              {/* TEXTAREA COMPACT (TINGGI DEFAULT 180px, MAX 320px, SCROLL DI DALAM) + TOMBOL PERBESAR */}
              <div className="relative rounded-[14px] border border-[#E0E2EA] bg-[#1C1C1E] overflow-hidden flex h-[180px] min-h-[180px] max-h-[320px] resize-y focus-within:border-[#FF3B30] transition-colors">
                <button
                  type="button"
                  onClick={() => setIsHtmlEditorFullscreen(true)}
                  title="Perbesar / Fullscreen Editor"
                  className="absolute top-2 right-2 z-10 px-2.5 py-1 rounded-[8px] bg-white/10 hover:bg-white/20 border border-white/15 text-[#F5F5F7] text-[10px] font-bold flex items-center gap-1 backdrop-blur-xs transition-colors cursor-pointer"
                >
                  <Maximize2 className="w-3 h-3 text-[#FF3B30]" />
                  <span>Perbesar</span>
                </button>

                <div
                  ref={lineNumbersRef}
                  aria-hidden="true"
                  className="h-full py-3 px-2.5 bg-[#141416] border-r border-white/10 text-[#636366] font-mono text-xs leading-6 text-right select-none overflow-hidden min-w-[44px] shrink-0"
                >
                  {Array.from({ length: htmlLineCount }, (_, idx) => (
                    <div key={idx}>{idx + 1}</div>
                  ))}
                </div>

                <textarea
                  id="htmlSourceTextarea"
                  ref={codeTextareaRef}
                  value={htmlCodeText}
                  onChange={(e) => {
                    setHtmlCodeText(e.target.value);
                    setCodeCheckResult(null);
                  }}
                  onScroll={(e) => {
                    if (lineNumbersRef.current) {
                      lineNumbersRef.current.scrollTop = e.currentTarget.scrollTop;
                    }
                  }}
                  spellCheck={false}
                  placeholder="<!DOCTYPE html> <html> ... paste kode HTML lu di sini ..."
                  className="flex-1 h-full p-3 pr-24 bg-transparent text-[#F5F5F7] placeholder:text-[#6E6E73] font-mono text-xs leading-6 resize-none focus:outline-none overflow-y-auto"
                />
              </div>

              {/* TOMBOL BAWAH TEXTAREA: CEK / PREVIEW KODE + INFO BARIS/KARAKTER */}
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <button
                    type="button"
                    onClick={handleValidateHtmlCode}
                    className="px-4 py-2 rounded-[10px] bg-[#F7F8FC] hover:bg-[#EAECEF] border border-[#E8E8E8] text-[#111111] text-xs font-extrabold flex items-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#FF3B30]" />
                    <span>Cek / Preview Kode</span>
                  </button>
                  <span className="text-[11px] font-mono font-bold text-[#8A8A8E] tabular-nums">
                    {htmlLineCount} baris • {htmlCharCount.toLocaleString('id-ID')} karakter
                  </span>
                </div>

                <span className="text-[11px] text-[#8A8A8E]">
                  Kode akan diupload sebagai <span className="font-mono font-bold text-[#111111]">.html</span> saat Build
                </span>
              </div>

              {/* MODAL FULLSCREEN EDITOR HTML */}
              {isHtmlEditorFullscreen && (
                <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs p-3 sm:p-6 flex items-center justify-center">
                  <div className="w-full max-w-5xl h-[90vh] rounded-[18px] bg-[#1C1C1E] border border-white/15 shadow-2xl flex flex-col overflow-hidden">
                    <div className="px-4 py-3 bg-[#141416] border-b border-white/10 flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2.5">
                        <Code2 className="w-4 h-4 text-[#FF3B30]" />
                        <span className="text-xs font-black uppercase tracking-[0.8px] text-white">
                          Editor HTML Fullscreen
                        </span>
                        <span className="text-[11px] font-mono text-[#8A8A8E] tabular-nums">
                          ({htmlLineCount} baris • {htmlCharCount.toLocaleString('id-ID')} karakter)
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handlePasteFromClipboard}
                          className="px-3 py-1.5 rounded-[8px] bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <ClipboardPaste className="w-3.5 h-3.5 text-[#FF3B30]" />
                          <span>Paste</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setIsHtmlEditorFullscreen(false)}
                          className="px-3 py-1.5 rounded-[8px] bg-[#FF3B30] hover:bg-[#E0342A] text-white text-[11px] font-black flex items-center gap-1 cursor-pointer"
                        >
                          <Minimize2 className="w-3.5 h-3.5" />
                          <span>Tutup</span>
                        </button>
                        <button
                          type="button"
                          aria-label="Tutup Editor Fullscreen"
                          onClick={() => setIsHtmlEditorFullscreen(false)}
                          className="p-1.5 rounded-[8px] bg-white/10 hover:bg-white/20 text-white cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="flex-1 overflow-hidden flex">
                      <div
                        ref={fullscreenLineNumbersRef}
                        aria-hidden="true"
                        className="h-full py-4 px-3 bg-[#141416] border-r border-white/10 text-[#636366] font-mono text-xs leading-6 text-right select-none overflow-hidden min-w-[48px] shrink-0"
                      >
                        {Array.from({ length: htmlLineCount }, (_, idx) => (
                          <div key={idx}>{idx + 1}</div>
                        ))}
                      </div>

                      <textarea
                        value={htmlCodeText}
                        onChange={(e) => {
                          setHtmlCodeText(e.target.value);
                          setCodeCheckResult(null);
                        }}
                        onScroll={(e) => {
                          if (fullscreenLineNumbersRef.current) {
                            fullscreenLineNumbersRef.current.scrollTop = e.currentTarget.scrollTop;
                          }
                        }}
                        spellCheck={false}
                        autoFocus
                        placeholder="<!DOCTYPE html> <html> ... paste kode HTML lu di sini ..."
                        className="flex-1 h-full p-4 bg-transparent text-[#F5F5F7] placeholder:text-[#6E6E73] font-mono text-xs leading-6 resize-none focus:outline-none overflow-y-auto"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* HASIL CEK KODE */}
              {codeCheckResult?.checked && (
                <div
                  className={`p-3 rounded-[12px] border text-xs space-y-1 ${
                    codeCheckResult.isEmpty
                      ? 'bg-[#FFE9E9]/80 border-[#FF3B30]/30 text-[#FF3B30]'
                      : codeCheckResult.hasHtmlTag && codeCheckResult.hasBodyTag
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-amber-50 border-amber-200 text-amber-800'
                  }`}
                >
                  {codeCheckResult.isEmpty ? (
                    <p className="font-bold">Kode HTML masih kosong, paste dulu.</p>
                  ) : (
                    <>
                      <p className="font-extrabold">
                        Hasil Validasi Kode ({htmlLineCount} baris • {htmlCharCount} karakter):
                      </p>
                      <div className="flex items-center gap-3 flex-wrap text-[11px] font-mono">
                        <span>&lt;html&gt;: {codeCheckResult.hasHtmlTag ? 'ADA' : 'TIDAK ADA'}</span>
                        <span>•</span>
                        <span>&lt;body&gt;: {codeCheckResult.hasBodyTag ? 'ADA' : 'TIDAK ADA'}</span>
                        <span>•</span>
                        <span>&lt;!DOCTYPE&gt;: {codeCheckResult.hasDoctype ? 'ADA' : 'OPSIONAL'}</span>
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* WARNING KUNING JIKA TIDAK ADA TAG <HTML> SAAT KLIK BUILD */}
              {htmlMissingTagWarning && (
                <div className="p-3 rounded-[12px] bg-amber-50 border border-amber-300 flex items-center justify-between gap-3 flex-wrap">
                  <p className="text-xs font-bold text-amber-900 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Kode tidak ada tag &lt;html&gt;, tetap lanjut?</span>
                  </p>
                  <button
                    type="button"
                    disabled={isBuildingApk || isUploadingHtmlCode}
                    onClick={onConfirmProceedWithoutHtmlTag}
                    className="px-3.5 py-1.5 rounded-[10px] bg-amber-600 hover:bg-amber-700 text-white text-xs font-black uppercase cursor-pointer"
                  >
                    Tetap Lanjut Build
                  </button>
                </div>
              )}

              {/* BOX HIJAU: HTML_URL PUBLIK SIAP DIKIRIM */}
              {htmlCodePublicUrl && (
                <div className="p-3 rounded-[12px] bg-emerald-50 border border-emerald-200 space-y-1">
                  <p className="text-[11px] font-black text-emerald-800 uppercase">
                    HTML_URL PUBLIK SIAP DIKIRIM
                  </p>
                  <p className="text-[11px] font-mono text-emerald-800 break-all">{htmlCodePublicUrl}</p>
                </div>
              )}

              {htmlCodeUploadError && (
                <div className="p-3 rounded-[12px] bg-[#FFE9E9]/80 border border-[#FF3B30]/30">
                  <p className="text-[11px] font-bold text-[#FF3B30] leading-relaxed">{htmlCodeUploadError}</p>
                </div>
              )}
            </div>
          )}

          {/* TOGGLE FULLSCREEN (BERLAKU UNTUK SEMUA 3 MODE) */}
          <div className="p-3.5 rounded-[14px] bg-[#F7F8FC] border border-[#E8E8E8] flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <p className="text-xs font-extrabold uppercase tracking-[0.8px] text-[#111111]">
                  Fullscreen
                </p>
                <span
                  className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                    apkFullscreen
                      ? 'bg-[#FFE9E9] text-[#FF3B30]'
                      : 'bg-[#E8E8E8] text-[#636366]'
                  }`}
                >
                  {apkFullscreen ? 'ON' : 'OFF'}
                </span>
              </div>
              <p className="text-[11px] text-[#8A8A8E] font-medium mt-0.5">
                {apkFullscreen
                  ? 'ON — Mengirim fullscreen="true" ke GitHub Actions (tanpa title bar)'
                  : 'OFF — Mengirim fullscreen="false" ke GitHub Actions (dengan title bar)'}
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={apkFullscreen}
              onClick={() => setApkFullscreen((prev) => !prev)}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full transition-colors duration-200 ease-in-out ${
                apkFullscreen ? 'bg-[#FF3B30]' : 'bg-[#D1D5DB]'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out mt-0.5 ${
                  apkFullscreen ? 'translate-x-5.5' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>

        {/* CARD 3 - ICON */}
        <div className="rounded-[16px] bg-white border border-[#E8E8E8] shadow-[0_4px_20px_rgba(0,0,0,0.04)] p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-[8px] bg-[#FFE9E9] text-[#FF3B30] flex items-center justify-center text-xs font-black">
                3
              </span>
              <h2 className="text-xs font-black uppercase tracking-[0.8px] text-[#111111]">
                Icon
              </h2>
            </div>

            {apkIconUrl ? (
              <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
                Icon Siap
              </span>
            ) : isUploadingIcon ? (
              <span className="text-[10px] font-black text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> Mengupload...
              </span>
            ) : apkIconError ? (
              <span className="text-[10px] font-black text-[#FF3B30] bg-[#FFE9E9] border border-[#FFD6D4] px-2.5 py-0.5 rounded-full">
                Upload Gagal
              </span>
            ) : (
              <span className="text-[10px] font-bold text-[#8A8A8E] bg-[#F7F8FC] border border-[#E8E8E8] px-2.5 py-0.5 rounded-full">
                Opsional
              </span>
            )}
          </div>

          <input
            type="file"
            id="apkLogoFileInput"
            accept="image/png,image/jpeg,image/jpg,image/webp"
            onChange={handleFileInputChange}
            className="hidden"
          />

          <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-4 items-center">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDraggingIcon(true);
              }}
              onDragLeave={() => setIsDraggingIcon(false)}
              onDrop={handleIconDrop}
              onClick={() => !isUploadingIcon && document.getElementById('apkLogoFileInput')?.click()}
              className={`rounded-[14px] border-2 border-dashed p-5 text-center transition-all cursor-pointer select-none ${
                isDraggingIcon
                  ? 'border-[#FF3B30] bg-[#FFE9E9]/40'
                  : 'border-[#E0E2EA] bg-[#F7F8FC] hover:border-[#FF3B30]/60 hover:bg-[#FAFAFC]'
              } ${isUploadingIcon ? 'opacity-60 pointer-events-none' : ''}`}
            >
              <div className="flex flex-col items-center gap-1.5">
                {isUploadingIcon ? (
                  <Loader2 className="w-7 h-7 text-[#FF3B30] animate-spin" />
                ) : (
                  <UploadCloud className="w-7 h-7 text-[#FF3B30]" />
                )}
                <p className="text-xs font-extrabold text-[#111111]">
                  {isUploadingIcon
                    ? 'Mengupload icon ke hosting publik...'
                    : 'Drag & drop icon di sini, atau klik untuk pilih file'}
                </p>
                <p className="text-[11px] font-semibold text-[#8A8A8E]">
                  PNG, min 512x512 (maks. 5 MB)
                </p>
              </div>
            </div>

            <div className="flex flex-col items-center gap-1.5">
              <div className="w-24 h-24 rounded-[22px] overflow-hidden flex items-center justify-center relative bg-gradient-to-b from-[#FF3B30] to-[#C81E1E] shadow-[0_6px_18px_rgba(0,0,0,0.14)] ring-1 ring-black/8">
                {showUploadedIconPreview ? (
                  <img
                    src={activePreviewIcon}
                    alt="Preview Icon Home Screen"
                    onError={() => setPreviewIconFailed(true)}
                    onLoad={(e) => {
                      if (e.currentTarget.naturalWidth < 2 || e.currentTarget.naturalHeight < 2) {
                        setPreviewIconFailed(true);
                      }
                    }}
                    className="w-full h-full object-cover object-center block"
                  />
                ) : (
                  <span className="text-[62px] font-black leading-none text-white select-none">
                    {displayFirstLetter}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-bold text-[#8A8A8E] text-center">
                {showUploadedIconPreview
                  ? `Home Screen (${apkIconDimensions ? `${apkIconDimensions.width}x${apkIconDimensions.height}` : 'Cover'})`
                  : `Default (${displayFirstLetter})`}
              </span>
              {activePreviewIcon && (
                <button
                  type="button"
                  onClick={onClearIcon}
                  className="text-[10px] font-bold text-[#FF3B30] hover:underline flex items-center gap-1 cursor-pointer mt-0.5"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Hapus icon</span>
                </button>
              )}
            </div>
          </div>

          {apkIconDimensions && (apkIconDimensions.width < 512 || apkIconDimensions.height < 512) && (
            <div className="p-2.5 rounded-[12px] bg-amber-50 border border-amber-200 text-[11px] font-semibold text-amber-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                Dimensi gambar Anda {apkIconDimensions.width}x{apkIconDimensions.height}px (disarankan min 512x512px agar icon APK tajam).
              </span>
            </div>
          )}

          {apkIconError && (
            <div className="p-3 rounded-[14px] bg-[#FFE9E9]/70 border border-[#FF3B30]/30 space-y-2">
              <p className="text-[11px] font-bold text-[#FF3B30] leading-relaxed">
                {apkIconError}
              </p>
              <div className="flex items-center gap-2 flex-wrap">
                {hasPendingIconUpload && (
                  <button
                    type="button"
                    disabled={isUploadingIcon}
                    onClick={onRetryIconUpload}
                    className="text-[10px] font-extrabold px-3 py-1.5 rounded-[10px] bg-[#FF3B30] text-white hover:bg-[#E0342A] flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" /> Coba Upload Ulang
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setApkSubView('SETTINGS')}
                  className="text-[10px] font-extrabold px-3 py-1.5 rounded-[10px] bg-white border border-[#FF3B30]/30 text-[#FF3B30] hover:bg-[#FFE9E9] cursor-pointer"
                >
                  Buka Pengaturan Builder
                </button>
                <button
                  type="button"
                  onClick={onClearIcon}
                  className="text-[10px] font-extrabold px-3 py-1.5 rounded-[10px] bg-white border border-[#E8E8E8] text-[#8A8A8E] hover:text-[#111111] cursor-pointer"
                >
                  Hapus Icon
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* TOMBOL BUILD & SIMPAN ZIP */}
      <div className="space-y-3">
        <button
          type="button"
          disabled={isBuildingApk || isUploadingIcon || isUploadingZip || isUploadingHtmlCode}
          onClick={() => onStartBuild(false)}
          className="w-full py-4 px-6 rounded-[16px] bg-[#FF3B30] hover:bg-[#E0342A] text-white font-black text-sm tracking-[1px] uppercase shadow-[0_8px_24px_rgba(255,59,48,0.3)] active:scale-[0.99] transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isBuildingApk ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin shrink-0" />
              <span>SEDANG BUILD...</span>
            </>
          ) : (
            <>
              <Play className="w-5 h-5 shrink-0 fill-current" />
              <span>BUAT &amp; INSTAL APK</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={onSaveAsZip}
          className="w-full py-3.5 px-6 rounded-[16px] border-2 border-[#111111] bg-white hover:bg-[#111111] hover:text-white text-[#111111] font-extrabold text-xs tracking-[1px] uppercase active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
        >
          <Download className="w-4 h-4 shrink-0" />
          <span>SIMPAN JUGA SEBAGAI PROJECT ZIP</span>
        </button>
      </div>

      {/* CARD BUILD PROFESIONAL ALA PLAY STORE (TAMPIL HANYA SETELAH USER KLIK BUILD) */}
      {liveBuild.phase !== 'idle' && (
        <div className="rounded-[18px] bg-white border border-[#E8E8E8] shadow-[0_10px_32px_rgba(0,0,0,0.06)] p-5 sm:p-6 space-y-5 animate-in fade-in">
          {/* HEADER CARD: ICON 64x64 KIRI + NAMA & METADATA KANAN */}
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-[16px] overflow-hidden shrink-0 shadow-xs border border-[#E8E8E8] flex items-center justify-center bg-gradient-to-b from-[#FF3B30] to-[#C81E1E]">
              {showUploadedIconPreview ? (
                <img
                  src={activePreviewIcon}
                  alt={displayAppName}
                  onError={() => setPreviewIconFailed(true)}
                  onLoad={(e) => {
                    if (e.currentTarget.naturalWidth < 2 || e.currentTarget.naturalHeight < 2) {
                      setPreviewIconFailed(true);
                    }
                  }}
                  className="w-full h-full object-cover object-center block"
                />
              ) : (
                <span className="text-[42px] font-black leading-none text-white select-none">
                  {displayFirstLetter}
                </span>
              )}
            </div>

            <div className="min-w-0 flex-1 space-y-1">
              <h3 className="text-lg sm:text-xl font-black text-[#111111] truncate leading-tight">
                {displayAppName}
              </h3>
              <p className="text-xs font-medium text-[#8A8A8E] truncate font-mono">
                v{displayVersion} • {displayPackage} • {apkBuildMode}
                {liveBuild.runId ? ` • RUN #${liveBuild.runId}` : ''}
              </p>
            </div>
          </div>

          {/* PROGRESS BAR REAL-TIME (DIHITUNG LANGSUNG DARI STATUS GITHUB API; DISEMBUNYIKAN JIKA DISPATCH GAGAL) */}
          {progressInfo.isDispatchError ? (
            <div className="p-3.5 rounded-[12px] bg-[#FFE9E9]/70 border border-[#FFD6D4] space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-black text-[#FF3B30]">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{progressInfo.statusText}</span>
              </div>
              <p className="text-[11px] font-mono text-[#FF3B30] break-words leading-relaxed">
                {liveBuild.dispatchError || liveBuild.errorMessage || 'Gagal mengirim workflow_dispatch ke GitHub Actions.'}
              </p>
            </div>
          ) : progressInfo.isRunTimeout ? (
            <div className="p-3.5 rounded-[12px] bg-amber-50 border border-amber-200 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-black text-amber-900">
                <Loader2 className="w-4 h-4 shrink-0 text-amber-600" />
                <span>GitHub masih memproses, cek di Lihat Log / buka GitHub Actions manual</span>
              </div>
              <p className="text-[11px] font-mono text-amber-800 break-words leading-relaxed">
                Mencari Run sejak {sentTimeLabel}... Dispatch sudah berhasil dikirim (204), klik Cek Lagi untuk memeriksa daftar Runs tanpa mengirim ulang.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="flex-1 h-[10px] rounded-full bg-[#EEF0F5] overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${progressInfo.barColorClass}`}
                    style={{ width: `${progressInfo.percent}%` }}
                  />
                </div>
                <span className="text-xs font-black tabular-nums text-[#111111] shrink-0 min-w-[38px] text-right">
                  {progressInfo.percent}%
                </span>
              </div>

              <div className="flex items-center justify-between gap-2 text-xs">
                <span
                  className={`font-bold inline-flex items-center gap-1.5 ${
                    progressInfo.isSuccess
                      ? 'text-emerald-700'
                      : progressInfo.isFailed
                      ? 'text-[#FF3B30]'
                      : 'text-[#636366]'
                  }`}
                >
                  {progressInfo.isLocating && (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-[#FF3B30] shrink-0" />
                  )}
                  <span>{progressInfo.statusText}</span>
                </span>
                {liveBuild.lastPolledAt && !progressInfo.isSuccess && !progressInfo.isFailed && (
                  <span className="text-[11px] text-[#8A8A8E] font-mono">
                    Polling API: {liveBuild.lastPolledAt}
                  </span>
                )}
              </div>

              {progressInfo.isFailed && (liveBuild.errorMessage || liveBuild.dispatchError) && (
                <p className="text-[11px] font-mono text-[#FF3B30] bg-[#FFE9E9]/70 border border-[#FFD6D4] rounded-[10px] p-2.5 break-words">
                  {liveBuild.errorMessage || liveBuild.dispatchError}
                </p>
              )}
            </div>
          )}

          {/* TOMBOL AKSI SESUAI STATUS BUILD */}
          {isBuildingApk ? (
            <button
              type="button"
              disabled
              className="w-full py-3.5 px-5 rounded-[14px] bg-[#F7F8FC] border border-[#E8E8E8] text-[#8A8A8E] font-black text-xs uppercase tracking-[0.8px] flex items-center justify-center gap-2 cursor-not-allowed"
            >
              <Loader2 className="w-4 h-4 animate-spin text-[#FF3B30]" />
              <span>
                {liveBuild.phase === 'locating_run'
                  ? `MENUNGGU RUN DIBUAT (${liveBuild.locateElapsedSec ?? 5}s)...`
                  : 'SEDANG BUILD...'}
              </span>
            </button>
          ) : progressInfo.isSuccess ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                disabled={isDownloadingApk || !liveBuild.artifactUrl}
                onClick={() => onDownloadApk(liveBuild.artifactUrl, displayAppName)}
                className="py-3.5 px-5 rounded-[14px] bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-[0.8px] shadow-[0_6px_18px_rgba(5,150,105,0.28)] flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {isDownloadingApk ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>MENGUNDUH .APK...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>INSTALL</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleShareApk}
                className="py-3.5 px-5 rounded-[14px] bg-white hover:bg-[#F7F8FC] border-2 border-[#E8E8E8] hover:border-[#111111] text-[#111111] font-black text-xs uppercase tracking-[0.8px] flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-[#FF3B30]" />
                <span>BAGIKAN</span>
              </button>
            </div>
          ) : progressInfo.isDispatchError ? (
            <button
              type="button"
              onClick={() => onStartBuild(false)}
              className="w-full py-3.5 px-5 rounded-[14px] bg-[#FF3B30] hover:bg-[#E0342A] text-white font-black text-xs uppercase tracking-[0.8px] flex items-center justify-center gap-2 transition-all cursor-pointer shadow-[0_6px_18px_rgba(255,59,48,0.25)]"
            >
              <RefreshCw className="w-4 h-4" />
              <span>COBA LAGI</span>
            </button>
          ) : progressInfo.isRunTimeout || progressInfo.isFailed ? (
            <div className="space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={onRecheckRun}
                  className="py-3.5 px-5 rounded-[14px] bg-[#FF3B30] hover:bg-[#E0342A] text-white font-black text-xs uppercase tracking-[0.8px] flex items-center justify-center gap-2 transition-all cursor-pointer shadow-[0_6px_18px_rgba(255,59,48,0.25)]"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>CEK LAGI</span>
                </button>

                {liveBuild.runUrl ? (
                  <a
                    href={liveBuild.runUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-3.5 px-5 rounded-[14px] bg-[#111111] hover:bg-[#2C2C2E] text-white font-black text-xs uppercase tracking-[0.8px] flex items-center justify-center gap-2 transition-all"
                  >
                    <ExternalLink className="w-4 h-4 text-[#FF3B30]" />
                    <span>LIHAT LOG DI GITHUB</span>
                  </a>
                ) : (
                  <button
                    type="button"
                    disabled
                    className="py-3.5 px-5 rounded-[14px] bg-[#F7F8FC] border border-[#E8E8E8] text-[#AAAAAA] font-black text-xs uppercase tracking-[0.8px] flex items-center justify-center gap-2 cursor-not-allowed"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>LIHAT LOG DI GITHUB</span>
                  </button>
                )}
              </div>

              {confirmNewDispatch ? (
                <div className="p-3 rounded-[12px] bg-[#FFE9E9]/70 border border-[#FFD6D4] flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[11px] font-bold text-[#FF3B30]">
                    Yakin kirim build baru lagi? Pastikan tidak duplikat di GitHub.
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setConfirmNewDispatch(false)}
                      className="px-3 py-1.5 rounded-[8px] bg-white border border-[#E8E8E8] text-[#111111] text-[10px] font-bold uppercase cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setConfirmNewDispatch(false);
                        onStartBuild(false);
                      }}
                      className="px-3 py-1.5 rounded-[8px] bg-[#FF3B30] text-white text-[10px] font-black uppercase cursor-pointer"
                    >
                      Ya, Kirim Build Baru
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmNewDispatch(true)}
                  className="w-full py-2.5 px-4 rounded-[12px] bg-[#F7F8FC] hover:bg-[#EAECEF] border border-[#E8E8E8] text-[#636366] font-bold text-[11px] uppercase tracking-[0.6px] transition-all cursor-pointer"
                >
                  Kirim Build Baru (Konfirmasi)
                </button>
              )}
            </div>
          ) : null}

          {/* INFO KECIL BISA DI-COLLAPSE PALING BAWAH CARD */}
          <details className="pt-3 border-t border-[#F0F0F0] group">
            <summary className="text-[11px] font-bold text-[#8A8A8E] hover:text-[#111111] flex items-center justify-between cursor-pointer list-none">
              <span>
                Detail: Jam kirim {sentTimeLabel} • {liveBuild.runId ? `RUN #${liveBuild.runId}` : 'Lihat Log'}
              </span>
              <ChevronDown className="w-3.5 h-3.5 group-open:rotate-180 transition-transform" />
            </summary>
            <div className="pt-2 flex items-center justify-between gap-2 flex-wrap text-[11px] text-[#636366]">
              <span className="font-mono">
                Jam kirim: {sentTimeLabel} •{' '}
                {liveBuild.runId
                  ? `RUN #${liveBuild.runId} ditemukan`
                  : `Mencari Run sejak ${sentTimeLabel}...`}
              </span>
              {liveBuild.runUrl ? (
                <a
                  href={liveBuild.runUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#FF3B30] font-bold hover:underline inline-flex items-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" /> Lihat Log
                </a>
              ) : (
                <span className="text-[#AAAAAA]">Log belum tersedia</span>
              )}
            </div>
          </details>
        </div>
      )}
    </div>
  );
};
