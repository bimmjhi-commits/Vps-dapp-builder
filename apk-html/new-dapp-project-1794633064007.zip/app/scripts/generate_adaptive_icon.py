#!/usr/bin/env python3
"""
Generate full-bleed Android Adaptive Icons (512x512 CENTER_CROP / COVER)
for uploaded user photos without any black bars, white bars, padding, or letterbox.

JALUR 1 (--icon / --icon-url valid):
- Load image with EXIF transpose
- Sample non-black/non-white edge color; flatten any alpha padding over edge color
- Strict CENTER_CROP / COVER to 512x512 (zoomed full-bleed, zero letterbox)
- Adaptive background uses blurred full-bleed photo + edge hex (never #000000 or #FFFFFF)

JALUR 2 (empty / failed / timeout / non-image / corrupt):
- NEVER produce a white empty canvas
- Red gradient background (#FF3B30 -> #C81E1E)
- White first letter of app_name centered & ~80% of visible icon canvas
"""
import argparse
import os
import shutil
import tempfile
import urllib.request
from collections import Counter
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

ADAPTIVE_DENSITIES = {
    "mdpi": 108,
    "hdpi": 162,
    "xhdpi": 216,
    "xxhdpi": 324,
    "xxxhdpi": 432,
}

LEGACY_DENSITIES = {
    "mdpi": 48,
    "hdpi": 72,
    "xhdpi": 96,
    "xxhdpi": 144,
    "xxxhdpi": 192,
}

THEME_TOP = (255, 59, 48)      # #FF3B30
THEME_BOTTOM = (200, 30, 30)   # #C81E1E


def clamp_non_bw_rgb(rgb: tuple[int, int, int]) -> tuple[int, int, int]:
    """Ensure sampled color is NEVER pure #000000 or pure #FFFFFF."""
    r, g, b = rgb
    if max(r, g, b) <= 24:
        return (36, 36, 40)
    if min(r, g, b) >= 242:
        return (242, 242, 247)
    return (r, g, b)


def extract_edge_rgb(img: Image.Image) -> tuple[int, int, int]:
    """Sample dominant non-black/non-white edge color from outer pixels."""
    small = img.convert("RGBA").resize((64, 64), Image.Resampling.BILINEAR)
    w, h = small.size
    edge_pixels = []
    for x in range(w):
        edge_pixels.append(small.getpixel((x, 0)))
        edge_pixels.append(small.getpixel((x, h - 1)))
    for y in range(1, h - 1):
        edge_pixels.append(small.getpixel((0, y)))
        edge_pixels.append(small.getpixel((w - 1, y)))

    opaque = [(r, g, b) for (r, g, b, a) in edge_pixels if a >= 180]
    if not opaque:
        return (44, 44, 48)

    filtered = [rgb for rgb in opaque if 20 < max(rgb) and min(rgb) < 245]
    sample = filtered if filtered else [clamp_non_bw_rgb(rgb) for rgb in opaque]
    quantized = [((r // 8) * 8, (g // 8) * 8, (b // 8) * 8) for (r, g, b) in sample]
    most_common, _ = Counter(quantized).most_common(1)[0]
    return clamp_non_bw_rgb(most_common)


def rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#{:02X}{:02X}{:02X}".format(*clamp_non_bw_rgb(rgb))


def load_font(size_px: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            return ImageFont.truetype(path, max(12, size_px))
    return ImageFont.load_default()


def build_red_gradient(size: int) -> Image.Image:
    canvas = Image.new("RGBA", (size, size))
    draw = ImageDraw.Draw(canvas)
    for y in range(size):
        ratio = y / max(1, size - 1)
        r = int(THEME_TOP[0] + (THEME_BOTTOM[0] - THEME_TOP[0]) * ratio)
        g = int(THEME_TOP[1] + (THEME_BOTTOM[1] - THEME_TOP[1]) * ratio)
        b = int(THEME_TOP[2] + (THEME_BOTTOM[2] - THEME_TOP[2]) * ratio)
        draw.line([(0, y), (size, y)], fill=(r, g, b, 255))
    return canvas


def draw_centered_letter(canvas: Image.Image, letter: str, target_ratio: float) -> Image.Image:
    """Draw large centered white letter occupying ~target_ratio (e.g. 0.78) of canvas."""
    size = canvas.width
    draw = ImageDraw.Draw(canvas)
    font_px = int(size * target_ratio * 1.15)
    font = load_font(font_px)
    bbox = draw.textbbox((0, 0), letter, font=font)
    tw = max(1, bbox[2] - bbox[0])
    th = max(1, bbox[3] - bbox[1])

    # Auto-fit so neither width nor height overflows target_ratio
    max_dim = size * target_ratio
    if tw > max_dim or th > max_dim:
        scale = min(max_dim / tw, max_dim / th)
        font = load_font(int(font_px * scale))
        bbox = draw.textbbox((0, 0), letter, font=font)
        tw = max(1, bbox[2] - bbox[0])
        th = max(1, bbox[3] - bbox[1])

    tx = (size - tw) / 2 - bbox[0]
    ty = (size - th) / 2 - bbox[1]
    draw.text((tx, ty), letter, fill=(255, 255, 255, 255), font=font)
    return canvas


def generate_default_letter_assets(app_name: str, size: int = 512) -> tuple[Image.Image, Image.Image, Image.Image, str]:
    """
    Returns (legacy_512, adaptive_foreground_512, adaptive_background_512, bg_hex).
    Adaptive launcher visible area is the inner 72/108 (66.7%), so drawing the letter
    at ~0.52 of the 108dp canvas makes it ~78-80% of the visible icon without clipping.
    Legacy icon is not 66.7%-cropped, so letter fills ~0.78 of the 512px canvas directly.
    """
    letter = (app_name.strip()[:1] or "A").upper()
    grad_bg = build_red_gradient(size)

    legacy_full = draw_centered_letter(grad_bg.copy(), letter, target_ratio=0.76)
    adaptive_fg = draw_centered_letter(Image.new("RGBA", (size, size), (0, 0, 0, 0)), letter, target_ratio=0.52)
    return legacy_full, adaptive_fg, grad_bg, "#FF3B30"


def try_load_user_photo(icon_path: str, icon_url: str) -> Image.Image | None:
    candidate_path = icon_path.strip() if icon_path else ""
    temp_file = None

    try:
        if (not candidate_path or not os.path.exists(candidate_path) or os.path.getsize(candidate_path) == 0) and icon_url:
            clean_url = icon_url.strip()
            if clean_url.lower().startswith(("http://", "https://")):
                req = urllib.request.Request(
                    clean_url,
                    headers={"User-Agent": "DappApkBuilder/1.0"},
                )
                with urllib.request.urlopen(req, timeout=15) as resp:
                    data = resp.read(12 * 1024 * 1024)
                if data:
                    fd, temp_file = tempfile.mkstemp(suffix=".img")
                    os.close(fd)
                    with open(temp_file, "wb") as f:
                        f.write(data)
                    candidate_path = temp_file

        if not candidate_path or not os.path.exists(candidate_path) or os.path.getsize(candidate_path) == 0:
            return None

        with Image.open(candidate_path) as opened:
            opened.load()
            transposed = ImageOps.exif_transpose(opened)
            rgba = transposed.convert("RGBA")
            if rgba.width < 2 or rgba.height < 2:
                return None

            # Flatten transparency onto sampled non-black/non-white edge color
            edge_rgb = extract_edge_rgb(rgba)
            backdrop = Image.new("RGBA", rgba.size, (*edge_rgb, 255))
            composited = Image.alpha_composite(backdrop, rgba)
            return composited
    except Exception:
        return None
    finally:
        if temp_file and os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except OSError:
                pass


def clean_old_icon_files(res_dir: str) -> None:
    """Remove old mipmap PNGs/XMLs so padded or blank white leftovers never survive."""
    for density in ADAPTIVE_DENSITIES:
        mipmap_dir = os.path.join(res_dir, f"mipmap-{density}")
        if os.path.isdir(mipmap_dir):
            for fname in (
                "ic_launcher.png",
                "ic_launcher_round.png",
                "ic_launcher_foreground.png",
                "ic_launcher_background.png",
                "ic_launcher.webp",
                "ic_launcher_round.webp",
            ):
                fpath = os.path.join(mipmap_dir, fname)
                if os.path.exists(fpath):
                    os.remove(fpath)
    anydpi_dir = os.path.join(res_dir, "mipmap-anydpi-v26")
    if os.path.isdir(anydpi_dir):
        for fname in ("ic_launcher.xml", "ic_launcher_round.xml"):
            fpath = os.path.join(anydpi_dir, fname)
            if os.path.exists(fpath):
                os.remove(fpath)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--res-dir", default="app/src/main/res")
    parser.add_argument("--icon", default="")
    parser.add_argument("--icon-url", default="")
    parser.add_argument("--app-name", default="App")
    args = parser.parse_args()

    clean_old_icon_files(args.res_dir)
    user_photo = try_load_user_photo(args.icon, args.icon_url)

    if user_photo is not None:
        # JALUR 1: Strict CENTER_CROP / COVER ke kotak 1:1 512x512 fullscreen
        full_bleed = ImageOps.fit(
            user_photo,
            (512, 512),
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        )
        edge_rgb = extract_edge_rgb(full_bleed)
        bg_hex = rgb_to_hex(edge_rgb)
        adaptive_fg_512 = full_bleed
        adaptive_bg_512 = full_bleed.filter(ImageFilter.GaussianBlur(radius=24))
        legacy_512 = full_bleed
    else:
        # JALUR 2: Default red gradient + ~80% centered white first letter (NEVER white blank)
        legacy_512, adaptive_fg_512, adaptive_bg_512, bg_hex = generate_default_letter_assets(
            args.app_name, 512
        )

    for density, px in ADAPTIVE_DENSITIES.items():
        mipmap_dir = os.path.join(args.res_dir, f"mipmap-{density}")
        os.makedirs(mipmap_dir, exist_ok=True)

        fg = ImageOps.fit(adaptive_fg_512, (px, px), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
        fg.save(os.path.join(mipmap_dir, "ic_launcher_foreground.png"), "PNG")

        bg_mip = ImageOps.fit(adaptive_bg_512, (px, px), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
        bg_mip.save(os.path.join(mipmap_dir, "ic_launcher_background.png"), "PNG")

        legacy_px = LEGACY_DENSITIES[density]
        legacy_icon = ImageOps.fit(legacy_512, (legacy_px, legacy_px), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
        legacy_icon.save(os.path.join(mipmap_dir, "ic_launcher.png"), "PNG")
        legacy_icon.save(os.path.join(mipmap_dir, "ic_launcher_round.png"), "PNG")

    values_dir = os.path.join(args.res_dir, "values")
    os.makedirs(values_dir, exist_ok=True)
    with open(os.path.join(values_dir, "ic_launcher_background.xml"), "w", encoding="utf-8") as f:
        f.write(
            '<?xml version="1.0" encoding="utf-8"?>\n'
            "<resources>\n"
            f'    <color name="ic_launcher_background">{bg_hex}</color>\n'
            "</resources>\n"
        )

    anydpi_dir = os.path.join(args.res_dir, "mipmap-anydpi-v26")
    os.makedirs(anydpi_dir, exist_ok=True)
    adaptive_xml = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
        '    <background android:drawable="@mipmap/ic_launcher_background" />\n'
        '    <foreground android:drawable="@mipmap/ic_launcher_foreground" />\n'
        "</adaptive-icon>\n"
    )
    for xml_name in ("ic_launcher.xml", "ic_launcher_round.xml"):
        with open(os.path.join(anydpi_dir, xml_name), "w", encoding="utf-8") as f:
            f.write(adaptive_xml)


if __name__ == "__main__":
    main()
